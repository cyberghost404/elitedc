<?php
global $ps_color,$zcmas,$ztmas,$conn1,$ps_operlogin,$ps_scheme,$ps_usercode,$ps_status,$conn1;
$ps_color=trim($ps_color);	
if ($ps_status>0){
	$rs_2=mysql_query("select COLOR from tbl_user where CODE=".$ps_usercode,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_color=$rs['COLOR'];	
	mysql_free_result($rs_2);
}
if (is_null($ps_color)==true) $ps_color="";
if (trim($ps_color)=="") $ps_color=getconf("SCHEME","VALUESTR");
if (file_exists($zserver.'main/color/'.$ps_color.'.col')==false) $ps_color='standart';
$ps_file = fopen($zserver.'main/color/'.$ps_color.'.col', "r");
	while (!feof($ps_file)) {
   		$ps1 = fgets($ps_file);
   		if (trim($ps1)!=""){
      		$ps_tip2=substr($ps1,0,1);
      		$ps_number=trim(mid($ps1,3,2));
      		$ps_value=trim(mid($ps1,6,15));
      		if ($ps_tip2=="C") $zcmas[$ps_number]=$ps_value; 
      		if ($ps_tip2=="T") $ztmas[$ps_number]=$ps_value;
   		}
	}
fclose($ps_file);
$ps_scheme=$ps_color;
?>
<style type="text/css">
	<!--
	.table_toppanel {background: url(main/color/scheme/<?php echo $ps_color;?>/fon_toppanel.png) repeat-x; background-color: <?php echo $zcmas[4];?>; BORDER-RIGHT: <?php echo $zcmas[1];?> 2px solid; BORDER-TOP: <?php echo $zcmas[1];?> 2px solid; BORDER-LEFT: <?php echo $zcmas[1];?> 2px solid; BORDER-BOTTOM: <?php echo $zcmas[1];?> 2px solid; PADDING-RIGHT: 0px; MARGIN-TOP: <?php echo $zcmas[1];?> 2px solid; PADDING-LEFT: <?php echo $zcmas[1];?> 2px solid; PADDING-BOTTOM: <?php echo $zcmas[1];?> 1px solid; PADDING-TOP: <?php echo $zcmas[1];?> 1px solid;}
	.table_header   {background: url(main/color/scheme/<?php echo $ps_color;?>/fon_header.png) repeat;}
	.table_leftmenu {background: url(main/color/scheme/<?php echo $ps_color;?>/fon_leftmenu.png) repeat; padding-bottom:0px; background-color: <?php echo $zcmas[7];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid;}
	.table_leftmenu_user {background: url(main/color/scheme/<?php echo $ps_color;?>/fon_leftmenu_user.png) repeat; vertical-align:middle; background-color: <?php echo $zcmas[4];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid;}
	.table_leftmenu_user_menu {background-color: <?php echo $zcmas[7];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid; PADDING-RIGHT: <?php echo $zcmas[4];?> 1px solid; BORDER-TOP: <?php echo $zcmas[4];?> 1px solid; MARGIN-TOP: <?php echo $zcmas[4];?> 1px solid; PADDING-LEFT: <?php echo $zcmas[4];?> 1px solid; PADDING-BOTTOM: <?php echo $zcmas[4];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[4];?> 1px solid; PADDING-TOP: <?php echo $zcmas[4];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[4];?> 1px solid;}
	.table_leftmenu_subkat {background-color: <?php echo $zcmas[7];?>; BORDER-RIGHT: <?php echo $zcmas[3];?> 2px solid; BORDER-TOP: <?php echo $zcmas[3];?> 2px solid; BORDER-LEFT: <?php echo $zcmas[3];?> 2px solid; BORDER-BOTTOM: <?php echo $zcmas[3];?> 2px solid; PADDING-RIGHT: <?php echo $zcmas[3];?> 2px solid; MARGIN-TOP: <?php echo $zcmas[3];?> 2px solid; PADDING-LEFT: <?php echo $zcmas[3];?> 2px solid; PADDING-BOTTOM: <?php echo $zcmas[3];?> 1px solid; PADDING-TOP: <?php echo $zcmas[3];?> 1px solid;}
	.table_down_kat {background-color: <?php echo $zcmas[7];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid; BORDER-TOP: <?php echo $zcmas[4];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[4];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-RIGHT: <?php echo $zcmas[4];?> 1px solid; MARGIN-TOP: <?php echo $zcmas[4];?> 1px solid; PADDING-LEFT: <?php echo $zcmas[4];?> 1px solid; PADDING-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-TOP: <?php echo $zcmas[4];?> 1px solid;}
	.table_down_kat_element {background: url(main/color/scheme/<?php echo $ps_color;?>/fon_down_kat.png) repeat; background-color: <?php echo $zcmas[4];?>; BORDER-RIGHT: <?php echo $zcmas[1];?> 2px solid; BORDER-TOP: <?php echo $zcmas[1];?> 2px solid; BORDER-LEFT: <?php echo $zcmas[1];?> 2px solid; BORDER-BOTTOM: <?php echo $zcmas[1]; ?> 2px solid; PADDING-RIGHT: 0px; MARGIN-TOP: <?php echo $zcmas[1];?> 2px solid; PADDING-LEFT: <?php echo $zcmas[1];?> 2px solid; PADDING-BOTTOM: <?php echo $zcmas[1];?> 1px solid; PADDING-TOP: <?php echo $zcmas[1];?> 1px solid;}
	.table_kat {background-color: <?php echo $zcmas[7];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid; BORDER-TOP: <?php echo $zcmas[4];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[4];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-RIGHT: <?php echo $zcmas[4];?> 1px solid; MARGIN-TOP: <?php echo $zcmas[4];?> 1px solid; PADDING-LEFT: <?php echo $zcmas[4];?> 1px solid; PADDING-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-TOP: <?php echo $zcmas[4];?> 1px solid;}
		#table_kat {background-color: <?php echo $zcmas[8];?>;}
	.table_kat_element {background: url(main/color/scheme/<?php echo $ps_color;?>/fon_down_kat.png) repeat; background-color: <?php echo $zcmas[4];?>; BORDER-RIGHT: <?php echo $zcmas[1];?> 2px solid; BORDER-TOP: <?php echo $zcmas[1];?> 2px solid; BORDER-LEFT: <?php echo $zcmas[1];?> 2px solid; BORDER-BOTTOM: <?php echo $zcmas[1]; ?> 2px solid; PADDING-RIGHT: 0px; MARGIN-TOP: <?php echo $zcmas[1];?> 2px solid; PADDING-LEFT: <?php echo $zcmas[1];?> 2px solid; PADDING-BOTTOM: <?php echo $zcmas[1];?> 1px solid; PADDING-TOP: <?php echo $zcmas[1];?> 1px solid;}
	.table_int_table {background-color: <?php echo $zcmas[7];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid; BORDER-TOP: <?php echo $zcmas[4];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[4];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-RIGHT: <?php echo $zcmas[4];?> 1px solid; MARGIN-TOP: <?php echo $zcmas[4];?> 1px solid; PADDING-LEFT: <?php echo $zcmas[4];?> 1px solid; PADDING-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-TOP: <?php echo $zcmas[4];?> 1px solid;}
	.table_int_table2 {background-color: <?php echo $zcmas[8];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid; BORDER-TOP: <?php echo $zcmas[4];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[4];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-RIGHT: <?php echo $zcmas[4];?> 1px solid; MARGIN-TOP: <?php echo $zcmas[4];?> 1px solid; PADDING-LEFT: <?php echo $zcmas[4];?> 1px solid; PADDING-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-TOP: <?php echo $zcmas[4];?> 1px solid;}
	.table_int_int_table {background-color: <?php echo $zcmas[1];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid; BORDER-TOP: <?php echo $zcmas[4];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[4];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-RIGHT: <?php echo $zcmas[4];?> 1px solid; MARGIN-TOP: <?php echo $zcmas[4];?> 1px solid; PADDING-LEFT: <?php echo $zcmas[4];?> 1px solid; PADDING-BOTTOM: <?php echo $zcmas[4];?> 1px solid; PADDING-TOP: <?php echo $zcmas[4];?> 1px solid;}


	INPUT {BACKGROUND: <?php echo $zcmas[30];?>; BORDER-RIGHT: <?php echo $zcmas[3];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[3];?> 1px solid; BORDER-TOP: <?php echo $zcmas[3];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[3];?> 1px solid; FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[31];?>; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold; HEIGHT: 18px}
	.INPUT2 {BACKGROUND: <?php echo $zcmas[30];?>; BORDER-RIGHT: <?php echo $zcmas[3];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[3];?> 1px solid; BORDER-TOP: <?php echo $zcmas[3];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[3];?> 1px solid; FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[31];?>; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold; HEIGHT: 18px}
		#INPUT2 {BACKGROUND: <?php echo $zcmas[32];?>; COLOR: <?php echo $zcmas[33];?>}
	.INPUT3 {BACKGROUND: <?php echo $zcmas[32];?>; BORDER-RIGHT: <?php echo $zcmas[3];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[3];?> 1px solid; BORDER-TOP: <?php echo $zcmas[3];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[3];?> 1px solid; FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[33];?>; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold; HEIGHT: 18px}
		#INPUT3 {BACKGROUND: <?php echo $zcmas[30];?>; COLOR: <?php echo $zcmas[31];?>}
	.INPUTB1 {cursor: url(main/color/scheme/<?php echo $ps_color;?>/cur_hand.cur), pointer; BACKGROUND: <?php echo $zcmas[32];?>; height:18; border:solid 1px; FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[33];?>; BORDER-RIGHT: <?php echo $zcmas[4];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[4];?> 1px solid; BORDER-TOP: <?php echo $zcmas[4];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[4];?> 1px solid; FONT-FAMILY: <?php echo $ztmas['1']; ?>; FONT-WEIGHT: bold}
		#INPUTB1 {BACKGROUND: <?php echo $zcmas[30];?>; COLOR: <?php echo $zcmas[31];?>}
	.INPUTB3 {cursor: url(main/color/scheme/<?php echo $ps_color;?>/cur_hand.cur), pointer; BACKGROUND: <?php echo $zcmas[32];?>; height:18; width:50; border:solid 1px; FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[33];?>; BORDER-RIGHT: <?php echo $zcmas[3];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[3];?> 1px solid; BORDER-TOP: <?php echo $zcmas[3];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[3];?> 1px solid; FONT-FAMILY: <?php echo $ztmas['1']; ?>; FONT-WEIGHT: bold}
		#INPUTB3 {BACKGROUND: <?php echo $zcmas[30];?>; COLOR: <?php echo $zcmas[31];?>}
	.INPUTB5 {cursor: url(main/color/scheme/<?php echo $ps_color;?>/cur_hand.cur), pointer; BACKGROUND: <?php echo $zcmas[32];?>; height:18; width:100; border:solid 1px; FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[33];?>; BORDER-RIGHT: <?php echo $zcmas[3];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[3];?> 1px solid; BORDER-TOP: <?php echo $zcmas[3];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[3];?> 1px solid; FONT-FAMILY: <?php echo $ztmas['1']; ?>; FONT-WEIGHT: bold}
		#INPUTB5 {BACKGROUND: <?php echo $zcmas[30];?>; COLOR: <?php echo $zcmas[31];?>}
	TEXTAREA {BACKGROUND: <?php echo $zcmas[30];?>; BORDER-RIGHT: <?php echo $zcmas[3];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[3];?> 1px solid; BORDER-TOP: <?php echo $zcmas[3];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[3];?> 1px solid; FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[31];?>; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold}
	.mceNoEditor {FONT-SIZE: 8pt;}
	OPTION {BACKGROUND: <?php echo $zcmas[30];?>;  FONT-SIZE: 9pt; COLOR: <?php echo $zcmas[31];?>; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold; HEIGHT: 18px; BORDER-RIGHT: <?php echo $zcmas[13];?> 1px solid; BORDER-BOTTOM: <?php echo $zcmas[13];?> 1px solid; BORDER-TOP: <?php echo $zcmas[13];?> 1px solid; BORDER-LEFT: <?php echo $zcmas[13];?> 1px solid}

	A:link {COLOR: <?php echo $zcmas[20];?>; TEXT-DECORATION: none}
	A:visited {COLOR: <?php echo $zcmas[20];?>; TEXT-DECORATION: none}
	A:hover {COLOR: <?php echo $zcmas[22];?>; TEXT-DECORATION: underline}

	A.link1:link {COLOR: <?php echo $zcmas[23];?>; TEXT-DECORATION: none}
	A.link1:visited {COLOR: <?php echo $zcmas[23];?>; TEXT-DECORATION: none}
	A.link1:hover {COLOR: <?php echo $zcmas[24];?>; TEXT-DECORATION: underline}

	A.link2:link {COLOR: <?php echo $zcmas[24];?>; TEXT-DECORATION: none}
	A.link2:visited {COLOR: <?php echo $zcmas[24];?>; TEXT-DECORATION: none}
	A.link2:hover {COLOR: <?php echo $zcmas[23];?>; TEXT-DECORATION: underline}

	A.linksorted:link {COLOR: <?php echo $zcmas[20];?>; TEXT-DECORATION: underline}
	A.linksorted:visited {COLOR: <?php echo $zcmas[20];?>; TEXT-DECORATION: underline}
	A.linksorted:hover {COLOR: <?php echo $zcmas[22];?>; TEXT-DECORATION: underline}

	BODY {COLOR: <?php echo $zcmas[10];?>; BACKGROUND-COLOR: <?php echo $zcmas[1];?>; TEXT-DECORATION: none; 
	  cursor:url('main/color/scheme/<?php echo $ps_color;?>/cur_cursor.cur');
	  scrollbar-face-color: <?php echo $zcmas[41];?>;
	  scrollbar-highlight-color: <?php echo $zcmas[42];?>;
	  scrollbar-shadow-color: <?php echo $zcmas[42];?>;
	  scrollbar-3dlight-color: <?php echo $zcmas[42];?>;
	  scrollbar-arrow-color: <?php echo $zcmas[42];?>;
	  scrollbar-track-color: <?php echo $zcmas[40];?>;
	  scrollbar-darkshadow-color: <?php echo $zcmas[42];?>;}

	.f6  {FONT-SIZE: 6pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	.f6b {FONT-SIZE: 6pt; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold;}
	.f7  {FONT-SIZE: 7pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	.f8  {FONT-SIZE: 8pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	.f8b {FONT-SIZE: 8pt; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold;}
	.f9  {FONT-SIZE: 9pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	.f9b {FONT-SIZE: 9pt; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold;}
	.f10 {FONT-SIZE: 10pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	.f10b{FONT-SIZE: 10pt; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold;}
	.f11 {FONT-SIZE: 11pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	.f11b {FONT-SIZE: 11pt; FONT-FAMILY: <?php echo $ztmas[1];?>; FONT-WEIGHT: bold;}
	.f30 {FONT-SIZE: 30pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	.f70 {FONT-SIZE: 70pt; FONT-FAMILY: <?php echo $ztmas[1];?>;}
	-->
</style>
