function tag_it2(txtstart,txtend) {
	document.frmlogin.opis.focus();
	if (document.selection){
		var rng = document.selection.createRange();
	  	if (rng.text){
	   		document.selection.createRange().text = txtstart + rng.text + txtend;
	   	}else{
	   		document.frmlogin.opis.value += txtstart  + txtend;
	   	}
	  	document.frmlogin.opis.focus();
	}
	else if (document.frmlogin.opis.selectionStart || document.frmlogin.opis.selectionStart == '0') {
		var selStart = document.frmlogin.opis.selectionStart;
		var selEnd = document.frmlogin.opis.selectionEnd; 
		var s = document.frmlogin.opis.value;     
		s = s.substring(0, selStart) + txtstart + s.substring(selStart, selEnd) + txtend + s.substring(selEnd, s.length);
	 	document.frmlogin.opis.value = s; 
		if (selEnd != selStart) {
			document.frmlogin.opis.selectionStart = selStart;
		 	document.frmlogin.opis.selectionEnd = selEnd + txtstart.length + txtend.length;
		}else{
			document.frmlogin.opis.selectionStart = selStart + txtstart.length;
		 	document.frmlogin.opis.selectionEnd = document.frmlogin.opis.selectionStart;
		}
	}else{
		document.frmlogin.opis.value += txtstart + txtend;   
	}
}


function tag_it(txtstart,txtend) {
	document.frmcomment.comment.focus();
	if (document.selection){
		var rng = document.selection.createRange();
	  	if (rng.text){
	   		document.selection.createRange().text = txtstart + rng.text + txtend;
	   	}else{
	   		document.frmcomment.comment.value += txtstart  + txtend;
	   	}
	  	document.frmcomment.comment.focus();
	}
	else if (document.frmcomment.comment.selectionStart || document.frmcomment.comment.selectionStart == '0') {
		var selStart = document.frmcomment.comment.selectionStart;
		var selEnd = document.frmcomment.comment.selectionEnd; 
		var s = document.frmcomment.comment.value;     
		s = s.substring(0, selStart) + txtstart + s.substring(selStart, selEnd) + txtend + s.substring(selEnd, s.length);
	 	document.frmcomment.comment.value = s; 
		if (selEnd != selStart) {
			document.frmcomment.comment.selectionStart = selStart;
		 	document.frmcomment.comment.selectionEnd = selEnd + txtstart.length + txtend.length;
		}else{
			document.frmcomment.comment.selectionStart = selStart + txtstart.length;
		 	document.frmcomment.comment.selectionEnd = document.frmcomment.comment.selectionStart;
		}
	}else{
		document.frmcomment.comment.value += txtstart + txtend;   
	}
}


function _capsLockDetect(e){
  if (!e) e = window.event || null; 
  if (typeof(oncapslock)!="function" || !e) return;
  var n = e.keyCode?e.keyCode:e.charCode; //��� ����⮩ ������
  if (e.type=="keypress") {
    var c = String.fromCharCode(n); //����砥� ᨬ��� �� ��� ����
    var cUC = c.toUpperCase(); //��ॢ���� ᨬ��� � ���孨� ॣ����
    var cLC = c.toLowerCase(); //��ॢ���� ᨬ��� � ������ ॣ����
    if (cUC!=cLC){
      oncapslock((e.shiftKey && cLC==c) || (!e.shiftKey && cUC==c));
    }
  }else{
    if (e.type=="keydown" && n==20) oncapslock(false);
  }
}

if (document.addEventListener)//IE
{
	document.addEventListener("keypress", _capsLockDetect, false);
	document.addEventListener("keydown", _capsLockDetect, false);
}
else if (document.attachEvent)//W3C (Gecko...)
{
	document.attachEvent("onkeypress", _capsLockDetect);
	document.attachEvent("onkeydown", _capsLockDetect);
}
else document.onkeypress = document.onkeydown = _capsLockDetect;

function selectoptions(obj) {
  var iMax = 1000;
  var iMaxCounter = obj.options.length;
  if (iMaxCounter > iMax) iMaxCounter = iMax;
  for (var i=0; i<iMaxCounter; i++) {
    obj.options[i].selected = true;
  }
}

function movelist(from,to) {
  for (var i=0; i<from.options.length; i++) {
    var o = from.options[i];
    if (o.selected) {
      to.options[to.options.length] = new Option( o.text, o.value, false, false);
    }
  }
  for (var i=(from.options.length-1); i>=0; i--) {
    var o = from.options[i];
    if (o.selected) from.options[i] = null;
  }
}

function showel(id) {
  document.cookie="mg_"+id+"=1; expires=Mon, 05-Jan-2015 00:00:00 GMT";
  document.getElementById(id).style.display = '';
}

function hideel(id) {
  document.cookie="mg_"+id+"=0; expires=Mon, 05-Jan-2015 00:00:00 GMT";
  document.getElementById(id).style.display = 'none';
}

function inserttext()
{
  var ea;
  for( var i = 0; i < arguments.length; i++ ) {
    var e = arguments[i];
    if( typeof e == 'string' )
      e = document.getElementById(e);
    if( arguments.length == 1 )
      return e;
    if( !ea )
      ea = new Array();
    ea[ea.length] = e;
  }
  return ea;
} 

function ICOIn(Pict) {
	document.images[Pict].style.height=18
	document.images[Pict].style.width=18
	}

function ICOOut(Pict) {
	document.images[Pict].style.height=16
	document.images[Pict].style.width=16
	}

function OpenDoc(nreg,Ps_Name) {window.open(nreg,Ps_Name,"width=100,height=100,status=no,toolbar=no,resizable=no,scrollbars=yes,menubar=no");} 

function mOvr(src,Col1) {    
if (!src.contains(event.fromElement)) 
{	  src.style.cursor = "hand";	  
          src.bgColor = Col1;        }    
}
  function mOut(src,Col1) {
if (!src.contains(event.toElement)) 
{	  src.style.cursor = "default";	  
          src.bgColor = Col1;     	}  
}

  function mClk(src) {    if(event.srcElement.tagName=="TD"){	  src.children.tags("A")[0].click();    }  }

//���������� ������� 
isOpera=isOpera5=window.opera&&isDOM; //Opera 5+ 
isMSIE=document.all&&document.all.item&&!isOpera; //MSIE 4+ 
isMozilla=navigator.appName=="Netscape"; //Mozilla 

//��������� ���������� ���������� � �������� �� 
var mousex = 0; 
var mousey = 0; 
var screenW = 0;
var screenH = 0;

//������� ���������� ����� � ���������� � ��� � ��� 
if (isMSIE || isOpera){ 
document.onmousemove = function(){ 
mousex = event.clientX + document.body.scrollLeft; 
mousey = event.clientY + document.body.scrollTop; 

screenW = screen.width;
screenH = screen.height;

return true; 
} 
} 
//������� ���������� ����� � ������� 
else if (isMozilla){ 
document.onmousemove=function(e){ 
mousex = e.pageX; 
mousey = e.pageY; 

screenW = screen.width;
screenH = screen.height;

return true; 
} 
} 

//���������� div � ������������ � ������������ 
function showMenu(objMenu,pi_h2,pi_w2,ps_t){ 

if (ps_t=="mapdesign"){
  document.forms.frmdiv.topy.value=mousey-4;
  document.forms.frmdiv.leftx.value=mousex-4;
  pi_x2="300";
  pi_y2="80";
}

if (mousex>(pi_w2/2))
{
mousex=mousex-pi_x2
}
if (isMSIE || isOpera){ 
	if (mousey>((screenH+document.body.scrollTop)-450))
	{
	mousey=mousey-pi_y2
	}
}
else if (isMozilla){ 
	if (mousey>(screenH-450))
	{
	mousey=mousey-pi_y2
	}
}

objMenu.style.display = ""; 
objMenu.style.left = mousex+5+"px"; 
objMenu.style.top = mousey+5+"px"; 
} 

//�������� div 
function hideMenu(objMenu){ 
objMenu.style.display = "none"; 
} 

