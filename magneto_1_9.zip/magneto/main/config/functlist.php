<?php
session_start();
$zcmas=array();
$ztmas=array();
$pmas1=array();
$pmas2=array();
require_once('config.php');
require_once('admfunct.php');

global $pmas1, $pmas2;
global $ps1, $ps2, $ps3, $ps4, $ps5, $ps6, $ps7, $ps8;
global $pi1, $pi2, $pi3, $pi4, $pi5, $pi6, $pi7, $pi8, $pi9;
global $pd1, $pd2, $pd3, $pd_last, $pd_first;
global $pb1, $pb2, $pb3, $pb4, $pb5;
global $zpda,$zl,$start_time,$zos;

global $conn1, $conn2, $conn3, $conn_s, $rs, $rs2, $rs3, $rs_s, $ps_connstring;
global $fso, $ps_file, $ps_file2, $ps_files, $ps_folder, $ps_fn;

global $ps_ip, $ps_login, $ps_pass, $ps_usercode, $ps_scheme, $ps_operlogin, $ps_status, $ps_comment;

global $zver, $znetname, $znetsite, $zdemo, $zvaluta, $zright, $zbilling, $ztypeact,$zlang;

global $ps_type, $ps_sort, $ps_style, $ps_msg, $ps_print, $ps_h, $ps_w, $ps_search, $ps_type2, $ps_type3, $ps_desc, $ps_code, $ps_step;

global $ps_page, $ps_pagetotal, $ps_pagemin, $ps_pagemax, $ps_onpage;


openconn_s();

$start_time = microtime();
$start_array = explode(" ",$start_time);
$start_time = $start_array[1] + $start_array[0];
all_readparam();

function openconn1 ()
	{
	global $zsqlserver, $zsqluser, $zsqlpass,$zsqldb,$conn1;
	$conn1 = mysql_connect($zsqlserver,$zsqluser,$zsqlpass);
	$rs=mysql_query("set names cp1251",$conn1);
	mysql_select_db($zsqldb ,$conn1) or die('MAGNETO - error connect to conn1: '.mysql_error());
	return;
	}

function openconn2 ()
	{
	global $zsqlserver, $zsqluser, $zsqlpass,$zsqldb,$conn2;
	$conn2 = mysql_connect($zsqlserver,$zsqluser,$zsqlpass);
	$rs=mysql_query("set names cp1251",$conn2);
	mysql_select_db($zsqldb ,$conn2) or die('MAGNETO - error connect to conn2: '.mysql_error());
	return;
	}

function openconn3 ()
	{
	global $zsqlserver, $zsqluser, $zsqlpass,$zsqldb,$conn3;
	$conn3 = mysql_connect($zsqlserver,$zsqluser,$zsqlpass);
	$rs=mysql_query("set names cp1251",$conn3);
	mysql_select_db($zsqldb ,$conn3) or die('MAGNETO - error connect to conn3: '.mysql_error());
	return;
	}

function openconn_s ()
	{
	global $zsqlserver, $zsqluser, $zsqlpass,$zsqldb,$conn_s;
	$conn_s = mysql_connect($zsqlserver,$zsqluser,$zsqlpass);
	$rs=mysql_query("set names cp1251",$conn_s);
	mysql_select_db($zsqldb ,$conn_s) or die('MAGNETO - error connect to conn_s: '.mysql_error());
	return;
	}

//���������� ����
openconn1();
$ps1=getconf("LANG_SYST","VALUESTR");
if ($ps1=="") $ps1="ru";
require_once($zserver.'main/lang/'.$ps1.'_magneto.php' );
mysql_close($conn1);
$ps_style="";
?>
