<?php
//require_once('main/config/functlist.php' );
openconn1();

verifyuser();
iswork();
dopverify2(1);

if ($ps_type=="new" || $ps_type=="new2" || $ps_type=="newok") $ps_style="short";


if ($ps_type=="msgdel"){
	$rs_2=mysql_query("select TOCODE,FROMCODE from tbl_trouble where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_tocode=$rs['TOCODE'];
		$ps_fromcode=$rs['FROMCODE'];
	mysql_free_result($rs_2);	
	$rs_s2=mysql_query("delete from tbl_trouble where CODE=".$ps_code." and TOCODE=".$ps_usercode,$conn1);
	if ($zright['DO_MODER']==1 || $zright['DO_MODERATOR']==1){
		$rs_s2=mysql_query("delete from tbl_trouble where CODE=".$ps_code." and FROMCODE=".$ps_usercode,$conn1);
		if ($ps_fromcode==$ps_usercode){
			header("Location: trouble.php?type=msgsend");exit;
		}
	}
	header("Location: trouble.php?type=msgin");exit;
}


if ($ps_type=="new2"){
	$ps_login=requestdata("user_login");
	$ps_opis=requestdata("opis");
	if ($ps_login=='' || $ps_opis==''){
		$ps_msg="blank";
		$ps_type="new";
	}else{
		//��������� - ���� �� ����� ����� � ����
		$pi1=recordcount_new("tbl_user where LOGIN='".$ps_login."'");
		if ($pi1==0){
			$ps_msg="badlogin";
			$ps_type="new";
		}else{
			$rs_2=mysql_query("select CODE from tbl_user where LOGIN='".$ps_login."'",$conn1);
				$rs=mysql_fetch_array($rs_2);
				$ps_logincode=$rs['CODE'];
			mysql_free_result($rs_2);
			//��������� - �� ���� �� �����
			if ($ps_logincode==$ps_usercode){
				$ps_msg="tohim";
				$ps_type="new";
			}else{
				//��������� � ����
				$ps_constr="insert into tbl_trouble (FROMCODE,TOCODE,OPIS,BASECODE,DATEADD,ISREAD) values (".$ps_usercode.",".$ps_logincode.",'".$ps_opis."',0,'".sqldatetime2(mktime())."',0)";
				$rs_s2=mysql_query($ps_constr,$conn1);
				?>
				<script type="text/javascript" language="JavaScript">
						{    
						window.opener.history.go(0);
						window.location="trouble.php?type=newok";
						}
				</script>
				<?php			
				exit;
			}
		}
	}
}

?>
<HTML>
<HEAD>
	<?php
	$ps1="";
	if ($ps_type=="") $ps1=$zl['524'];//���������
	if ($ps_type=="msgin") $ps1=$zl['531'];//�������� ���������
	if ($ps_type=="msgsend") $ps1=$zl['536'];//������������ ���������
	if ($ps_type=="new" || $ps_type=="new3") $ps1=$zl['525'];//����� ���������
	?>
	<TITLE><?php echo getconf("PROJECTNAME","VALUESTR").' - '.$ps1 ?></TITLE>
	<?php site_header()?>
</HEAD>
<script  language="JavaScript">
	function autoReload(){ 	
        document.frmadd.submit()
	}
	function autoReload1(){ 	
        document.frmadd1.submit()
	}
</script>			
<BODY leftMargin=0 topMargin=0>
<?php 
if ($ps_style=="") require_once('inc_top.php');
?>
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	<TR valign=top>
		<?php 
		if ($ps_style=="") require_once('inc_left.php');
		?>

		<TD class=f10>
    		<?php



    		//===========================================================================================
    		if ($ps_type=="newok"){
    			windowsize(250,500);
    			echo '<br><br><center>';
				//���� ��������� ����������
				us_text2($zl['530']);
				echo '<br>';
				closewindow();
			}



    		//===========================================================================================
    		if ($ps_type=="new"){
    			windowsize(500,700);
    			echo '<br><center>';
				//����� ���������

				?><TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0><TR><TD><?php

				us_text2($zl['525']);

				?></TD></TR></TABLE><?php

				echo '<br>';
				if ($ps_type2!='') $ps_login=getuserlogin($ps_type2);
				?>
				<form method="post" name="frmlogin" action="trouble.php" border=0>
					<?php
					if ($ps_msg!=''){
						if ($ps_msg=='badlogin') $ps_msg=$zl['526'];//������������ � ����� ������� �� ������!
						if ($ps_msg=='blank') $ps_msg=$zl['529'];//�� ��� ���� ���������!
						if ($ps_msg=='tohim') $ps_msg=$zl['659'];//���� ������ ������
						echo '<b><font color="'.$zcmas[16].'">'.$ps_msg.'</font></b><br><br>';
					}
					?>
					<input type="hidden" name="type" value="<?php echo $ps_type?>2">
					<b>
					<?php
					//������� ����� ����������
					echo $zl['527'].": ";
					?>
					<INPUT TYPE="input" NAME="user_login" size="40" maxlength=40 value="<?php echo $ps_login?>" class=input2 onFocus="id=className;" onblur="id=''"><br>
					<br>
					<?php
					//����� ���������
					echo $zl['528'].":<br>";
					?>
					<textarea class=TEXTAREA1 name="opis" cols="100" rows="10"><?php 
					if ($ps_opis!="") echo $ps_opis;?></textarea><br>		
					<br>	
					<?php
					//���������
					inputstyle($zl['333']);
					?>
					<br>
					<br>
				</form>	
				<?php

			}



		

    		//===========================================================================================
    		if ($ps_type=="msgin"){
				//�������� ���������

				?><TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0><TR><TD><?php

				us_text($zl['531']);

				?></TD></TR></TABLE><?php

				echo '<br>';
				$pi_count=recordcount_new("tbl_trouble where TOCODE=".$ps_usercode);
				$ps_perpage=getconf("PERPAGE","VALUESTR");;//�� ������� �� ��������
				$pi3=ceil($pi_count/$ps_perpage);
				$pi4=($ps_page-1)*$ps_perpage;					
				if ($pi_count>0){
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd" action="trouble.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}					
					$rs2_2 = mysql_query("select * from tbl_trouble where TOCODE=".$ps_usercode." order by DATEADD desc limit ".$pi4.",".$ps_perpage,$conn1);
						while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
							//������ ������� � ���������
							$rs_s2=mysql_query("update tbl_trouble set ISREAD=1 where CODE=".$rs2['CODE'],$conn1);
							?>
							<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0 bgcolor="<?php echo $zcmas[2]?>">
								<TR valign=top height=100%>
									<TD class=f9 width=150 align=center>
										<font size=1><u><?php echo cdate($rs2['DATEADD'])?></u></font><br>
										<?php
										$rs3_2=mysql_query("select * from tbl_user where CODE=".$rs2['FROMCODE'],$conn1);
											$rs3=mysql_fetch_array($rs3_2);
											if ($rs3['ISBAN']==1){
												//������������ ������������
												?>
												<img src="main/color/scheme/<?php echo $ps_color;?>/element_lock.png" width=16 height=16 alt="<?php echo $zl['172']?>">
												<?php
											}
											//���������� � ������������
											?>
											<a href="user.php?type=show&code=<?php echo $rs2['FROMCODE']?>" title="<?php echo $zl['12']?>">
											<?php echo $rs3['LOGIN'];?>
											</a><br>
											<?php
											if ($rs3['POSTER']!="" && mayavatar($rs2['FROMCODE'])==1){
												?>
												<img src="main/avatar/<?php echo $rs3['POSTER']?>" width=64 height=64 border=0>
												<br>														
												<?php
											}
											//������� ������������
											echo '<font size=1>'.getstatusname($rs3['STATUS']).'</font><br>';
											//�������
											echo '<font size=1>'.$zl['255'].': '.$rs3['RATINGS'].'</font><br>';
											$ps_israt=1;
											echo getstar(floor($rs3['RATINGS']*0.1)).' ';
											$ps_israt=0;
										mysql_free_result($rs3_2);
										?>
									</TD>
									<td>
										<TABLE cellSpacing=0 cellPadding=0 width=100% height=100% border=0>
											<TR valign=top height=100%>
												<TD class=f9 width=100%>
													<?php
													$ps_opis=$rs2['OPIS']; 
													$ps_opis=str_replace(chr(13),"<br>",$ps_opis);
													//������������ ����� ������
													$ps_comment=commentdo($ps_opis);
													echo $ps_comment;
													?><br>
												</TD>
											</TR>
											<TR valign=bottom>
												<TD class=f9 width=100%>
													<?php
													//�������� �� ���������
													?>
													:: <a href="javascript:OpenDoc('trouble.php?type=new&type2=<?php echo $rs2['FROMCODE']?>',<?php echo rndwindow()?>)" title="<?php echo $zl['534']?>"><?php echo $zl['534']?></a><br>
												</TD>
											</TR>
										</TABLE>
									</td>
									<td width=20>
										<?php
										//������� ���������
										//������������� ������� ���������
										?>
										<a href="trouble.php?type=msgdel&code=<?php echo $rs2['CODE']?>" title="<?php echo $zl['532']?>" OnClick="return confirm('<?php echo $zl['533']?>?'); return true;">
										<img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=16 height=16 border=0>
										</a>
									</td>
								</TR>										
							</TABLE>	
							<br>		
							<?php
						}
					mysql_free_result($rs2_2);	
					?>
					</center>
					<?php
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd1" action="trouble.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					echo '<br>';									
				}else{
					echo '<b>'.$zl['178'].'</b>';//������ ������ ���
				}

			}





    		//===========================================================================================
    		if ($ps_type=="msgsend"){
				//������������ ���������

				?><TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0><TR><TD><?php

				us_text($zl['536']);

				?></TD></TR></TABLE><?php

				echo '<br>';
				$pi_count=recordcount_new("tbl_trouble where FROMCODE=".$ps_usercode);
				$ps_perpage=getconf("PERPAGE","VALUESTR");;//�� ������� �� ��������
				$pi3=ceil($pi_count/$ps_perpage);
				$pi4=($ps_page-1)*$ps_perpage;					
				if ($pi_count>0){
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd" action="trouble.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}					
					$rs2_2 = mysql_query("select * from tbl_trouble where FROMCODE=".$ps_usercode." order by DATEADD desc limit ".$pi4.",".$ps_perpage,$conn1);
						while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
							?>
							<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0 bgcolor="<?php echo $zcmas[2]?>">
								<TR valign=top height=100%>
									<TD class=f9 width=150 align=center>
										<font size=1><u><?php echo cdate($rs2['DATEADD'])?></u></font><br>
										<?php
										$rs3_2=mysql_query("select * from tbl_user where CODE=".$rs2['TOCODE'],$conn1);
											$rs3=mysql_fetch_array($rs3_2);
											if ($rs3['ISBAN']==1){
												//������������ ������������
												?>
												<img src="main/color/scheme/<?php echo $ps_color;?>/element_lock.png" width=16 height=16 alt="<?php echo $zl['172']?>">
												<?php
											}
											//���������� � ������������
											?>
											<a href="user.php?type=show&code=<?php echo $rs2['TOCODE']?>" title="<?php echo $zl['12']?>">
											<?php echo $rs3['LOGIN'];?>
											</a><br>
											<?php
											if ($rs3['POSTER']!="" && mayavatar($rs2['TOCODE'])==1){
												?>
												<img src="main/avatar/<?php echo $rs3['POSTER']?>" width=64 height=64 border=0>
												<br>														
												<?php
											}
											//������� ������������
											echo '<font size=1>'.getstatusname($rs3['STATUS']).'</font><br>';
											//�������
											echo '<font size=1>'.$zl['255'].': '.$rs3['RATINGS'].'</font><br>';
											$ps_israt=1;
											echo getstar(floor($rs3['RATINGS']*0.1)).' ';
											$ps_israt=0;
										mysql_free_result($rs3_2);
										?>
									</TD>
									<td>
										<TABLE cellSpacing=0 cellPadding=0 width=100% height=100% border=0>
											<TR valign=top height=100%>
												<TD class=f9 width=100%>
													<?php
													$ps_opis=$rs2['OPIS']; 
													$ps_opis=str_replace(chr(13),"<br>",$ps_opis);
													//������������ ����� ������
													$ps_comment=commentdo($ps_opis);
													echo $ps_comment;
													?><br>
												</TD>
											</TR>
										</TABLE>
									</td>
									<td width=20>
										<?php
										//������� ����� ������ � ����
										//������� ���������
										//������������� ������� ���������
										if ($zright['DO_MODER']==1 || $zright['DO_MODERATOR']==1){
											?>
											<a href="trouble.php?type=msgdel&code=<?php echo $rs2['CODE']?>" title="<?php echo $zl['532']?>" OnClick="return confirm('<?php echo $zl['533']?>?'); return true;">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=16 height=16 border=0>
											</a>
											<?php
										}
										?>
									</td>
								</TR>										
							</TABLE>	
							<br>		
							<?php
						}
					mysql_free_result($rs2_2);	
					?>
					</center>
					<?php
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd1" action="trouble.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					echo '<br>';									
				}else{
					echo '<b>'.$zl['535'].'</b>';//������ ���
				}
			}


			?>
    	</TD>

		<?php 
		if ($ps_style=="") require_once('inc_right.php');
		?>
	      									
	</TR>
</TABLE>
<?php 
if ($ps_style=="") require_once('inc_down.php');
mysql_close($conn1);
?>	
</body>
</html>
