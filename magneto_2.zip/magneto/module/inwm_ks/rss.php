<?php
header("content-type: application/rss+xml");
echo "<?xml version='1.0' encoding='windows-1251'?>
<rss version=\"2.0\">
<channel>";
//require_once('main/config/functlist.php');
openconn1();
?>
<title><?php echo getconf("PROJECTNAME","VALUESTR").' - '.$zl['167']?></title>
<link><?php echo $zpath?></link>
<description><?php echo $zl['417'].' ';?><?php echo $zpath?></description>
<language>ru</language>
<?php
//���� ���������� ��������� � ������ �����
$ps_constr="select DATEMODER from tbl_base where ISMODER=1 order by DATEMODER desc limit 1";
$rs_2 = mysql_query($ps_constr,$conn1);
	$rs=mysql_fetch_array($rs_2);
	$ps1=date("r",strtotime($rs['DATEMODER'])); // ����������� ���� � ������ RFC 2822
	echo "<lastBuildDate>".$ps1."</lastBuildDate>";
mysql_free_result($rs_2);
//�������
$pi1=getconf("RSS_COUNT","VALUESTR");
if ($pi1=='') $pi1=20;
$ps_constr="select * from tbl_base where ISMODER=1 order by DATEMODER desc limit ".$pi1;
$rs_2 = mysql_query($ps_constr,$conn1);
	while (($rs=mysql_fetch_assoc($rs_2))!==false) {
		?>
		<item>
		<?php
		$ps1=$rs['NAZV'];
		$ps1=str_replace('"',"'",$ps1);
		$ps1=str_replace('&#34',"'",$ps1);
		$ps1=str_replace('&',"&amp;",$ps1);
		?>
		<title><?php echo $ps1?> (<?php echo getkatname($rs['KAT']);if ($rs['WHOEDIT']>0) echo ' // ���������';?>)</title>
		<link><?php echo $zpath;?>topic.php?type=show&amp;code=<?php echo $rs['CODE']?></link>
		<copyright>Kondrat</copyright>
		<?php
		$ps10 = $ps1;
		$ps1=left_1($rs['OPIS'],300);
		$ps1=commentdo($ps1);
		$ps1=str_replace('"',"'",$ps1);
		$ps1=str_replace('&#34',"'",$ps1);
		$ps1=str_replace('&',"&amp;",$ps1);
		$ps1=str_replace('<',"&lt;",$ps1);
		$ps1=str_replace('>',"&gt;",$ps1);
		?>

		<description>
		<?php
		// echo smalleskiz($rs['POSTER']);

		?>

		<table cellSpacing="5" cellPadding="0" border="1">
			<tr>
				<td>
					<![CDATA[<?php echo smalleskiz($rs['POSTER']);?>]]>
				</td>
				<td class="f8b">
					<?php echo $ps1?>
				</td>
			</tr>
		</table>		
		
		</description>

		<?php
		$ps1=date("r",strtotime($rs['DATEMODER']));
		?>
		<pubDate><?php echo $ps1?></pubDate>
		<guid>../topic.php?type=show&amp;code=<?php echo $rs['CODE']?></guid>
		</item>


		<?php
	}
mysql_free_result($rs_2);
?>
</channel>
</rss>
<?php
mysql_close($conn1);
?>	
