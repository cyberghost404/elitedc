<?php
function viewinfo($ps_linkcode){
global $conn1,$zcmas,$ps_israt,$ps_color,$zl,$ps_kat3,$ps_subkat3;
$rs_s2=mysql_query("select * from tbl_base where CODE=".$ps_linkcode,$conn1);
	$rs_s=mysql_fetch_array($rs_s2);
	?>
	<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
		<TR class=f10 height=150>
			<td width=100 align=center >
				<?php
				$ps1=$rs_s['POSTER'];
				if ($ps1!=""){
					?>
					<a href="topic.php?type=show&code=<?php echo $ps_linkcode?>" title="<?php echo $rs_s['NAZV']?>">
					<?php echo smalleskiz($ps1,"������� �� ������� : ".$rs_s['NAZV']);?>
					</a>
					<?php
				}
				//��������:
				?>
			</TD>
			<td valign=middle>
				<?php echo $zl['108']?> <b><a href="topic.php?type=show&code=<?php echo $ps_linkcode?>" alt="<?php echo $rs_s['NAZV']?>"><?php echo $rs_s['NAZV']?></a></b> 
				<?php 
				if ($rs_s['RELEASE2']!="") echo '<font size=1>('.$rs_s['RELEASE2'].')</font>';
				echo '<br>';
				//������������:
				echo $zl['109'].'<b>';
				$ps1=$rs_s['SUBKAT1'];
				if ($ps1>0){
					$ps2=getsubkatname($ps1);
					?>
					<a class=link1 href="subkat.php?type=showsubkat&type2=<?php echo $ps1?>"><?php echo $ps2?></a>&nbsp;
					<?php
				}
				$ps1=$rs_s['SUBKAT2'];
				if ($ps1>0){
					$ps2=getsubkatname($ps1);
					?>
					<a class=link1 href="subkat.php?type=showsubkat&type2=<?php echo $ps1?>"><?php echo $ps2?></a>&nbsp;
					<?php
				}
				$ps1=$rs_s['SUBKAT3'];
				if ($ps1>0){
					$ps2=getsubkatname($ps1);
					?>
					<a class=link1 href="subkat.php?type=showsubkat&type2=<?php echo $ps1?>"><?php echo $ps2?></a>&nbsp;
					<?php
				}
				echo '</b><br>';
				//���� ����������:
				echo $zl['110'].' '.cdate($rs_s['DATEADD']).'<br>';
				//��� �������:
				echo $zl['111'];
				if ($rs_s['WHOADD']>0){
					//���������� � ������������
					?>
					<a href="user.php?type=show&code=<?php echo $rs_s['WHOADD']?>" title="<?php echo $zl['12']?>">
					<?php
					echo getuserlogin($rs_s['WHOADD']);
					echo '</a> ';
					$ps_israt=1;
					echo getstar(floor(getuserratings($rs_s['WHOADD'])*0.1));
					$ps_israt=0;
				}else{
					//�.�.
					echo $zl['112'];
				}
				echo '<br>';
				//������:
				//��
				echo $zl['113'].' '.$rs_s['RAZMER'].' '.$zl['114'].'<br>';
				//�������:
				echo $zl['115'].' '.$rs_s['VOTES'].'<br>';
				//���������...
				?>
				<a href="topic.php?type=show&code=<?php echo $ps_linkcode?>" alt="<?php echo $rs_s['NAZV']?>"><b><?php echo $zl['652']?></b></a>
			</TD>
		</TR>
		<?php
		//����� ������ ������� (���� ����)
		$pi1=getconf("ALSORAZD","VALUESTR");
		if ($pi1>0){
			?>
			<TR>
				<TD align=center class=f10b>
					<?php
					//���
					echo $zl['509'];
					?>
				</TD>
				<TD class=f8b>
					<?php
					if ($ps_subkat3==''){
						$ps_constr="select NAZV,CODE,RAZMER from tbl_base where ISMODER=1 and KAT=".$ps_kat3." order by DATEMODER desc limit 1, ".$pi1;
					}else{
						$ps_constr="select NAZV,CODE,RAZMER from tbl_base where ISMODER=1 and (SUBKAT1=".$ps_subkat3." or SUBKAT2=".$ps_subkat3." or SUBKAT3=".$ps_subkat3.") order by DATEMODER desc limit 1, ".$pi1;
					}
					$rs3_2 = mysql_query($ps_constr,$conn1);
						while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {
							$ps_nazv=$rs3['NAZV'];
							if (strlen($ps_nazv)>40) $ps_nazv=left_1($ps_nazv,40).'...';
							//������� �� �������
							$ps_tit=$zl['16']." :\n ".$rs3['NAZV']." /  ".$rs3['RAZMER']." ".$zl['114'];
							?>
							&middot; <a href="topic.php?type=show&code=<?php echo $rs3['CODE']?>" title="<?php echo $ps_tit?>"><?php echo $ps_nazv?></a><br>
							<?php
						}
					mysql_free_result($rs3_2);					
					?>
					<br>
				</TD>
			</TR>
			<?php
		}
		?>
	</TABLE>
	<?php
mysql_free_result($rs_s2);
return;
}

//============================================================================================================================================

function viewinfo_news($ps_linkcode, $ps_range){
global $conn1,$zcmas,$ps_israt,$ps_color,$zl,$zright,$ps_newsshort;

if ($ps_range==false || $ps_range=="") $ps_range=0;

$rs_s2=mysql_query("select * from tbl_news where CODE=".$ps_linkcode,$conn1);
	$rs_s=mysql_fetch_array($rs_s2);
	?>
	<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
		<TR class=f9b>
			<td valign=top>
				<?php
				//����:
				echo '&nbsp;&nbsp;'.$zl['117'];
				if ($ps_range==0) echo '  <b>'.$rs_s['NAZV'].'</b>  ';
				if ($ps_range!=0) echo '  <a href="subkat.php?type=shownews"><b>'.$rs_s['NAZV'].'</b></a>';

				?>
				<font size=1>
				<?php

				//��� �������: $zl['111'];
				echo '&nbsp;&nbsp;&nbsp;&nbsp; '.$zl['111'];
				if ($rs_s['WHOADD']>0){
					//���������� � ������������
					?>
					<a href="user.php?type=show&code=<?php echo $rs_s['WHOADD']?>" title="<?php echo $zl['12']?>">
					<?php
					echo getuserlogin($rs_s['WHOADD']);
					echo '</a> ';
				//	$ps_israt=1;
				//	echo getstar(floor(getuserratings($rs_s['WHOADD'])*0.1));
				//	$ps_israt=0;
				}else{
					//�.�.
					echo $zl['112'];
				}
				//���� ����������: 110
				echo ' ('.cdate($rs_s['DATEADD']).')';
				?>
				</font>

				<?php
				if ($ps_range==0) {

					if ($zright['DO_NEWS']==1) {
						//������������� �������
						//�������
						?>
						<br>
						 &nbsp;&nbsp;&nbsp;&nbsp;<font size=1>( <a href="topic.php?type=editnews&code=<?php echo $ps_linkcode?>" title="<?php echo $zl['118']?>"><?php echo $zl['119']?></a> / </font>
						 <font size=1><a href="topic.php?type=delnews&code=<?php echo $ps_linkcode?>" OnClick="return confirm('<?php echo $zl['415']?>?'); return true;" title="<?php echo $zl['416']?>"><?php echo $zl['414']?></a> )</font>
						<?php
					}


					?>

					<center>
					<TABLE cellSpacing=2 cellPadding=0 class=table_int_int_table width=98% border=0>
						<TR valign=top class=f10>
							<td width=10></td>
							<TD>
								
								<?php 
								$ps1=$rs_s['OPIS'];
								$pb1=0;
								if (strlen($ps1)>256 && $ps_newsshort==1){
									$ps1=left_1($ps1,256);
									$pb1=1;
								}
								$ps1=str_replace(chr(13),"<br>",$ps1);
								echo $ps1;
								if ($pb1==1){
									//������ �����
									?>
									 ...  (<a href="subkat.php?type=shownews"><?php echo $zl['551']?></a>)
									<?php
								}
								
								?>
							
							</TD>
							<td width=10></td>
						</TR>
					</TABLE>		
					</center>
				<?php
				}
				?>
				
			</TD>
		</TR>
	</TABLE>
	<?php
mysql_free_result($rs_s2);
return;
}


function viewcategory($ps_name){
global $ps_color;
	$ps_icon="other";

	if ($ps_name=="�����") $ps_icon = "video";
	if ($ps_name=="HD-Video") $ps_icon= "video_hd";
	if ($ps_name=="����") $ps_icon= "games";
	if ($ps_name=="������") $ps_icon= "music";
	if ($ps_name=="���������") $ps_icon= "soft";

	if ($ps_name=="����� � ������") $ps_icon= "books_and_other";
	if ($ps_name=="����������") $ps_icon= "persona";
	if ($ps_name=="������� �������") $ps_icon= "news";

	$filename_ico = 'main/color/scheme/'.$ps_color.'/img_tab/'.$ps_icon.'.png';
	if ( file_exists($filename_ico) )
	{
	?>
	
	<TD align=right valign=middle height=20>
		<img src="<?php echo $filename_ico?>" alt="<?php echo $ps_name?>" border=0 height=20 vspace=0 hspace=0 align="absmiddle">
	</TD>
	<?php
	}
return;
}

function pan_search(){
global $zcmas,$ps_color,$zl,$zright;
?>
<TR class=f10 height=16>
	<td>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
			<TR class=f10 height=16>
				<td width=25 align=center>
					<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon_search.png" width=16 height=16>
				</TD>
				<td><font color="<?php echo $zcmas[50]?>">
					<b><?php echo $zl['66']?></b>
				</font>
				</TD>
				<?php viewcategory("�����"); ?>
			</TR>
		</TABLE>
	</TD>
</TR>
<?php
return;
}

//============================================================================================================================================
?>