<?php

$txcode1 = preg_replace("#(.*)\/(.*)\/(.*)\.png#i", "$2", $_SERVER['REQUEST_URI']);

$txcode = preg_replace("#(.*)\/(.*)\.png#i", "$2", $_SERVER['REQUEST_URI']);
$txcode = trim(substr(trim($txcode), 0, 10));
if (! is_numeric($txcode)) { die("Invalid user_id or hacking attempt."); }

if (! is_numeric($txcode1) || $txcode1=="0" ) { $txcode1 = rand(1,8); }


require_once('main/config/functlist.php' );
openconn1();
global $txcode, $tx, $font, $fontsize, $cx, $cy, $im;

// $text = $_GET['text'];

$rs_2=mysql_query("select RATINGS, DOWNHIM, ALTLINKS, LINKS, DOWNUS, VOTES from tbl_user where CODE=".$txcode,$conn1);
$rs=mysql_fetch_array($rs_2);
	mysql_free_result($rs_2);	

$im = imagecreatefrompng("module/inwm_ks/ub/$txcode1.png"); //png picture
$font = "module/inwm_ks/ub/ub.ttf"; //font file

$color_bl = imagecolorallocate($im, 0, 0, 0);
$color_w = imagecolorallocate($im, 255, 255, 255);

//$color_r = imagecolorallocate($im, 255, 0, 0);
//$color_g = imagecolorallocate($im, 0, 255, 0);

$color_r = imagecolorallocate($im, 255, 158, 158);
$color_g = imagecolorallocate($im, 187, 255, 198);

$color_b = imagecolorallocate($im, 0, 0, 255);
$color_gr = imagecolorallocate($im, 100, 100, 100);
$color_or = imagecolorallocate($im, 255, 164, 0);

// ������� ������� ������, �� ����
$fontsize = 12; //font size
//$cx=6;	//��������� X
$cy=14;
//$tx = "InWM";
//$color=$color_gr;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

$cx=0;
$tx = $rs['RATINGS']; if ($tx=='' || $tx==0) $tx=0;
$color=$color_or;
$cx=350-(sized($fontsize,$cx,$tx, $font))-4;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);

// ������, ������
$fontsize = 8; //font size
$cx=80;
$ctx=$cx;
$cy=13;
$tx = "U:";
$color=$color_g;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$tx = $rs['LINKS']; if ($tx=='' || $tx==0) $tx=0;
$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

//$tx = "/ P:";
//$color=$color_g;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = recordcount_new("tbl_persona where ISMODER=1 and ISDOPEDIT=0 and WHOADD=".$txcode); if ($tx=='' || $tx==0) $tx=0;
//$color=$color_w;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

$tx = "+";
$color=$color_g;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$tx = $rs['ALTLINKS'];  if ($tx=='' || $tx==0) $tx=0;
$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

$tx = "+";
$color=$color_g;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$tx = $rs['DOWNUS']; if ($tx=='' || $tx==0) $tx=0;
$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

//$tx = " VTS:";
//$color=$color_g;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = $rs['VOTES']; if ($tx=='' || $tx==0) $tx=0;
//$color=$color_w;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);


// �������
$cx=$ctx+102;
//$cy+=8;
$tx = "D:";
$color=$color_r;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$tx = $rs['DOWNHIM']; if ($tx=='' || $tx==0) $tx=0;
$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);


$cx=$ctx+142;
$tx = "RATIO:";
$color=$color_or;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = ($rs['LINKS'] + $rs['DOWNUS']) / $rs['DOWNHIM'];
$tx = number_format( ( $rs['LINKS'] + $rs['ALTLINKS'] + $rs['DOWNUS']) / $rs['DOWNHIM'], 2, '.', '');

$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);


header('Content-type: image/png');
imagepng($im);
imagedestroy($im);


function sized($size, $cx, $text, $fontfile)
	{
	$bbox = imagettfbbox($size, 0, $fontfile, $text); //calculate the pixel of the string
	$cx = $cx + abs($bbox[4] - $bbox[0])+2;
	return $cx;
	}
function imagettftextoutline($sig,$size,$angle,$x,$y,$col,$outlinecol,$fontfile,$text, $width){
	for($xc=$x-$width; $xc<=($x+$width); $xc++){
     	for ($yc=$y-$width; $yc<=($y+$width); $yc++){
			imagettftext($sig ,$size ,$angle,$xc ,$yc, $outlinecol ,$fontfile ,$text);
		}
	}
	imagettftext($sig,$size,$angle,$x,$y,$col,$fontfile,$text);
}



?>