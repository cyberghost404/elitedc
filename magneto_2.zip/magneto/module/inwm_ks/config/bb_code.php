<?php

function regex_tag($text, $ps_cod){
	$ps_c=rand(1,25000);
        //spoiler
        while ( preg_match( "#\[spoiler(.*?)\](.+?)\[/spoiler\]#is", $text ) )
        {            
        	$text = preg_replace( "#\[spoiler(.*?)\](.+?)\[/spoiler\]#ies", "regex_expand_tag( '\\2', '\\1', $ps_cod+$ps_c)", $text );
//		$ps_c=$ps_c*25000;
       	}
return $text;
}

function regex_expand_tag($content, $option, $ps_ddiv){

        if($option=="")
        {
            $option = "������� �����";
        }
        else
        {
            $option = substr($option,1);
            $option = stripslashes($option); 
        }
        $content = stripslashes($content);        

	$ps_ddiv=$ps_ddiv.rand(1,25000);

return "<TABLE cellSpacing=1 cellPadding=0 width=100% class=table_int_table border=0><TR><TD class=f8>".
"<div id='".$option.$ps_ddiv."_show' ".regex_expand_disp2($option.$ps_ddiv)." onClick=\"javascript:showel('mg_".$option.$ps_ddiv."'); javascript:hideel('".$option.$ps_ddiv."_show');javascript:showel('".$option.$ps_ddiv."_hide');\" style='cursor: pointer;'><div class='folded'>".$option."</div></div>".
"<div id='".$option.$ps_ddiv."_hide' ".regex_expand_disp1($option.$ps_ddiv)." onClick=\"javascript:hideel('mg_".$option.$ps_ddiv."'); javascript:hideel('".$option.$ps_ddiv."_hide');javascript:showel('".$option.$ps_ddiv."_show');\" style='cursor: pointer;'><div class='unfolded'>".$option."</div></div>".
"<div id='mg_".$option.$ps_ddiv."' ".regex_expand_disp1($option.$ps_ddiv)."><TABLE cellSpacing=1 cellPadding=0 class=table_int_int_table2 width=100% border=0><TR><TD class=f9>".$content."</TD></TR></TABLE></div>".
"</TD></TR></TABLE>";		
}

function regex_expand_disp1($ps_dddiv){
    if (requestcookie("mg_".$ps_dddiv)!=1) {
        return "style='display:none'";
    } else {
        return "";
        }
}
function regex_expand_disp2($ps_dddiv){
    if (requestcookie("mg_".$ps_dddiv)==1) {
        return "style='display:none'";
    } else {
        return "";
        }
}



function regex_badtag($text){

	$text = eregi_replace( "\\<table(.*)\\>", " ", $text );
	$text = eregi_replace( "\\<\/table\\>", " ", $text );
	$text = eregi_replace( "\\<tr(.*)\\>", " ", $text );
	$text = eregi_replace( "\\<\/tr\\>", " ", $text );
	$text = eregi_replace( "\\<td(.*)\\>", " ", $text );
	$text = eregi_replace( "\\<\/td\\>", " ", $text );
	$text = eregi_replace( "\\<(.*)strong\\>", "<\\1s>", $text );

	$text = eregi_replace( "\\<em\\>", " ", $text );
	$text = eregi_replace( "\\<\/em\\>", " ", $text );

//	$text = eregi_replace( "\\<(.*)p\\>", " ", $text );

	$text = eregi_replace( "\\[(.*)\\]", " ", $text );

	$text = eregi_replace( "\\<span (.*)\\>", " ", $text );
	$text = eregi_replace( "\\</span\\>", " ", $text );
	$text = eregi_replace( "\\<hr\\>", " ", $text );
	$text = eregi_replace( "\\[hr\\]", " ", $text );

//	$text = eregi_replace( "\\<br /\\>", "<br>", $text );

	$text = eregi_replace( "\\<var class(.*)\\>", " ", $text );
	$text = eregi_replace( "\\<img class(.*)\\>", " ", $text );
	$text = eregi_replace( "\\<\/var\\>", " ", $text );
	$text = eregi_replace( "\\<img (.*)\\>", " ", $text );

	$text = eregi_replace("\\[spoiler=(.*)\\](.*)\\[/spoiler\\]"," ",$text);
	$text = eregi_replace( "////", "/", $text );


return $text;
}
function regex_badtag2($text){
	$text = eregi_replace( "\\<em\\>", " ", $text );
	$text = eregi_replace( "\\<\/em\\>", " ", $text );

	$text = eregi_replace( "\\(", " , ", $text );
	$text = eregi_replace( "\\)", " ", $text );

	$text = eregi_replace( "/", ", ", $text );

	$text = str_replace( "<", ", ", $text );
	$text = str_replace( ">", ", ", $text );
	$text = str_replace( "[b]", ", ", $text );
	$text = str_replace( "[/b]", ", ", $text );
	$text = str_replace( ":", ", ", $text );

	$text = eregi_replace( "\\[", ", ", $text );
	$text = eregi_replace( "\\]", ", ", $text );

//	$text = eregi_replace( "\\<span style=(.*)\\>", " ", $text );
//	$text = eregi_replace( "\\<span class=(.*)\\>", " ", $text );
//	$text = eregi_replace( "<\\/span\\>", " ", $text );

//	$text = eregi_replace( "\\font(.*)\\>", " ", $text );
//	$text = eregi_replace( "\\<(.*)font\\>", " ", $text );
//	$text = eregi_replace( "\\<(.*)\\>", "\\1, ", $text );
//	$text = eregi_replace( "\\\", ", ", $text );
//	$text = eregi_replace( "//", " , ", $text );


return $text;
}


function regex_tag2($rs_opis, $ps_code1, $conn11, $txtfind, $privyazka){

	//�������� �������� ���������� �� ������
        //������ ������� ������
	//�������� � ������ �� �������
        
        $txtpers="";
	$rs_opis2 = $rs_opis;
	$rs_opis2 = str_replace( chr(13),"<br>",$rs_opis);

//	$rs_opis2 = regex_badtag($rs_opis);
//	$rs_opis2 = regex_badtag2($rs_opis2);

        if ( $txtfind != "all" && strstr( $rs_opis, $txtfind) )
	{
		$txtpers = " ".substr($rs_opis2, strpos($rs_opis2,$txtfind)+strlen($txtfind)+2 );		//������ �� � ����� � �����

		if ( strstr($txtpers, "<b") ) {
			$txtpers = substr($txtpers,0,strpos($txtpers, "<b") );
		} elseif ( strstr($txtpers,".") ) {
			$txtpers = substr($txtpers,0,strpos($txtpers, ".") );
		} else {
			$txtpers = substr($txtpers,0 );
		}
	}
	if ( $txtfind=="all" )
	{
		$txtpers = $rs_opis2;
	}

	$txtpers = regex_badtag2($txtpers);

	if ($txtpers!="") {

//	echo $txtpers."<br><br>";

	$arr_pers=explode(',',$txtpers);
	$cnt=sizeof($arr_pers);
	$cnt_i=1;
		foreach ($arr_pers as $str) {
		$str=trim($str);
			$rs2_3=mysql_query("select CODE, NAZV, NAZVROD from tbl_persona where NAZV like '%".$str."%' ",$conn11);
				$rs3=mysql_fetch_array($rs2_3);
					if ($rs3['CODE']>0 && $rs3['NAZV']==$str ){

					$str2='<a href="persona.php?type=show&code='.$rs3['CODE'].'" title="�������� ����������" ><i>'.$str.'</i></a>';
					$rs_opis = str_replace($str,$str2,$rs_opis);

					if ($privyazka == 1) {
					//��������, ��������� �� ��� ���������� � �������, ���� ��� - ��������.
					$rs2_4=mysql_query("select CODE from tbl_cross2 where secondcode=".$ps_code1." and firstcode=".$rs3['CODE'],$conn11);
						$rs4=mysql_fetch_array($rs2_4);
						if($rs4['CODE']==null || $rs4['CODE']==0) {
							$sql="delete from tbl_cross2 where SECONDCODE=".$ps_code1." and FIRSTCODE=".$rs3['CODE'];
							mysql_query( $sql,$conn11);
							//��������� ������
							$sql="insert into tbl_cross2 (secondcode,firstcode) values(".$ps_code1.",".$rs3['CODE'].")";
							mysql_query( $sql,$conn11);
							$sql="update tbl_persona set LINKS=(LINKS+1) where CODE=".$rs3['CODE'];
							mysql_query( $sql,$conn11);
						}
					}

					}else{
					//	echo $str;
					}
			//	if ($cnt_i<$cnt) echo ', ';
			mysql_free_result($rs2_3);

			$rs2_3=mysql_query("select CODE, NAZV, NAZVROD from tbl_persona where NAZVROD like '%".$str."%' ",$conn11);
				$rs3=mysql_fetch_array($rs2_3);
					if ($rs3['CODE']>0 && $rs3['NAZVROD']==$str ){

					$str2='<a href="persona.php?type=show&code='.$rs3['CODE'].'" title="View Personal Info" ><i>'.$str.'</i></a>';
					$rs_opis = str_replace($str,$str2,$rs_opis);

					if ($privyazka == 1) {
					//��������, ��������� �� ��� ���������� � �������, ���� ��� - ��������.
					$rs2_4=mysql_query("select CODE from tbl_cross2 where secondcode=".$ps_code1." and firstcode=".$rs3['CODE'],$conn11);
						$rs4=mysql_fetch_array($rs2_4);
						if($rs4['CODE']==null || $rs4['CODE']==0) {
							$sql="delete from tbl_cross2 where SECONDCODE=".$ps_code1." and FIRSTCODE=".$rs3['CODE'];
							mysql_query( $sql,$conn11);
							//��������� ������
							$sql="insert into tbl_cross2 (secondcode,firstcode) values(".$ps_code1.",".$rs3['CODE'].")";
							mysql_query( $sql,$conn11);
							$sql="update tbl_persona set LINKS=(LINKS+1) where CODE=".$rs3['CODE'];
							mysql_query( $sql,$conn11);
						}
					}

					}else{
					//	echo $str;
					}
			//	if ($cnt_i<$cnt) echo ', ';
			mysql_free_result($rs2_3);

			$cnt_i++;
		}
	}
	return $rs_opis;
}
												

?>
