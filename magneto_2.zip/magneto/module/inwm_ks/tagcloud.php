<?php
//require_once('main/config/functlist.php');
//openconn1();
//verifyuser();

//============================================================================================================================================
?>
<HTML>
<HEAD>
	<TITLE><?php echo getconf("PROJECTNAME","VALUESTR").' - '.$zl['4012'] ?></TITLE>
	<?php site_header()?>
</HEAD>
<BODY leftMargin=0 topMargin=0>
<?php 
if ($ps_style=="") require_once('inc_top.php');
?>	
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	<TR valign=top>
		<?php 
		if ($ps_style=="") {
			if (getconf("ISWORK","VALUEINT")==1){
				require_once('inc_left.php');
			}
		}
		?>

		<TD class=f10>
    		<?php
    		//===========================================================================================
   			//�������� ��������
			?><TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0><TR><TD><?php
    		us_text($zl['668']);   
			?></TD></TR></TABLE>
					<br>
			<?php
				//������ �����
				if (getconf("ISTAGS","VALUEINT")==1){
				?>
					<TABLE class=table_int_table width="650" border=0 align=center valign=middle><TR><TD><center>

					<div id="flashcontent"></div>
					<script type="text/javascript" src="main/config/swfobject.js"></script>
					<script type="text/javascript">
					var so = new SWFObject("main/config/tagcloud.swf", "tagcloud", "648", "600", "3", "#ffffff");
					// uncomment next line to enable transparency
					so.addParam("wmode", "transparent");
					so.addVariable("tcolor", "0x000000");
					so.addVariable("mode", "tags");
					so.addVariable("distr", "true");
					so.addVariable("tspeed", "40");
					so.addVariable("tagcloud", "<tags><?php
					//��������� ����
					$ps_col=$zcmas[10];
					$ps_col=str_replace("#","",$ps_col);
					//�������� ����������� ����������
					$ps_koef=1; 
					$rs_2 = mysql_query("select tbl_base.DOWN as b_DOWN from tbl_tags,tbl_base where tbl_tags.BASECODE=tbl_base.CODE and tbl_base.ISMODER=1 order by tbl_base.DOWN desc limit 1",$conn1);
						$rs=mysql_fetch_array($rs_2);
						$ps_koef=$rs['b_DOWN'];
					mysql_free_result($rs_2);		
					$ps_koef2=40;
					$ps_koef3=$ps_koef2/$ps_koef;
					$rs_2 = mysql_query("select tbl_base.DOWN as b_DOWN, tbl_base.CODE as b_CODE, tbl_base.NAZV as b_NAZV from tbl_tags,tbl_base where tbl_tags.BASECODE=tbl_base.CODE and tbl_base.ISMODER=1",$conn1);
						while (($rs=mysql_fetch_assoc($rs_2))!==false){
							$ps_size=ceil($rs['b_DOWN']*$ps_koef3);
				//			if ($ps_size<2) $ps_size=2;
				//			if ($ps_size>9) $ps_size=9;
							$ps_size=5;
		                 			$nazv=$rs['b_NAZV'];
									str_replace("&", " ", $nazv);
				//	                $n_len=26;  //����. ���-�� ��������
		        //          			if ( strlen($rs['b_NAZV'])>$n_len ) $nazv=substr($rs['b_NAZV'], 0, $n_len)."...";
		        //          			echo "<a href='topic.php?type=show%26code=".$rs['b_CODE']."' color='0x".rand(3,15)."f".rand(1,15)."f".rand(1,15)."f' style='$ps_size' alt='ALT' title='TITLE'>".$nazv."</a>";



					echo "<a href='topic.php?type=show%26code=".$rs['b_CODE']."' color='0x".rand(3,15)."f".rand(1,15)."f".rand(1,15)."f' style='$ps_size' alt='ALT' title='TITLE'>".$rs['b_NAZV']."</a>";
						}
					mysql_free_result($rs_2);		
					?></tags>");
					so.write("flashcontent");
					</script>
					
					</center></TD></TR></TABLE>
				<?php
				} else {
					echo '��������� ���������������';
				}
				?>
    	</TD>
	<?php 
	$ps_tagcloudfull="1";
	if ($ps_style=="") require_once('inc_right.php');
	$ps_tagcloudfull=false;
	?>

	</TR>
</TABLE>
<?php 
if ($ps_style=="") require_once('inc_down.php');
mysql_close($conn1);
?>	
</body>
</html>