<?php
//require_once('main/config/functlist.php' );
global $ps_menukat;
openconn1();

iswork();

require_once('config/bb_code.php' );
require_once('inc_katfunct.php' );

// �������������� �������� ������� "�� ����"
if ($ps_type=="flyedit") {
	verifyuser();

	if ($ps_step=="2"){
		$ps_opis=requestdata("opis");
		$ps_opis=$opis;	
		$ps_code=requestdata("code");
		$rs_2=mysql_query("select OPIS from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);

	//�������� � ����

		//��������� ����� ��������
		if ($ps_opis != $rs['OPIS']) $rs_2=mysql_query("delete OPIS from tbl_base where CODE=".$ps_code,$conn1);

		if ($ps_opis != "") $rs_2=mysql_query("update tbl_base set OPIS='".$ps_opis."' where CODE=".$ps_code,$conn1);
		if ($ps_opis == "") $rs_2=mysql_query("update tbl_base set OPIS='".$rs['OPIS']."' where CODE=".$ps_code,$conn1);

		mysql_free_result($rs_2);
		goback();
	}

	if ($ps_step==""){
	windowsize (600,800);
	header("Content-type: text/html; Charset=Windows-1251");

	$pi1=0;
	$rs_2=mysql_query("select * from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['WHOADD']==$ps_usercode) $pi1=1;

	if ($pi1==0 && $zright['DO_MODER']!=1) {
		header("Location: index.php");
		exit;
	}


	?>
	<HEAD>
	<?php
	site_header();
	?>
	</HEAD>
	<BODY leftMargin=0 topMargin=0>
	<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 bgcolor="<?php echo $zcmas[4]?>" align="center" valign="middle">
		<TR>
		<TD class="table_leftmenu_user_menu">
			<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top bgcolor="<?php echo $zcmas[2]?>">
				<?php
//				echo 'Fly Post Editor by SCALOlaz (�������������� �������� �� ����).<br><br>';
				echo '<br><center><font size=2><b>��������!!!</b> �� ��������� ������ ������, ������� ���������� ����� � ����� ������!<br></font></center>';
				?>
		<form method="post" name="frmlogin" action="topic.php" border=0>
			<input type="hidden" name="type" value="<?php echo $ps_type?>">
			<input type="hidden" name="step" value="2">
			<input type="hidden" name="code" value="<?php echo $ps_code?>">

			<?php
			$ps_istiny=getconf("ISTINY_TOPIC","VALUEINT");	
			if ($ps_istiny==1){
				?>
				<script type="text/javascript" src="main/config/tiny_mce/tiny_mce.js"></script>
				<script type="text/javascript">
				tinyMCE.init({
					// General options
					mode : "textareas",
					//theme : "simple",
					theme : "advanced",
					force_br_newlines : true,
					plugins : "save,advhr,advimage,advlink,iespell,inlinepopups,media,contextmenu,paste,directionality,xhtmlxtras,imagemanager,filemanager,template",
					editor_deselector : "mceNoEditor",
													
					// Theme options
					theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,fontselect,fontsizeselect,|,bullist,numlist,hr,|,undo,redo,|,link,unlink,image,code,forecolor,backcolor,charmap,template",
					theme_advanced_buttons2 : "",
					theme_advanced_buttons3 : "",
					theme_advanced_toolbar_location : "top",
					theme_advanced_toolbar_align : "left",
					theme_advanced_statusbar_location : "bottom",
					theme_advanced_resizing : true,
					// Office example CSS
					content_css : "css/office.css",

					// Drop lists for link/image/media/template dialogs
					template_external_list_url : "js/template_list.js",
					external_link_list_url : "js/link_list.js",
					external_image_list_url : "js/image_list.js",
					media_external_list_url : "js/media_list.js",

					// Replace values for the template plugin
					template_replace_values : {
						username : "Magneto",
						staffid : "4732893875"
					}
				});
				</script>
				<center>
				<textarea name="opis" style="width:100%; height=400"><?php echo $rs['OPIS'];?></textarea>
				</center>
				<?php
			}else{
				?>
				<script type="text/javascript">
				tinyMCE.init({
					// General options
					mode : "textareas",
					//theme : "simple",
					theme : "advanced",
					force_br_newlines : true,
					plugins : "save,advhr,advimage,advlink,iespell,inlinepopups,media,contextmenu,paste,directionality,xhtmlxtras,imagemanager,filemanager,template",
					editor_deselector : "mceNoEditor",
													
					// Theme options
					theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,fontselect,fontsizeselect,|,bullist,numlist,hr,|,undo,redo,|,link,unlink,image,code,forecolor,backcolor,charmap,template",
					theme_advanced_buttons2 : "",
					theme_advanced_buttons3 : "",
					theme_advanced_toolbar_location : "top",
					theme_advanced_toolbar_align : "left",
					theme_advanced_statusbar_location : "bottom",
					theme_advanced_resizing : true,

					// Office example CSS
					content_css : "css/office.css",

					// Drop lists for link/image/media/template dialogs
					template_external_list_url : "js/template_list.js",
					external_link_list_url : "js/link_list.js",
					external_image_list_url : "js/image_list.js",
					media_external_list_url : "js/media_list.js",

					// Replace values for the template plugin
					template_replace_values : {
						username : "Magneto",
						staffid : "4732893875"
					}
				});
				</script>
				<center>
				<textarea class=TEXTAREA1 name="opis" cols="107" rows="20"><?php echo $rs['OPIS'];?></textarea>
				</center>
			<?php
			}
			?>
			<br><center>
			<?php
			inputstyle($zl['70']);//��������
			?>
			</center><br>
		</form>
			</TABLE>
			</TD>
			</TR>			
		</TABLE>
		</BODY>
		<?php

	//	$ps_opis=$_POST("opis");
	//	$rs_2=mysql_query("delete OPIS from tbl_base where CODE=".$ps_code,$conn1);
	//	$rs_2=mysql_query("update tbl_base set OPIS='".$ps_opis." +1 ' where CODE=".$ps_code,$conn1);
		mysql_free_result($rs_2);
		exit;
	}
}

//======================================================================================================
if ($ps_type=="download"){
	verifyuser();
	$pi1=$ps_usercode;
	if (getconf("ISSHOWLINKTOUNREG","VALUEINT")!=1){
		dopverify2(1);
	}else{
		if ($pi1=='') $pi1=-1;
	}
	$pi4=0;
	//���� ��� ���� ��� ����� ��� �������, �� �� ���������
	if (recordcount_new("tbl_stat where USERCODE=".$pi1." and LINKCODE=".$ps_code)>0) $pi4=1;
	if ($pi4==0){
		//� ������� �����
		$rs_s2=mysql_query("insert into tbl_stat (USERCODE,LINKCODE,DATESTAT,USERIP) values (".$pi1.",".$ps_code.",'".sqldatetime2(mktime())."','".$_SERVER["REMOTE_ADDR"]."')",$conn1);
		//tbl_link - ������
		$rs_s2=mysql_query("update tbl_link set DOWN=(DOWN+1) where CODE=".$ps_code,$conn1);	
		//tbl_base - �������
		$rs_2=mysql_query("select BASECODE from tbl_link where CODE=".$ps_code,$conn1);
			$rs=mysql_fetch_array($rs_2);
			$ps_bc=$rs['BASECODE'];
			$rs_s2=mysql_query("update tbl_base set DOWN=(DOWN+1) where CODE=".$ps_bc,$conn1);
		mysql_free_result($rs_2);		
		$pi_rat_down=getconf("RAT_DOWN","VALUESTR");
		//tbl_user - ������������
		$rs_2=mysql_query("select WHOADD from tbl_link where CODE=".$ps_code,$conn1);
			$rs=mysql_fetch_array($rs_2);
			$rs_s2=mysql_query("update tbl_user set DOWNUS=(DOWNUS+1),RATINGS=(RATINGS+".$pi_rat_down.") where CODE=".$rs['WHOADD'],$conn1);
		mysql_free_result($rs_2);		
		//tbl_user - ���� �����
		if ($pi1!=-1){
			$rs_s2=mysql_query("update tbl_user set DOWNHIM=(DOWNHIM+1),RATINGS=(RATINGS-".$pi_rat_down.") where CODE=".$pi1,$conn1);
		}
	}
	exit;
}
//======================================================================================================

verifyuser();

if ($ps_type=="download2"){
	if (getconf("ISSHOWLINKTOUNREG","VALUEINT")!=1) dopverify2(1);
}


if ($ps_type=="favadd" || $ps_type=="favdel") dopverify2(1);
if ($ps_type=="addcomment" || $ps_type=="delcomment" || $ps_type=="addposter" || $ps_type=="new" || $ps_type=="newpre" || $ps_type=="new2" ||$ps_type=="delete" || $ps_type=="edit" || $ps_type=="vote" || $ps_type=="delposter" || $ps_type=="addcross" || $ps_type=="addcrosspersona" || $ps_type=="altlink" || $ps_type=="altlink2") dopverify("DO_ADD");
if ($ps_type=="moderdop" || $ps_type=="moderyes" || $ps_type=="moderdop2" || $ps_type=="moderno" || $ps_type=="flyedit") dopverify("DO_MODER");
if ($ps_type=="tagsadd" || $ps_type=="tagsdel" || $ps_type=="videoarcdel"  || $ps_type=="videoarcadd") dopverify("DO_SET");
if ($ps_type=="newnews" || $ps_type=="delnews" || $ps_type=="newnews2" || $ps_type=="editnews2") dopverify("DO_NEWS");
if ($ps_type=="showeskiz" || $ps_type=="moderdop" || $ps_type=="addposter" || $ps_type=="addcross" || $ps_type=="addcrosspersona" || $ps_type=="altlink" || $ps_type=="altlink2" || $ps_type=="showtube" || $ps_type=="download2") $ps_style="short";

if ($ps_type=="altlink" || $ps_type=="altlink2") {
	if (getconf("ISADDALTLINKS","VALUEINT")==0){
		header("Location: index.php");exit;	
	}
	$pi1=getconf("RATFORLINKS","VALUESTR");
	$pi2=getuserratings($ps_usercode);
	if ($zright['DO_MODER']==1) $pi2=$pi1;
	if ($pi2<$pi1){
		header("Location: index.php");exit;	
	}
}

if ($ps_type=="addcomment" || $ps_type=="delcomment"){
	if ($ps_comment!=1 && maycomment($ps_usercode)==1){
		header("Location: index.php");
		exit;
	}
}
if ($ps_type=="newnews2") {
	if (getconf("ISNEWS","VALUEINT")==0){
		header("Location: index.php");exit;	
	}
}
if ($ps_type=="editnews2"){
	if (getconf("ISNEWS","VALUEINT")==0){
		header("Location: index.php");exit;	
	}
}

if ($ps_type=="showtube"){
	if (getconf("ISTUBE","VALUEINT")==0){
		header("Location: index.php");exit;	
	}
	if (recordcount_new("tbl_tube where BASECODE=".$ps_code." and ISMODER=1")==0){
		header("Location: index.php");exit;	
	}
}

//���������� ���� - ���������� ������ � ����� ����
//=========================================================================================
if ($ps_type=="new_pre2"){
	$ps1=getconf("MINTOSEARCH","VALUESTR");
	if ($ps1=='') $ps1="5";
	$ps1=$ps1-1;
	$ps_test=requestdata('stest');
	$ps_test=iconv("utf-8", "cp1251", $_GET['stest']);
	if ($ps_test=='���') $ps_search=iconv("utf-8", "cp1251", $_GET['search']);
	if (strlen($ps_search)>$ps1){
		header("Content-type: text/html; Charset=Windows-1251"); 
		if (recordcount_new("tbl_base where ISMODER=1 and NAZV LIKE '%".$ps_search."%'")>0){
			?>
			<TABLE cellSpacing=0 cellPadding=0 height=5 valign=top border=0>
				<TR height=100%>
					<td>
					</td>
				</TR>
			</TABLE>
			<TABLE cellSpacing=0 cellPadding=0 width=219 border=0 valign=top border=0>
				<TR>
					<TD width=8>
					</TD>
					<TD class=table_leftmenu_user_menu>
						<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
							<?php
							$rs2_2 = mysql_query("select * from tbl_base where ISMODER=1 and NAZV like '%".$ps_search."%' order by NAZV limit 10",$conn1);
								while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
									$ps1=$rs2['NAZV'];
									if (strlen($ps1)>25){
										$ps1=left_1($ps1,25).'...';
									}
									?>
									<TR valign=top>
										<TD width=5>
										</TD>
										<TD class=f8>
											<a class=link1 href="topic.php?type=show&code=<?php echo $rs2['CODE']?>" title="<?php echo $rs2['NAZV']?>"><?php echo $ps1?></a>
										</TD>
										<TD width=5>
										</TD>
									</TR>								
									<?php
								}
							mysql_free_result($rs2_2);		
							?>
						</TABLE>
					</TD>
					<TD width=8>
					</TD>
				</TR>			
			</TABLE>
			<?php
		}
	}
	exit;
}

//��������� 24/7
//=========================================================================================
if ($ps_type=="videoarcadd" && getconf("VIDEOARC","VALUEINT")=="1"){
	$ps_constr="update tbl_base set INVIDEOARC=1 where CODE=".$ps_code;
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: topic.php?type=show&code=".$ps_code);exit;
}

//������� 24/7
//=========================================================================================
if ($ps_type=="videoarcdel" && getconf("VIDEOARC","VALUEINT")=="1"){
	$ps_constr="update tbl_base set INVIDEOARC=0 where CODE=".$ps_code;
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: topic.php?type=show&code=".$ps_code);exit;
}


//���������� ���� - ����������� ������ ����������
//=========================================================================================
if ($ps_type=="new_pre"){
	//����� ����������� ����� ������
	$ps_test=requestdata('stest');
	$ps_test=iconv("utf-8", "cp1251", $_GET['stest']);
	if ($ps_test=='���') $ps_search=iconv("utf-8", "cp1251", $_GET['search']);
	if (strlen($ps_search)>$ps2){
		header("Content-type: text/html; charset=windows-1251"); 
		if (recordcount_new("tbl_base where ISMODER=1 and NAZV LIKE '%".$ps_search."%'")>0){
			//� ���� ��� ���� �������
			echo "<b>".$zl['393']."</b>:";
			echo '<br><hr>';
			$rs2_2 = mysql_query("select * from tbl_base where ISMODER=1 and NAZV like '%".$ps_search."%' order by NAZV limit 15",$conn1);
				while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
					//����������� �������
					//���������
					//��� �������
					//���������� � ������������
					//���� ����������
					?>
					&bull; <a href="topic.php?type=show&code=<?php echo $rs2['CODE']?>" title="<?php echo $zl['160']?>"><?php echo $rs2['NAZV']?></a>
					<font size=1>- <?php echo $zl['175']?>: <?php echo getkatname($rs2['KAT'])?> - <?php echo $zl['279']?>:
					<a href="user.php?type=show&code=<?php echo $rs2['WHOADD']?>" title="<?php echo $zl['12']?>"><?php echo getuserlogin($rs2['WHOADD'])?></a>
					- <?php echo $zl['280']?>: <?php echo cdate($rs2['DATEADD'])?></font>
					<br>
					<?php
				}
			mysql_free_result($rs2_2);		
			echo '<hr>';
		}
	}
	exit;
}


//��������� - ���� �� ����� ������� ������
//=========================================================================================
if ($ps_type=="edit" || $ps_type=="show"){
	if (recordcount_new("tbl_base where CODE=".$ps_code)==0){
		header("Location: index.php");exit;
	}
}

//��������� ��� ����������
//=========================================================================================
if ($ps_type=="favadd"){
	$ps_constr="insert into tbl_fav (USERCODE,BASECODE,DATELAST) values (".$ps_usercode.",".$ps_code.",NOW())";
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: topic.php?type=show&code=".$ps_code);exit;
}

//������� �� ����������
//=========================================================================================
if ($ps_type=="favdel"){
	$ps_constr="delete from tbl_fav where BASECODE=".$ps_code." and USERCODE=".$ps_usercode;
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: topic.php?type=show&code=".$ps_code);exit;
}

//��������� � ������ �����
//=========================================================================================
if ($ps_type=="tagsadd" && getconf("ISTAGS","VALUEINT")==1){
	$ps_constr="insert into tbl_tags (BASECODE) values (".$ps_code.")";
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: topic.php?type=show&code=".$ps_code);exit;
}

//������� �� ������ �����
//=========================================================================================
if ($ps_type=="tagsdel"  && getconf("ISTAGS","VALUEINT")==1){
	$ps_constr="delete from tbl_tags where BASECODE=".$ps_code;
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: topic.php?type=show&code=".$ps_code);exit;
}


//������� ����������� �������
//=========================================================================================
if ($ps_type=="delete"){
	$rs_2=mysql_query("select WHOADD from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['WHOADD'];
	mysql_free_result($rs_2);
	if (($ps1==$ps_usercode && $zright['DO_DELSVOI']==1) || $zright['DO_MODER']==1){
		$ps_type="moderno";
		$ps_type2="delete";
	}else{
		header("Location: index.php");exit;
	}
}



//���������� �� ���������
//=========================================================================================
if ($ps_type=="moderdop2"){
	$ps_why=requestdata("why");
	$ps_why2=requestdata("why2");
	if ($ps_why=='') $ps_why=$ps_why2;
	$rs_s2=mysql_query("update tbl_base set ISMODER=0, ISDOPEDIT=1, WHODOPEDIT=".$ps_usercode.", WHYDOPEDIT='".$ps_why."' where CODE=".$ps_code,$conn1);
	?>
	<script type="text/javascript" language="JavaScript">
			{    
			window.opener.location="subkat.php?type=ismoder";
			window.close()
			}
	</script>
	<?php
}


//������� ������ - ���.��������
//=========================================================================================
if ($ps_type=="delcross"){
	$rs_2=mysql_query("select * from tbl_cross where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$rs2_2=mysql_query("select WHOADD from tbl_base where CODE=".$rs['FIRSTCODE'],$conn1);
			$rs2=mysql_fetch_array($rs2_2);
			$ps1=$rs2['WHOADD'];
		mysql_free_result($rs2_2);
		$rs2_2=mysql_query("select WHOADD from tbl_base where CODE=".$rs['SECONDCODE'],$conn1);
			$rs2=mysql_fetch_array($rs3_2);
			$ps2=$rs2['WHOADD'];
		mysql_free_result($rs2_2);
	mysql_free_result($rs_2);
	if ($ps1==$ps_usercode || $ps2==$ps_usercode || $zright['DO_MODER']==1){
		$rs_s2=mysql_query("delete from tbl_cross where CODE=".$ps_code,$conn1);
		header("Location: topic.php?type=show&code=".requestdata('backcode'));exit;
	}else{
		header("Location: index.php");exit;
	}
}


//������ ������ - ���.��������
//=========================================================================================
if ($ps_type=="addcross" || $ps_type=="addcrosspersona"){
	$rs_2=mysql_query("select * from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['WHOADD'];
	mysql_free_result($rs_2);
	if ($ps1!=$ps_usercode && $zright['DO_MODER']!=1){
		header("Location: index.php");exit;
	}
	if ($ps_step=="2" && $ps_search=="") $ps_step="";
}



//������� �����������
//=========================================================================================
if ($ps_type=="delcomment"){
	$ps1=0;
	$rs_2=mysql_query("select * from tbl_comment where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if (($zright['DO_MODER']==1 && isadekvat($rs2['WHOADD'])==1)|| $rs['WHOADD']==$ps_usercode) $ps1=1;
	mysql_free_result($rs_2);
	if ($ps1!=1){
		header("Location: index.php");exit;
	}
	$rs_s2=mysql_query("delete from tbl_comment where CODE=".$ps_code,$conn1);
	if ($ps_type2=="not"){
		header("Location: subkat.php?type=lastcomment");exit;
	}else{
		header("Location: topic.php?type=show&code=".$ps_type2."&page=".$ps_page."#comment");exit;
	}
}


//��������� �����������
//=========================================================================================
if ($ps_type=="addcomment"){
	$ps_firsttext=requestdata("firsttext");
	$ps_lasttext=requestdata("lasttext");
	$ps_opis=requestdata("comment");
	$ps_msg="";
	if ($zright['DO_VERADD']!=1){
		if ($ps_firsttext!=md5($ps_lasttext)){
			$ps_msg="badcode";
		}
		if ($ps_msg=="badcode") $ps_msg="";
	}
	if ($ps_opis==""){
		$ps_msg="blank";
	}
	if ($ps_msg==""){
		$rs_s2=mysql_query("insert into tbl_comment (ISMODER,BASECODE,WHOADD,DATEADD,OPIS) values (1,".$ps_code.",".$ps_usercode.",NOW(),'".$ps_opis."')",$conn1);
		header("Location: topic.php?type=show&code=".$ps_code."#comment");exit;
	}else{
		header("Location: topic.php?type=show&code=".$ps_code."&comment=".$ps_opis."&msg=".$ps_msg."#addcomment");exit;
	}
		
}

//��������� ������ � ����� �������
//=========================================================================================
if ($ps_type=="altlink2"){
	$pb_isrepl=1;
	if (getconf("ISREPLACE","VALUEINT")==0) $pb_isrepl=0;
	$ps_linkopis=requestdata("link_opis");
	if ($pb_isrepl==1){
		$ps_link=requestdata("link_alt");
	}else{
		$ps_link=requestdata2("link_alt");
	}
	$ps_msg='';
	if ($ps_linkopis=='') $ps_msg="blank";
	if ($ps_link=='') $ps_msg="blank";
	if ($ps_code=='') $ps_msg="blank";
	//��������� TTH
	$ps1=instr(1,$ps_link,"?xt=");
	if ($ps1==0){
		$ps_msg="badlink";
	}else{
		$ps2=mid($ps_link,$ps1,strlen($ps_link));
		$pi2=instr(1,$ps2,"&xl=")-1;
		if ($pi2==-1)$pi2=strlen($ps2);
		$ps_tth=left_1($ps2,$pi2);
		//��������� - ���� �� ����� ��� � ����
		$pi1=recordcount_new("tbl_link where BASECODE=".$ps_code." and LINK like '%".$ps_tth."%'");
		if ($pi1>0){
			$ps_msg="linkyes";
		}
	}
	$ps_type2='';
	if ($ps_msg==''){
		//�������� ������� ����� ������
		$rs_2=mysql_query("select LINKPOS from tbl_link where BASECODE=".$ps_code." order by LINKPOS desc limit 1",$conn1);
			$rs=mysql_fetch_array($rs_2);
			$ps_linkpos=$rs['LINKPOS'];
		mysql_free_result($rs_2);
		if ($ps_linkpos=='') $ps_linkpos=0;
		$ps_linkpos++;
		$ps_constr="insert into tbl_link (ISMODER,BASECODE,LINKPOS,LINK,LINKOPIS,DATEADD,WHOADD,DOWN) values (0,".$ps_code.",".$ps_linkpos.",'".$ps_link."','".$ps_linkopis."','".sqldatetime2(mktime())."',".$ps_usercode.",0)";
		$rs_2=mysql_query($ps_constr,$conn1);
		$rs_2=mysql_query("select CODE from tbl_link where BASECODE=".$ps_code." order by CODE desc limit 1",$conn1);
			$rs=mysql_fetch_array($rs_2);
			$ps_linkcode=$rs['CODE'];
		mysql_free_result($rs_2);
		//��������� �������
		$pi_rat=getconf("RAT_ALTLINKS","VALUESTR");
		$rs_s2=mysql_query("update tbl_user set ALTLINKS=(ALTLINKS+1),RATINGS=(RATINGS+".$pi_rat.") where CODE=".$ps_usercode,$conn1);
		//���� ������ ���������, �� ������������ �� ����
		if ($zright['DO_VERADD']==1){
			$rs_s2=mysql_query("update tbl_link set ISMODER=1 where CODE=".$ps_linkcode,$conn1);
			//������, ��� ������� ���������
			$rs_s2=mysql_query("update tbl_base set DATEMODER='".sqldatetime2(mktime())."' where CODE=".$ps_code,$conn1);
			//��������� ������ � �������
			$ps_razmer2=0;
			$ps4=$ps_link;
			if (instr(1,$ps4,"&xl=")!=0){
				$ps_razmer2=mid($ps4,instr(1,$ps4,"&xl=")+4,strlen($ps4));
			}
			if (strlen($ps_razmer2)>1){
				$ps_razmer2=left_1($ps_razmer2,instr(1,$ps_razmer2,"&")-1);
				$ps_razmer2=round($ps_razmer2/1024/1024);
			}
			if ($ps_razmer2>0){
				$rs_2=mysql_query("select RAZMER from tbl_base where CODE=".$ps_code,$conn1);
					$rs=mysql_fetch_array($rs_2);
					$ps_razmer=$rs['RAZMER'];
				mysql_free_result($rs_2);
				if ($ps_razmer=='')$ps_razmer=0;
				$ps_razmer=$ps_razmer+$ps_razmer2;
				$rs_s2=mysql_query("update tbl_base set RAZMER=".$ps_razmer." where CODE=".$ps_code,$conn1);
			}
			goback();
			exit;
		}
		header("Location: topic.php?type=altlink&type2=onmoder");exit;
	}
	$ps_type="altlink";
}



//��������� ������� - ���.��������
//=========================================================================================
if ($ps_type=="addposter"){
	$rs_2=mysql_query("select * from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['WHOADD'];
	mysql_free_result($rs_2);
	if ($ps1!=$ps_usercode && $zright['DO_MODER']!=1){
		header("Location: index.php");exit;
	}
}

//������� �������� - ���.��������
//=========================================================================================
if ($ps_type=="delposter"){
	$ps1=0;
	$rs_2=mysql_query("select * from tbl_poster where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_poster=$rs['POSTER'];
		$ps_basecode=$rs['BASECODE'];
		$rs2_2=mysql_query("select * from tbl_base where CODE=".$ps_basecode,$conn1);
			$rs2=mysql_fetch_array($rs2_2);
			if ($rs['WHOADD']==$ps_usercode || $rs2['WHOADD']==$ps_usercode) $ps1=1;
		mysql_free_result($rs2_2);
	mysql_free_result($rs_2);
	if ($ps1!=1 && $zright['DO_MODER']!=1){
		header("Location: index.php");exit;
	}
	//������� ����
	if (file_exists($zserver.'main/poster/'.$ps_poster)==true){
		unlink($zserver.'main/poster/'.$ps_poster);
	}
	$rs_s2=mysql_query("delete from tbl_poster where CODE=".$ps_code,$conn1);
	if ($ps_type2=="ret"){
		header("Location: topic.php?type=show&code=".$ps_basecode);exit;
	}else{
		goback();
	}
}

//=========================================================================================
if ($ps_type=="vote"){
	$pi4=0;
	if (recordcount_new("tbl_votes where USERCODE=".$ps_usercode." and BASECODE=".$ps_code)>0) $pi4=1;
	//�������� �� �������� �� �� ���� ������
	$rs_2=mysql_query("select WHOADD from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['WHOADD']==$ps_usercode) $pi4=1;
	mysql_free_result($rs_2);		
	if ($pi4==0){
		if ($ps_type2!=1) $ps_type2=-1;
		//��������� ���� �� ������� � �� ������������ �� ���
		if (recordcount_new("tbl_base where ISMODER=1 and CODE=".$ps_code)==0) $pi4=0;
		//��������
		$rs_s2=mysql_query("insert into tbl_votes (USERCODE,BASECODE,VOTES,DATEVOTES) values (".$ps_usercode.",".$ps_code.",".$ps_type2.",'".sqldatetime2(mktime())."')",$conn1);	
		//��������� ������� � ������ �������
		$pi_rat_votes=getconf("RAT_VOTES","VALUESTR");
		$rs_2=mysql_query("select WHOADD from tbl_base where CODE=".$ps_code,$conn1);
			$rs=mysql_fetch_array($rs_2);
			if ($ps_type2==1){
				$rs_s2=mysql_query("update tbl_base set VOTES=(VOTES+1) where CODE=".$ps_code,$conn1);
				$rs_s2=mysql_query("update tbl_user set VOTES=(VOTES+1),RATINGS=(RATINGS+".$pi_rat_votes.") where CODE=".$rs['WHOADD'],$conn1);
			}
//			if ($ps_type2==-1){
//				$rs_s2=mysql_query("update tbl_base set VOTES=(VOTES-1) where CODE=".$ps_code,$conn1);
//				$rs_s2=mysql_query("update tbl_user set VOTES=(VOTES-1),RATINGS=(RATINGS-".$pi_rat_votes.") where CODE=".$rs['WHOADD'],$conn1);
//			}
		mysql_free_result($rs_2);		
	}
	header("Location: topic.php?type=show&code=".$ps_code);exit;
}


//=========================================================================================
if ($ps_type=="moderyes"){
	$rs_s2=mysql_query("update tbl_base set ISMODER=1, WHOMODER=".$ps_usercode.", DATEMODER='".sqldatetime2(mktime())."' where CODE=".$ps_code,$conn1);	
	//���� ��� �� �������� ��� �������������� - �� ��������� ���� �� ��������
	$rs_2=mysql_query("select WHOEDIT from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['WHOEDIT']=='' || $rs['WHOEDIT']==0){
			$rs_s2=mysql_query("update tbl_poster set DATEADD='".sqldatetime2(mktime())."' where BASECODE=".$ps_code,$conn1);
		}
		$rs_s2=mysql_query("update tbl_poster set ISMODER=1 where BASECODE=".$ps_code,$conn1);
	mysql_free_result($rs_2);
	//��������� ���� �������
	$rs_s2=mysql_query("update tbl_user set MODERS=(MODERS+1) where CODE=".$ps_usercode,$conn1);	
	//������ �� ������� ����������
	$rs_s2=mysql_query("update tbl_link set ISMODER=1 where BASECODE=".$ps_code,$conn1);	
	//����������� ������ �������
	$ps_razmer=0;
	$rs_2=mysql_query("select LINK from tbl_link where BASECODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_razmer2=0;
		$ps4=$rs['LINK'];
		if (instr(1,$ps4,"&xl=")!=0){
			$ps_razmer2=mid($ps4,instr(1,$ps4,"&xl=")+4,strlen($ps4));
		}
		if (strlen($ps_razmer2)>1){
			$ps_razmer2=left_1($ps_razmer2,instr(1,$ps_razmer2,"&")-1);
			$ps_razmer2=round($ps_razmer2/1024/1024);
		}
		$ps_razmer=$ps_razmer+$ps_razmer2;
	mysql_free_result($rs_2);			
	//��������� ������ � �������
	$rs_s2=mysql_query("update tbl_base set RAZMER=".$ps_razmer." where CODE=".$ps_code,$conn1);
	header("Location: subkat.php?type=ismoder");exit;
}


//=========================================================================================
if ($ps_type=="moderno"){
	//������� ������
	$rs_2=mysql_query("select POSTER,WHOADD,WHOMODER,ISDOPEDIT from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['POSTER'];
		$ps_whoadd=$rs['WHOADD'];
		$ps_whomoder=$rs['WHOMODER'];
		$ps_isdopedit=$rs['ISDOPEDIT'];
	mysql_free_result($rs_2);	
	if ($ps1!=""){
		if (file_exists($zserver.'main/eskiz/'.$ps1)==true){
			unlink($zserver.'main/eskiz/'.$ps1);
		}
	}
	//**********************************************
	//������� ���������� �� ���������� ������
	$pi_rat_down=getconf("RAT_DOWN","VALUESTR");
	$pi_rat_votes=getconf("RAT_VOTES","VALUESTR");
	$pi_rat_links=getconf("RAT_LINKS","VALUESTR");
	$pi_rat_altlinks=getconf("RAT_ALTLINKS","VALUESTR");
	//tbl_stat
	$rs2_2 = mysql_query("select * from tbl_link where BASECODE=".$ps_code,$conn1);
		while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
		$ps_whoaddlink=$rs['WHOADD'];
		$rs_2 = mysql_query("select USERCODE from tbl_stat where LINKCODE=".$rs2['CODE'],$conn1);
			while (($rs=mysql_fetch_assoc($rs_2))!==false) {
				if ($rs['USERCODE']>-1){
					//����������� � ���� ������, ������� ������ ������
					$rs_s2=mysql_query("update tbl_user set DOWNHIM=(DOWNHIM-1),RATINGS=(RATINGS+".$pi_rat_down.") where CODE=".$rs['USERCODE'],$conn1);
				}
				//��������� � ������
				$rs_s2=mysql_query("update tbl_user set DOWNUS=(DOWNUS-1),RATINGS=(RATINGS-".$pi_rat_down.") where CODE=".$ps_whoaddlink,$conn1);
			}
		mysql_free_result($rs_2);
		//��������� � ������ ������
		$rs_s2=mysql_query("update tbl_user set ALTLINKS=(ALTLINKS-1),RATINGS=(RATINGS-".$pi_rat_altlinks.") where CODE=".$ps_whoaddlink,$conn1);
		//������� � ����������
		$rs_s2=mysql_query("delete from tbl_stat where LINKCODE=".$ps1,$conn1);
		}
	mysql_free_result($rs2_2);	
	//**********************************************
	//������� ���������� �� �������
	$pi_votes_g=recordcount_new("tbl_votes where VOTES=1 and BASECODE=".$ps_code);
	$pi_votes_b=recordcount_new("tbl_votes where VOTES=-1 and BASECODE=".$ps_code);
	$pi1=($pi_votes_g-$pi_votes_b);
	//��������� � ������
	if ($pi1<0){
		//���� ���� ������ ������������� �� ���������
		$rs_s2=mysql_query("update tbl_user set VOTES=(VOTES+".$pi1."),RATINGS=(RATINGS+".($pi_rat_votes*$pi1).") where CODE=".$ps_whoadd,$conn1);
	}else{
		//���� ���� ������ ������������� �� ��������
		$rs_s2=mysql_query("update tbl_user set VOTES=(VOTES-".$pi1."),RATINGS=(RATINGS-".($pi_rat_votes*$pi1).") where CODE=".$ps_whoadd,$conn1);
	}
	$rs_s2=mysql_query("delete from tbl_votes where BASECODE=".$ps_code,$conn1);	
	//**********************************************
	//��������� � ������ �������
	$rs_s2=mysql_query("update tbl_user set LINKS=(LINKS-1),RATINGS=(RATINGS-".$pi_rat_links.") where CODE=".$ps_whoadd,$conn1);
	//**********************************************
	
	//������� ������
	$rs_s2=mysql_query("delete from tbl_link where BASECODE=".$ps_code,$conn1);
	$rs_s2=mysql_query("delete from tbl_comment where BASECODE=".$ps_code,$conn1);	
	//������� ������
	$rs_s2=mysql_query("delete from tbl_cross where FIRSTCODE=".$ps_code,$conn1);	
	$rs_s2=mysql_query("delete from tbl_cross where SECONDCODE=".$ps_code,$conn1);	
	$rs_s2=mysql_query("delete from tbl_cross2 where SECONDCODE=".$ps_code,$conn1);	
	//������� ���������
	$rs_2 = mysql_query("select * from tbl_poster where BASECODE=".$ps_code,$conn1);
		while (($rs=mysql_fetch_assoc($rs_2))!==false) {
			if ($rs['POSTER']!=""){
				if (file_exists($zserver.'main/poster/'.$rs['POSTER'])==true){
					unlink($zserver.'main/poster/'.$rs['POSTER']);
				}
			}
		}
	mysql_free_result($rs_2);	
	$rs_s2=mysql_query("delete from tbl_poster where BASECODE=".$ps_code,$conn1);	
	//������� ��-��� ����������
	$rs_s2=mysql_query("delete from tbl_fav where BASECODE=".$ps_code,$conn1);	
	//������� ���� �������
	$rs_s2=mysql_query("delete from tbl_base where CODE=".$ps_code,$conn1);	
	//��������� � ������ ����������
	$rs_s2=mysql_query("update tbl_user set MODERS=(MODERS-1) where CODE=".$ps_whomoder,$conn1);

	if ($ps_type2!="delete"){
		if ($ps_isdopedit==1){
			header("Location: subkat.php?type=onmoderedit&type2=all");
		}else{
			header("Location: subkat.php?type=ismoder");
		}
		exit;
	}else{
		header("Location: index.php");
		exit;
	}
}


//=========================================================================================
//��������� - ���� �������� ��������������� �������
if ($ps_type=="show" && $zright['DO_MODER']!=1){
	$rs_2=mysql_query("select * from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$pi1=$rs['ISMODER'];
		if ($rs['WHOADD']==$ps_usercode) $pi1=1;
	mysql_free_result($rs_2);
	if ($pi1==0){
		header("Location: index.php");
		exit;
	}
}

//=========================================================================================
//��������� - ���� �� ������ ����� �������������
if ($ps_type=="edit" && $zright['DO_MODER']!=1){
	$pi1=0;
	$rs_2=mysql_query("select * from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['WHOADD']==$ps_usercode) $pi1=1;
	mysql_free_result($rs_2);
	if ($pi1==0){
		header("Location: index.php");
		exit;
	}
}

//=========================================================================================

//�������� ��������� � �������
if ($ps_type=="edit" && $ps_step=="2"){
	$rs_s2=mysql_query("update tbl_base set KAT=".requestdata("kat").", SUBKAT1=0, SUBKAT2=0, SUBKAT3=0 where CODE=".$ps_code,$conn1);
	header("Location: topic.php?type=edit&code=".$ps_code);
	exit;	
}
//=========================================================================================

//���� - �������� - �� ��������� ������ ���� ����������
if ($ps_type=="show"){
	$rs_2=mysql_query("select KAT from tbl_base where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_menukat=$rs['KAT'];
	mysql_free_result($rs_2);
}

//=========================================================================================
if ($ps_type=="zl_c"){
	if ($ps_type2==""){
		$ps1=getconf("LANG_SYST","VALUESTR");
		$ps_file = fopen($zserver.'main/lang/'.$ps1.'_magneto.php', "r");
		$ps_file2 = fopen($zserver.'main/lang/lang_magneto.tmp', "w");
			while (!feof($ps_file)) {
		   		$ps3 = fgets($ps_file);
		   		$ps2=fwrite($ps_file2, $ps3);
			}
		fclose($ps_file);
		fclose($ps_file2);
	}else{
		unlink($zserver.'main/lang/lang_magneto.tmp');
	}
	header("Location: index.php?type=ok");exit;
}

//=========================================================================================
if ($ps_type=="newnews2"){
	$ps_nazv=requestdata("nazv");
	$ps_opis=requestdata("opis");
	$ps_connstr="insert into tbl_news (DATEADD,NAZV,OPIS,WHOADD) values ('".sqldatetime2(mktime())."','".$ps_nazv."','".$ps_opis."',".$ps_usercode.")";
	$rs_s2=mysql_query($ps_connstr,$conn1);	
	header("Location: subkat.php?type=shownews");exit;
}
//=========================================================================================
if ($ps_type=="editnews2"){
	$ps_nazv=requestdata("nazv");
	$ps_opis=requestdata("opis");
	$ps_connstr="update tbl_news set DATEADD='".sqldatetime2(mktime())."', NAZV='".$ps_nazv."', OPIS='".$ps_opis."',WHOADD=".$ps_usercode." where CODE=".$ps_code;
	$rs_s2=mysql_query($ps_connstr,$conn1);	
	header("Location: subkat.php?type=shownews");exit;
}
//=========================================================================================
if ($ps_type=="delnews"){
	$ps_connstr="delete from tbl_news where CODE=".$ps_code;
	$rs_s2=mysql_query($ps_connstr,$conn1);	
	header("Location: subkat.php?type=shownews");exit;
}
//=========================================================================================
function rehash_cross($ps_crosslink){
	global $pi_b,$pmas_cross,$pi_c,$conn1;
	$rs2_2 = mysql_query("select * from tbl_cross where FIRSTCODE=".$ps_crosslink,$conn1);
		while (($rs2=mysql_fetch_assoc($rs2_2))!==false){
			$ps_cross=$rs2['SECONDCODE'];
			//��������� - ����� � ������� ��� ���� ����� �������
			$pb1=0;
			for ($pi1=1; $pi1<=(count($pmas_cross));$pi1++){
				if ($pmas_cross[$pi1][1]==$ps_cross) $pb1=1;
			}
			if ($pb1==0){
				$pi_c++;
				$pmas_cross[$pi1][1]=$ps_cross;
				$pmas_cross[$pi1][2]=$rs2['CODE'];
				rehash_cross($ps_cross);
			}
		}
	mysql_free_result($rs2_2);
	$rs2_2 = mysql_query("select * from tbl_cross where SECONDCODE=".$ps_crosslink,$conn1);
		while (($rs2=mysql_fetch_assoc($rs2_2))!==false){
			$ps_cross=$rs2['FIRSTCODE'];
			//��������� - ����� � ������� ��� ���� ����� �������
			$pb1=0;
			for ($pi1=1; $pi1<=(count($pmas_cross));$pi1++){
				if ($pmas_cross[$pi1][1]==$ps_cross) $pb1=1;
			}
			if ($pb1==0){
				$pi_c++;
				$pmas_cross[$pi1][1]=$ps_cross;
				$pmas_cross[$pi1][2]=$rs2['CODE'];
				rehash_cross($ps_cross);
			}
		}
	mysql_free_result($rs2_2);
	return;
}
//=========================================================================================

?>
<HTML>
<HEAD>
	<?php
	$ps1="";
	if ($ps_type=="showtube") $ps1=$zl['575'];//����������� �����
	if ($ps_type=="altlink") $ps1=$zl['456'];//���������� ������ � �������
	if ($ps_type=="addcrosspersona") $ps1=$zl['384'];//������ � �����������
	if ($ps_type=="new") $ps1=$zl['256'];//���������� �������
	if ($ps_type=="edit") $ps1=$zl['257'];//�������������� �������
	if ($ps_type=="addposter") $ps1=$zl['258'];//���������� ���������
	if ($ps_type=="addcross") $ps1=$zl['259'];//������ ������
	if ($ps_type=="showeskiz") $ps1=$zl['422'];//�������� �������
	if ($ps_type=="moderdop") $ps1=$zl['261'];//������� �� ���������
	if ($ps_type=="download2")$ps1=$zl['636'];//������
	if ($ps_type=="show"){
		$rs_2=mysql_query("select NAZV from tbl_base where CODE=".$ps_code,$conn1);
			$rs=mysql_fetch_array($rs_2);
			$ps1=$rs['NAZV'];
		mysql_free_result($rs_2);
	}
	if ($ps_type=="newnews") $ps1=$zl['262'];//���������� �������
	if ($ps_type=="editnews") $ps1=$zl['263'];//�������������� �������
	?>
	<TITLE><?php echo getconf("PROJECTNAME","VALUESTR")?> - <?php echo $ps1;?></TITLE>
	<?php 
	site_header();
	if ($ps_type=="download2"){
		$pi1=$ps_usercode;
		if ($pi1=='') $pi1=-1;
		$pi4=0;
		//���� ��� ���� ��� ����� ��� �������, �� �� ���������
		if (recordcount_new("tbl_stat where USERCODE=".$pi1." and LINKCODE=".$ps_code)>0) $pi4=1;
		if ($pi4==0){
			//� ������� �����
			$rs_s2=mysql_query("insert into tbl_stat (USERCODE,LINKCODE,DATESTAT,USERIP) values (".$pi1.",".$ps_code.",'".sqldatetime2(mktime())."','".$_SERVER["REMOTE_ADDR"]."')",$conn1);
			//tbl_link - ������
			$rs_s2=mysql_query("update tbl_link set DOWN=(DOWN+1) where CODE=".$ps_code,$conn1);	
			//tbl_base - �������
			$rs_2=mysql_query("select BASECODE from tbl_link where CODE=".$ps_code,$conn1);
				$rs=mysql_fetch_array($rs_2);
				$ps_bc=$rs['BASECODE'];
				$rs_s2=mysql_query("update tbl_base set DOWN=(DOWN+1) where CODE=".$ps_bc,$conn1);
			mysql_free_result($rs_2);		
			$pi_rat_down=getconf("RAT_DOWN","VALUESTR");
			//tbl_user - ������������
			$rs_2=mysql_query("select WHOADD from tbl_link where CODE=".$ps_code,$conn1);
				$rs=mysql_fetch_array($rs_2);
				$rs_s2=mysql_query("update tbl_user set DOWNUS=(DOWNUS+1),RATINGS=(RATINGS+".$pi_rat_down.") where CODE=".$rs['WHOADD'],$conn1);
			mysql_free_result($rs_2);		
			//tbl_user - ���� �����
			if ($pi1!=-1){
				$rs_s2=mysql_query("update tbl_user set DOWNHIM=(DOWNHIM+1),RATINGS=(RATINGS-".$pi_rat_down.") where CODE=".$pi1,$conn1);
			}
		}
		//���� ������
		$rs_2=mysql_query("select LINK,BASECODE,LINKOPIS from tbl_link where CODE=".$ps_code,$conn1);
			$rs=mysql_fetch_array($rs_2);
			$ps_link=$rs['LINK'];
			$ps_linkopis=$rs['LINKOPIS'];
			$ps_basecode=$rs['BASECODE'];
		mysql_free_result($rs_2);			
		?>
		<meta http-equiv="Refresh" content="1; URL=<?php echo $ps_link?>">
		<?php
	}
	?>
</HEAD>
<script  language="JavaScript">
	function autoReload(){ 	
        document.frmadd.submit()
	}
	function autoReload1(){ 	
        document.frmadd1.submit()
	}
</script>	
<BODY leftMargin=0 topMargin=0>
<?php 
if ($ps_style=="") require_once('inc_top.php');
?>
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	<TR valign=top>
		<?php 
		if ($ps_style=="") require_once('inc_left.php');
		?>

		<TD class=f10>
    		<?php

			//======================================================================================================
			if ($ps_type=="download2"){
				windowsize (300,500);
				//�������� �������� �������
				$rs_2=mysql_query("select NAZV from tbl_base where CODE=".$ps_basecode,$conn1);
					$rs=mysql_fetch_array($rs_2);
					$ps_nazv=$rs['NAZV'];
				mysql_free_result($rs_2);	
				//������ �� ����������
				//���� ������� �� ������ �� ��������� ������������� - ������� �� ��
				$ps2=$ps_link;

				//$ps2=utf8_cp1251($ps_link);	//����������� ����� � �������� � ������� �����
				//$ps_link = eregi_replace("dn=(.*)","\\1dn=".utf8_cp1251('\\2'),$ps_link);

				if (strlen($ps2)>50) $ps2=left_1($ps2,50).'...';
				?>
				<center>
				<br>
				<TABLE cellSpacing=1 cellPadding=3 width=95% border=0>
					<tr>
						<td class=f10 align=center>
							<b><font size=4><?php echo $ps_nazv?></font></b><br>
							<?php echo $ps_linkopis?><br>
							<br>
							<?php echo $zl['658']?>:<br>
							<a href="<?php echo $ps_link?>"><?php echo $ps2?></a><br>
							<br><br>
							<font size=1><i><?php echo $zl['657']?></font></i>
						</td>
					</tr>
				</table>				
				<?php
				?>
				<script type="text/javascript" language="JavaScript">
						{    
						//window.location="<?php echo $ps_link?>";
						}
				</script>
				<?php
			}



			//==========================================================================================
			if ($ps_type=="showtube"){
				$ps1=3;
				if ($ps1==1){$ps_w=320;$ps_h=265;};
				if ($ps1==2){$ps_w=425;$ps_h=344;};
				if ($ps1==3){$ps_w=480;$ps_h=385;};
				if ($ps1==4){$ps_w=640;$ps_h=605;};
				windowsize ($ps_h+200,$ps_w+100);
				?>
				<center>
				<br>
				<?php
				$rs_2=mysql_query("select * from tbl_tube where ISMODER=1 and BASECODE=".$ps_code,$conn1);
					$rs=mysql_fetch_array($rs_2);
					us_text2($rs['NAZV']);
					echo '<br>';
					?>
					<TABLE cellSpacing=1 cellPadding=3 border=0 class=table_int_int_table>
						<tr>
							<td>
								<object width="<?php echo $ps_w?>" height="<?php echo $ps_h?>">
									<param name="movie" value="http://www.youtube.com/v/<?php echo $rs['RN']?>&hl=ru&fs=1&rel=0"></param>
									<param name="allowFullScreen" value="true"></param>
									<param name="allowscriptaccess" value="always"></param>
									<embed src="http://www.youtube.com/v/<?php echo $rs['RN']?>&hl=ru&fs=1&color1=0xe1600f&color2=0xF57E42" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="<?php echo $ps_w?>" height="<?php echo $ps_h?>"></embed>
								</object>
							</td>
						</tr>
					</table>
					<br>					
					<?php
				mysql_free_result($rs_2);														
			}








			//==========================================================================================
			if ($ps_type=="altlink"){
				windowsize (350,650);
				?>
				<center>
				<br>
				<?php
				//���������� ������ � �������
				us_text2($zl['456']);
				if ($ps_msg=="blank") $ps_msg=$zl['144'];//�� ��� ������ ���������!
				if ($ps_msg=="badlink") $ps_msg=$zl['459'];//������������ ������
				if ($ps_msg=="linkyes") $ps_msg=$zl['460'];//����� ������ � ���� ������� ��� ���� (���� �� ���������)
				if ($ps_msg!=''){
					echo '<br><b><font color="'.$zcmas[16].'">'.$ps_msg.'</font></b>';
				}
				if ($ps_type2=="onmoder"){
					?>
					<script type="text/javascript" language="JavaScript">
							{    
							window.opener.history.go(0);
							}
					</script>
					<?php					
					echo '<br><b><font size=3>';
					echo $zl['458'];//������ ���������� �� ���������
					echo '</font></b><br><br>';
					closewindow();
				}
				if ($ps_type2!="onmoder"){
					//�������� ������
					//���� ����������
					//magnet-������				
					?>
					<form method="post" name="frmlogin" action="topic.php" border=0>
						<input type="hidden" name="type" value="<?php echo $ps_type?>2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<?php echo $zl['320']?> <font size=1>(<?php echo $zl['321']?>)</font><br>
						<input type="text" name="link_opis" class=input2 size="80" maxlength="200" onFocus="id=className;" onBlur="id=''" value="<?php echo requestdata('link_opis')?>"><br>
						<?php echo $zl['285']?><br>
						<input type="text" name="link_alt" class=input2 size="80" maxlength="500" onFocus="id=className;" onBlur="id=''" value="<?php echo requestdata('link_alt')?>"><br>
						<br>
						<?php
						//��������
						inputstyle($zl['337']);
						?>
						<br>
						<br>
					</form>	
					<?php
				}
			}






			//==========================================================================================
			if ($ps_type=="moderdop"){
				windowsize (350,600);
				?>
				<center>
				<br>
				<?php
				//������� �� ���������
				us_text2($zl['261']);
				?>
				<form method="post" name="frmlogin" action="topic.php" border=0>
					<input type="hidden" name="type" value="<?php echo $ps_type?>2">
					<input type="hidden" name="code" value="<?php echo $ps_code?>">
					<b><?php 
					//������� ������� ��������
					echo $zl['264'];
					echo '</b><br>';
					if (recordcount_new("tbl_conf_dorab")>0){
						//������ ������ ���������
						echo '<select name="why2" size="1">';
						$rs_2 = mysql_query("select * from tbl_conf_dorab order by OPIS",$conn1);
							while (($rs=mysql_fetch_assoc($rs_2))!==false) {
								echo '<option value="'.$rs['OPIS'].'">'.$rs['OPIS'].'</option>';
							}
						mysql_free_result($rs_2);						
						echo '</select><br><br>';
						//��� ���� �������
						echo '<b>'.$zl['514'].'</b><br>';
					}
					?>
					<INPUT TYPE="input" NAME="why" size="50" maxlength=200 value=""><br>
					<br>
					<?php
					//�������
					inputstyle($zl['265']);
					?>
					<br>
					<br>
				</form>	
				<?php
			}



			//==========================================================================================
			if ($ps_type=="addcrosspersona"){
				if ($ps_step=="3"){
					//�������� � ����
					$ps1=requestdata("firstcode");
					if ($ps1!=""){
						//������� (���� ����) ������� ������
						$rs_s2=mysql_query("delete from tbl_cross2 where SECONDCODE=".$ps_code." and FIRSTCODE=".$ps1,$conn1);
						//����������� ����� ������
						$ps_constr="insert into tbl_cross2 (SECONDCODE,FIRSTCODE) values (".$ps_code.",".$ps1.")";
						$rs_s2=mysql_query($ps_constr,$conn1);
						//��������� � ���������� +1
						$rs_s2=mysql_query("update tbl_persona set LINKS=(LINKS+1) where CODE=".$ps1,$conn1);
					}
					goback();
				}				
				if ($ps_step=="2"){
					windowsize (740,600);
					?>
					<center>
					<br>
					<?php
					//������ � �����������
					us_text2($zl['384']);
					//������� ������ ����� ����������, � ������� ������ ������� ������� �������
					?>
					<font size=1>(<?php echo $zl['385']?>)</font><br>
					<br>
					<form method="send" name="frmlogin" action="topic.php" border=0>
						<input type="hidden" name="type" value="addcrosspersona">
						<input type="hidden" name="step" value="2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<input class=input2 type="text" name="search" size="60" maxlength="200" value="<?php echo $ps_search?>" onFocus="id=className;" onBlur="id=''">
						<br>
						<br>
						<?php
						//�����
						inputstyle($zl['267']);
						?>
						<br>
						<br>
					</form>	
					<hr>
					<?php
					$pi3=recordcount_new("tbl_persona where ISMODER=1 and NAZV like '%".$ps_search."%'");
					if ($pi3==0){
						//������ �� �������
						?>
						<br><br>
						<b><font color="<?php echo $zcmas[16]?>"><?php echo $zl['268']?>.</font></b>
						<?php
					}else{
						if ($pi3>21) $pi3=21;
						//�������� �� ���������
						?>
						<b><?php echo $zl['269']?>:</b>
						<form method="send" name="frmlogin" action="topic.php" border=0>
							<input type="hidden" name="type" value="addcrosspersona">
							<input type="hidden" name="step" value="3">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
		  					<select name="firstcode" size="<?php echo $pi3?>">
								<?php
								$pi1=0;
								$rs_2 = mysql_query("select * from tbl_persona where ISMODER=1 and NAZV like '%".$ps_search."%' order by NAZV",$conn1);
									while (($rs=mysql_fetch_assoc($rs_2))!==false) {
										//��������� - ��� �� ��� ������
										if (recordcount_new("tbl_cross2 where SECONDCODE=".$ps_code." and FIRSTCODE=".$rs['CODE'])==0){
											$pi1=$pi1+1;
											$ps5=$rs['NAZV'];
											if (strlen($ps5)>60) $ps5=left_1($ps5,60).'...';
											?>
											<option value="<?php echo $rs['CODE']?>"><?php echo $ps5?></option>
											<?php
										}
									}
								mysql_free_result($rs_2);
								?>
		  					</select>
							<br>
							<br>
							<?php 
							//�������
							if ($pi1>0) inputstyle($zl['270']);
							?>
							<br>
							<br>
						</form>							
						<?php
					}
				}
				if ($ps_step==""){
					windowsize (270,500);
					?>
					<center>
					<br>
					<?php
					//������ � �����������
					us_text2($zl['384']);
					//������� ������ ����� ����������, � ������� ������ ������� ������� �������
					?>
					<font size=1>(<?php echo $zl['385']?>)</font><br>
					<br>
					<form method="send" name="frmlogin" action="topic.php" border=0>
						<input type="hidden" name="type" value="addcrosspersona">
						<input type="hidden" name="step" value="2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<input class=input2 type="text" name="search" size="60" maxlength="200" value="" onFocus="id=className;" onBlur="id=''">
						<br>
						<br>
						<?php
						//�����
						inputstyle($zl['267']);
						?>
						<br>
						<br>
					</form>	
					<?php
				}
			}
			
			




			//==========================================================================================
			if ($ps_type=="addcross"){
				if ($ps_step=="3"){
					//�������� � ����
					$ps1=requestdata("secondcode");
					if ($ps1!=""){
						//������ � �������� ���� �� ����
						$rs_s2=mysql_query("update tbl_cross set FIRSTCODE=".$ps_code." where FIRSTCODE=".$ps1,$conn1);
						$rs_s2=mysql_query("update tbl_cross set SECONDCODE=".$ps_code." where SECONDCODE=".$ps1,$conn1);
						//������� (���� ����) ������� ������
						$rs_s2=mysql_query("delete from tbl_cross where SECONDCODE=".$ps_code." and FIRSTCODE=".$ps1,$conn1);
						$rs_s2=mysql_query("delete from tbl_cross where FIRSTCODE=".$ps_code." and SECONDCODE=".$ps1,$conn1);
						//������� �����
						$rs_s2=mysql_query("delete from tbl_cross where FIRSTCODE=SECONDCODE",$conn1);
						//����������� ����� ������
						$rs_s2=mysql_query("insert into tbl_cross (FIRSTCODE,SECONDCODE) values (".$ps_code.",".$ps1.")",$conn1);
					}
					goback();
				}				
				if ($ps_step=="2"){
					windowsize (740,700);
					?>
					<center>
					<br>
					<?php
					//������ ������
					us_text2($zl['259']);
					//������� ������ ����� �������, � ������� ������ ������� ������� �������
					?>
					<font size=1>(<?php echo $zl['266']?>)</font><br>
					<br>
					<form method="send" name="frmlogin" action="topic.php" border=0>
						<input type="hidden" name="type" value="addcross">
						<input type="hidden" name="step" value="2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<input class=input2 type="text" name="search" size="60" maxlength="200" value="<?php echo $ps_search?>" onFocus="id=className;" onBlur="id=''">
						<br>
						<br>
						<?php
						//�����
						inputstyle($zl['267']);
						?>
						<br>
						<br>
					</form>	
					<hr>
					<?php
					//���� ��������� - �� ��������� � ������� �����������
					$ps_iscross=getconf("ISCROSSETC","VALUEINT");
					//�������� ��������� �������
					$rs_2=mysql_query("select KAT from tbl_base where CODE=".$ps_code,$conn1);
						$rs=mysql_fetch_array($rs_2);
						$ps_kat1=$rs['KAT'];
					mysql_free_result($rs_2);					
					if ($ps_iscross!=1){
						$pi3=recordcount_new("tbl_base where ISMODER=1 and KAT=".$ps_kat1." and NAZV like '%".$ps_search."%' and CODE<>".$ps_code);
					}else{
						$pi3=recordcount_new("tbl_base where ISMODER=1 and NAZV like '%".$ps_search."%' and CODE<>".$ps_code);
					}
					if ($pi3==0){
						//������ �� �������
						?>
						<br><br>
						<b><font color="<?php echo $zcmas[16]?>"><?php echo $zl['268']?>.</font></b>
						<?php
					}else{
						if ($pi3>21) $pi3=21;
						//�������� �� ���������
						?>
						<b><?php echo $zl['269']?>:</b>
						<form method="send" name="frmlogin" action="topic.php" border=0>
							<input type="hidden" name="type" value="addcross">
							<input type="hidden" name="step" value="3">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
		  					<select name="secondcode" size="<?php echo $pi3?>">
								<?php
								$pi1=0;
								//��������� ������ �� �������
								$pmas_cross=array();
								$pi_c=0;
								rehash_cross($ps_code);
								if ($ps_iscross!=1){
									$ps_constr="select tbl_base.NAZV as b_NAZV,tbl_base.CODE as b_CODE from tbl_base where tbl_base.ISMODER=1 and tbl_base.KAT=".$ps_kat1." and tbl_base.NAZV like '%".$ps_search."%' and tbl_base.CODE<>".$ps_code." order by tbl_base.NAZV";
								}else{
									$ps_constr="select tbl_base.NAZV as b_NAZV,tbl_base.CODE as b_CODE,tbl_kat.NAZV as k_NAZV,tbl_kat.CODE as k_CODE from tbl_base,tbl_kat where tbl_base.ISMODER=1 and tbl_base.NAZV like '%".$ps_search."%' and tbl_base.CODE<>".$ps_code." and tbl_base.KAT=tbl_kat.CODE order by tbl_base.NAZV";
								}
								$rs_2 = mysql_query($ps_constr,$conn1);
									while (($rs=mysql_fetch_assoc($rs_2))!==false) {
										//��������� - ��� �� ��� ������
										$pb1=0;
										for ($pi1=1; $pi1<=(count($pmas_cross));$pi1++){
											if ($pmas_cross[$pi1][1]==$rs['b_CODE']) $pb1=1;
										}
										if ($pb1==0){
											$pi1=$pi1+1;
											$ps5=$rs['b_NAZV'];
											if (strlen($ps5)>85) $ps5=left_1($ps5,85).'...';
											?>
											<option value="<?php echo $rs['b_CODE']?>"><?php echo $ps5?><?php if ($ps_iscross==1 && $ps_kat1!=$rs['k_CODE']) echo ' ['.$rs['k_NAZV'].']';?></option>
											<?php
										}
									}
								mysql_free_result($rs_2);
								?>
		  					</select>
							<br>
							<br>
							<?php 
							//�������
							if ($pi1>0) inputstyle($zl['270']);
							?>
							<br>
							<br>
						</form>							
						<?php
					}
				}
				if ($ps_step==""){
					windowsize (270,500);
					?>
					<center>
					<br>
					<?php
					//������ ������
					us_text2($zl['259']);
					//������� ������ ����� �������, � ������� ������ ������� ������� �������
					?>
					<font size=1>(<?php echo $zl['266']?>)</font><br>
					<br>
					<form method="send" name="frmlogin" action="topic.php" border=0>
						<input type="hidden" name="type" value="addcross">
						<input type="hidden" name="step" value="2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<input class=input2 type="text" name="search" size="60" maxlength="200" value="" onFocus="id=className;" onBlur="id=''">
						<br>
						<br>
						<?php
						//�����
						inputstyle($zl['267']);
						?>
						<br>
						<br>
					</form>	
					<?php
				}
			}
			
			

			//==========================================================================================
			if ($ps_type=="showeskiz"){
				$rs_2=mysql_query("select * from tbl_base where CODE=".$ps_code,$conn1);
					$rs=mysql_fetch_array($rs_2);
					echo '<center><br>';
					us_text2($rs['NAZV']);
					echo '<br>';
					$size = getimagesize($zserver."main/eskiz/".$rs['POSTER']);
					$pi_w = $size[0];
					$pi_h = $size[1];					
					windowsize (($pi_h+200),($pi_w+100));
					//�������, ����� �������
					?>
					<a href="javascript:window.close();" title="<?php echo $zl['271']?>">
					<img src="main/eskiz/<?php echo $rs['POSTER']?>" width=<?php echo $pi_w?> height=<?php echo $pi_h?> border=0>
					</a>
					<?php
				mysql_free_result($rs_2);
				?>
				<?php
			}
			

			//==========================================================================================
			if ($ps_type=="addposter"){
				$ps_isurl=getconf("ISGETINET_SCREEN","VALUEINT");
				$ps_hs=getconf("HOWMANYSCR","VALUESTR");
				if ($ps_hs<1) $ps_hs=1;
				if ($ps_hs>20) $ps_hs=20;
				if ($ps_isurl==1){
					windowsize (230+60*$ps_hs,500);
				}else{
					windowsize (220+40*$ps_hs,500);
				}
				?>
				<center>
				<br>
				<?php
				$ps_maxsize=getconf("MAXSIZESCREEN","VALUESTR");
				if ($ps_maxsize=='') $ps_maxsize=1024;				
				if ($ps_hs==1){
					//��������� ��������
					us_text2($zl['274']);
					//������ � �������
					//����. ������
					//��
					?>
					<font size=1>(<?php echo $zl['275']?> *.gif, *.jpg, *.png. <?php echo $zl['276'].' '.$ps_maxsize.' '.$zl['503']?>)</font><br>
					<?php
				}else{
					//��������� ���������
					us_text2($zl['599']);
					//������ � �������
					//����.������ �������
					//��
					?>
					<font size=1>(<?php echo $zl['275']?> *.gif, *.jpg, *.png. <?php echo $zl['600'].' '.$ps_maxsize.' '.$zl['503']?>)</font><br>
					<?php
				}
				?>
				<br>
				<form method="post" name="frmlogin" ENCTYPE="multipart/form-data" action="upload.php" border=0>
					<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo ($ps_maxsize*1024)?>">
					<input type="hidden" name="type" value="newposter">
					<input type="hidden" name="code" value="<?php echo $ps_code?>">
					<?php
					for ($pi1=1; $pi1<=$ps_hs;$pi1++)
						{		
						?>
						<INPUT TYPE="file" NAME="ps_file[]" size="40"><br>
						<?php
						//���� �������� URL - �� �����
						if ($ps_isurl==1){
							echo $zl['582'];//��� URL
							?>
							<input type="text" name="url_poster_<?php echo $pi1?>" class=input2 size="42" maxlength="500" onFocus="id=className;" onBlur="id=''" value=''><br>
							<?php
						}
						echo '<br>';
					}			
					//���������
					inputstyle($zl['196']);
					?>
					<br>
					<br>
				</form>	
				<?php
			}



    		//===========================================================================================
    		if ($ps_type=="new" || $ps_type=="show" || $ps_type=="edit"){
    			if ($ps_type=="show"){
					//���� ������
		      		if (getconf("ISFINDTOP_2","VALUEINT")==1){
		      			?>
						<script>
							var xmlHttp;
							function showResultMagneto2(str){
								if (str.length==0){ 
									document.getElementById("magneto_search_top").innerHTML="";
									document.getElementById("magneto_search_top").style.display="none";
									return;
								}
								xmlHttp=GetXmlHttpObject();
								if (xmlHttp==null){
									//alert ("������� �� ������������ HTTP-Request");
									return;
								} 
								var url="index.php?type=new_pre";
								//url=url+"?search="+encodeURIComponent(str);
								url=url+"&search="+str;
								url=url+"&stest=���";
								url=url+"&randoms="+Math.random();
								xmlHttp.onreadystatechange=stateChangedMagneto2;
								xmlHttp.open("GET",url,true);
								xmlHttp.send(null);
							}
							function stateChangedMagneto2(){ 
								if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
									{ 
									document.getElementById("magneto_search_top").innerHTML=xmlHttp.responseText;
									document.getElementById("magneto_search_top").style.display="";
								} 
							}
						</script> 			
			      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
							<FORM name="frmfind" METHOD="send" ACTION="subkat.php">
				      			<TR class=f10>
					      			<?php
					      			//�����
					      			//� ���
			      					?>
				      				<td valign=top align=center>
							      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat>
						
									<?php pan_search(); ?>

											<TR height=30>
							      				<td class=f10 align=center>
									      			<input type="hidden" name="type" value="find">
													&nbsp;<b><?php echo $zl['594']?></b>
									      			<input class=input type="text" name="search" size="70" maxlength="25" value="<?php echo $ps_search?>" onFocus="id=className;" onblur="id=''" onkeyup="showResultMagneto2(this.value); return true;">
													<input type="checkbox" name="fullsearch" value="1" title="<?php echo $zl['496']?>">      	
									    			<font size=1><?php echo lcase($zl['496'])?></font>
									      			&nbsp;&nbsp;&nbsp;
									    			<input type="submit" class=inputb3 value="<?php echo $zl['267']?>" onMouseOver="id=className" onMouseOut="id=''"><br>
													<div id="magneto_search_top" align=left></div>
							      				</TD>
							      			</TR>					      									
							      		</TABLE>
							      	</td>
								</TR>
							</FORM>					      					
			      		</table>
			      		<br>
		    			<?php
		    		}       			
    			}
    			
    				?><TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0><TR><TD><?php
    								
    			if ($ps_type=="new") us_text($zl['256']);//���������� �������
    			if ($ps_type=="show" || $ps_type=="edit") {
    				
    				?><TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
							<TR>
								<TD width=100%>
					<?php
												
    				$rs_2=mysql_query("select * from tbl_base where CODE=".$ps_code,$conn1);
    				$rs=mysql_fetch_array($rs_2);
    				us_text(getkatname($rs['KAT']));
    				us_text2($rs['NAZV']);
    				echo '<font color="'.$zcmas[4].'" size=1>'.$zl['277'].': '.cdate($rs['DATEADD']).'</font><br>';//���������

					?></TD><TD align=right valign=bottom><?php

    				if ($ps_status>=1 && $ps_type=="show"){
    					$pi1=recordcount_new("tbl_fav where USERCODE=".$ps_usercode." and BASECODE=".$ps_code);
    					?>
    					<TABLE cellSpacing=0 cellPadding=0 width=150 height=20 valign=bottom border=0>
							<TR>
								<TD width=20>   
									<?php
									if ($pi1>0){
										echo '<img src="main/color/scheme/'.$ps_color.'/element_fav_del.png" border=0 width=16 height=16>';
									}else{
										echo '<img src="main/color/scheme/'.$ps_color.'/element_fav_add.png" border=0 width=16 height=16>';
									}
									?>
								</TD>
								<TD class=f7>   
									<?php
									if ($pi1>0){
				    					//������ �� ����������
				    					//��������� ������� �� ����������� � �������
										?>
										<a href="topic.php?type=favdel&code=<?php echo $ps_code?>" title="<?php echo $zl['490']?>"><?php echo $zl['489']?></a>
										<?php
									}else{
				    					//�������� ��� ����������
				    					//������ ������� �� ����������� � �������
										?>
										<a href="topic.php?type=favadd&code=<?php echo $ps_code?>" title="<?php echo $zl['488']?>"><?php echo $zl['487']?></a>
										<?php
									}
									?>
								</TD>
							</TR>
						</TABLE>
    					<?php
    				}
    				//��������� � ������ �����
    				if ($zright['DO_SET']==1 && $ps_type=="show" && getconf("ISTAGS","VALUEINT")==1){
    					$pi1=recordcount_new("tbl_tags where BASECODE=".$ps_code);
    					?>
    					<TABLE cellSpacing=0 cellPadding=0 width=150 height=20 valign=bottom border=0>
							<TR>
								<TD width=20>   
									<?php
									if ($pi1>0){
										echo '<img src="main/color/scheme/'.$ps_color.'/element_fav_del.png" border=0 width=16 height=16>';
									}else{
										echo '<img src="main/color/scheme/'.$ps_color.'/element_fav_add.png" border=0 width=16 height=16>';
									}
									?>
								</TD>
								<TD class=f7>   
									<?php
									if ($pi1>0){
				    					//������ �� ������ �����
										?>
										<a href="topic.php?type=tagsdel&code=<?php echo $ps_code?>" title="<?php echo $zl['653']?>"><?php echo $zl['653']?></a>
										<?php
									}else{
				    					//�������� � ������ �����
										?>
										<a href="topic.php?type=tagsadd&code=<?php echo $ps_code?>" title="<?php echo $zl['654']?>"><?php echo $zl['654']?></a>
										<?php
									}
									?>
								</TD>
							</TR>
						</TABLE>
    					<?php
    				}
    				//24/7
    				if ($zright['DO_SET']==1 && $ps_type=="show" && getconf("VIDEOARC","VALUEINT")==1){
    					?>
    					<TABLE cellSpacing=0 cellPadding=0 width=150 height=20 valign=bottom border=0>
							<TR>
								<TD width=20>   
									<?php
									if ($rs['INVIDEOARC']!=1){
										echo '<img src="main/color/scheme/'.$ps_color.'/element_fav_add.png" border=0 width=16 height=16>';
									}else{
										echo '<img src="main/color/scheme/'.$ps_color.'/element_fav_del.png" border=0 width=16 height=16>';
									}
									?>
								</TD>
								<TD class=f7>   
									<?php
									if ($rs['INVIDEOARC']!=1){
				    					//��������� ����� 24/7
										?>
										<a href="topic.php?type=videoarcadd&code=<?php echo $ps_code?>" title="<?php echo $zl['674']?>"><?php echo $zl['674']?></a>&nbsp;&nbsp;
										<?php
									}else{
				    					//����� ����� 24/7
										?>
										<a href="topic.php?type=videoarcdel&code=<?php echo $ps_code?>" title="<?php echo $zl['675']?>"><?php echo $zl['675']?></a>&nbsp;&nbsp;
										<?php
									}
									?>
								</TD>
							</TR>
						</TABLE>
    					<?php
    				}
       				?></TD></TR></TABLE><?php
    			}
    			
       				?></TD></TR></TABLE><?php
    			
    			//���� ��������� - �� ���������� ������� �������
    			if ($ps_type=="show"){
    				if ($rs['ISMODER']==0){
    					//��������� ����������
    					echo '<br><b>'.$zl['278'].':</b><br><hr>';
    					$ps2=$rs['NAZV'];
    					$ps3=left_1($rs['NAZV'],5);
						$rs2_2 = mysql_query("select * from tbl_base where ISMODER=1 and NAZV like '%".$ps3."%' order by NAZV",$conn1);
							while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
								//����������� �������
								//���������
								//��� �������
								//���������� � ������������
								//���� ����������
								?>
								&bull; <a href="topic.php?type=show&code=<?php echo $rs2['CODE']?>" title="<?php echo $zl['160']?>"><?php echo $rs2['NAZV']?></a>
								<font size=1>- <?php echo $zl['175']?>: <?php echo getkatname($rs2['KAT'])?> - <?php echo $zl['279']?>:
								<a href="user.php?type=show&code=<?php echo $rs2['WHOADD']?>" title="<?php echo $zl['12']?>"><?php echo getuserlogin($rs2['WHOADD'])?></a>
								- <?php echo $zl['280']?>: <?php echo cdate($rs2['DATEADD'])?></font>
								<br>
								<?php
							}
						mysql_free_result($rs2_2);			
						echo '<hr>';
    				}
    			}
    			if (($ps_type=="new" && $ps_step=="") || ($ps_type=="edit" && $ps_step=="1")){
    				//���
    				if ($ps_type=="new") echo '<b><u>'.$zl['281'].' �1</u></b><br>';
    				if ($ps_type=="edit"){
						$rs2_2=mysql_query("select KAT from tbl_base where CODE=".$ps_code,$conn1);
							$rs2=mysql_fetch_array($rs2_2);
							$ps_kat=$rs2['KAT'];
						mysql_free_result($rs22_2);
    				}
    				?>
    				<br>
					<form method="send" name="frmlogin" action="topic.php">
						<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=500 border=0 height=50>
							<TR>
								<TD class=f9>    					
									<input type="hidden" name="type" value="<?php echo $ps_type?>">
									<input type="hidden" name="step" value="2">
									<?php
									if ($ps_type=="edit") echo '<input type="hidden" name="code" value="'.$ps_code.'">';
									//�������� ���������
									?>
									<b><?php echo $zl['282']?>:</b>
				  					<select name="kat" size="1">
										<?php
										$rs_2 = mysql_query("select * from tbl_kat order by NAZV",$conn1);
											while (($rs=mysql_fetch_assoc($rs_2))!==false) {
												?>
												<option value="<?php echo $rs['CODE']?>" <?php if ($ps_type=="edit" && $ps_kat==$rs['CODE']) echo 'selected';?>><?php echo $rs['NAZV']?></option>
												<?php
											}
										mysql_free_result($rs_2);
										?>
				  					</select>
				    				&nbsp;&nbsp;&nbsp;<?php 
				    				if ($ps_type=="new") inputstyle($zl['283']);//�����
				    				if ($ps_type=="edit") inputstyle($zl['70']);//��������
				    				?>
					    		</TD>
					    	</TR>
					    </TABLE>
	    			</form>
	    			<?php
    			}
    			if (($ps_type=="new" && $ps_step=="2") || $ps_type=="show" || ($ps_type=="edit" && ($ps_step!="4" && $ps_step!="1"))){
    				if ($ps_type=="new" || $ps_type=="edit"){
    					//��������
    					//magnet-������
    					//����������, ��������� ��������� ����
    					?>
						<script type="text/javascript" language="JavaScript">
							function check()
								{
								arr_field=new Array("nazv","link_1");
								arr_desc_field=new Array("<?php echo $zl['284']?>","<?php echo $zl['285']?>");
								error="";
								for(i=0;i<arr_field.length;i++){
									if(document.forms['frmlogin'].elements[arr_field[i]].value==''){
										//document.forms['frmlogin'].elements[arr_field[i]].focus();
										error=error+"-"+arr_desc_field[i]+"\n";
									}
								}
								if (error!=""){
							    	alert("<?php echo $zl['286']?>:\n"+error);
									return false;
								}
							}
						</script>
	    				<?php
	    				//���
	    				if ($ps_type=="new") echo '<b><u>'.$zl['281'].' �2</u></b><br><br>';
	    				//��������� ���� ����� - ����.����� - ���� �� ����� �������
	    				echo '<div id="topic_search" align=left><br></div>';
						//������ ������ ������
						?>
						<script>
							var xmlHttp;
							function showResultTopic(str){
								if (str.length==0){ 
									document.getElementById("topic_search").innerHTML="";
									document.getElementById("topic_search").style.border="0px";
									return;
								}
								xmlHttp=GetXmlHttpObject();
								if (xmlHttp==null){
									//alert ("������� �� ������������ HTTP-Request");
									return;
								} 
								var url="topic.php?type=new_pre";
								//url=url+"?search="+encodeURIComponent(str);
								url=url+"&search="+str;
								url=url+"&stest=���";
								url=url+"&randoms="+Math.random();
								xmlHttp.onreadystatechange=stateChanged ;
								xmlHttp.open("GET",url,true);
								xmlHttp.send(null);
							}
							function stateChanged(){ 
								if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
									{ 
									document.getElementById("topic_search").innerHTML=xmlHttp.responseText;
								} 
							}
							function GetXmlHttpObject(){
								var xmlHttp=null;
								try{
									// Firefox, Opera 8.0+, Safari
									xmlHttp=new XMLHttpRequest();
								}catch (e){
									// Internet Explorer
									try{
										xmlHttp=new ActiveXObject("Microsoft.XMLHttp");
									}catch (e){
										try{
											xmlHttp=new ActiveXObject("MSXML2.XMLHttp");
										}catch (e){
											try{
												xmlHttp=new ActiveXObject("MSXML2.XMLHttp.3.0");
											}catch (e){
												try{
													xmlHttp=new ActiveXObject("MSXML2.XMLHttp.4.0");
												}catch (e){
													xmlHttp=new ActiveXObject("MSXML2.XMLHttp.5.0");
												}
											}
										}
									}
								}
								return xmlHttp;
							}
						</script> 			
						<form method="post" name="frmlogin" enctype="multipart/form-data" action="upload.php" onsubmit="return check();">
		    			<?php
		    		}
    			if (($ps_type=="new" && $ps_step=="2") || $ps_type=="show" || ($ps_type=="edit" && ($ps_step!="4" && $ps_step!="1"))){
						$ps1=$rs['POSTER'];
						if ($ps1!=""){
							?>
							<br>
							<TABLE cellSpacing=2 cellPadding=0 width=100% border=0>
								<TR valign=top>
									<TD width=200>
									<?php
										if ($ps_type=="show"){
											//��� �������:
											?>
											<TABLE cellSpacing=1 cellPadding=0 width=200 border=0>
												<TR align=center>
													<TD class=f9 width=100%>
														<font size=3 color="#FFFFFF"><b><?php echo $zl['111']?></b></font><br>
														<?php
														$rs2_2=mysql_query("select * from tbl_user where CODE=".$rs['WHOADD'],$conn1);
															$rs2=mysql_fetch_array($rs2_2);
															$ps2=$rs2['POSTER'];
															if ($ps2!="" && mayavatar($rs['WHOADD'])==1){
																$ps_isr=getconf("ISREFLEX_AVA","VALUEINT");
																?>
																<img src="main/avatar/<?php echo $ps2?>" width=64 height=64 border=0 <?php if ($ps_isr==1) echo 'class="reflex itiltnone iopacity100"';?>>
																<br>
																<?php
															}
															//���������� � ������������
															?>
															<a title="<?php echo $zl['12']?>" href='user.php?type=show&code=<?php echo $rs['WHOADD']?>'>
															<font size=3><b><?php echo $rs2['LOGIN'];?></b></font>
															</a>
															<br>
															<?php
															$ps_israt=1;
															echo getstar(floor($rs2['RATINGS']*0.1));
															$ps_israt=0;
														mysql_free_result($rs2_2);
														if ($ps_status>0){														
															//�������� ���������
															?>
															<br>
															<font size=1><a href="javascript:OpenDoc('trouble.php?type=new&type2=<?php echo $rs['WHOADD']?>',<?php echo rndwindow()?>)" title="<?php echo $zl['538']?>"><?php echo $zl['538']?></a></font><br>
															<?php
														}
														?>
													</TD>
												</TR>
											</TABLE>
											<?php
										}
										//������� ��� ����������
										?>
										<br><br>										
										
										<?php
										if ($ps_type=="show"){
										//�������
										?>
											<TABLE cellSpacing=1 cellPadding=0 width=200 border=0>
												<TR align=center>
													<TD>
													</TD>
													<TD class=f9>
														<font size=3 color="#FFFFFF"><b><?php echo $zl['289']?></b></font>
													</TD>
													<TD>
													</TD>
												</TR>
												<TR align=center>


													<TD width=20 align=right>
														<?php
														$pi4=0;
														if ($ps_status>0 && $rs['WHOADD']<>$ps_usercode){
															if (recordcount_new("tbl_votes where USERCODE=".$ps_usercode." and BASECODE=".$ps_code)==0) $pi4=1;
														}
														if ($pi4==1){
															//������������� ������
															?>
															
															<img src="main/color/scheme/<?php echo $ps_color;?>/element_vote_minus.png" border=0 width=25 height=25>
															
															<?php
														}
														?>
													&nbsp;&nbsp;
													</TD>

													<TD class=f10b>
														<?php
														$ps_div="votes";
														?>
														<font color="<?php echo $zcmas[20];?>">
														<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
															<?php echo $rs['VOTES'];?>
														</div>
														<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
															<?php echo $rs['VOTES'];?>
														</div>
														</font>													
													</TD>

													<TD align=left>
													
														<?php
														if ($pi4==1){
															//������������� ��
															?>
															<a href="topic.php?type=vote&type2=1&code=<?php echo $ps_code?>" title="<?php echo $zl['288']?>">
															<img src="main/color/scheme/<?php echo $ps_color;?>/element_vote_plus.png" border=0 width=25 height=25 alt="<?php echo $zl['288']?>">
															</a>
															<?php
														}
														?>
													</TD>
												</TR>
											</TABLE>
										<?php
										}else{
										?>
											<TABLE cellSpacing=1 cellPadding=0 width=10 border=0>
												<TR align=center>
													<TD>&nbsp;
													</TD>
												</TR>
											</TABLE>
										<?php
										}
										?>
									</TD>
											
											
									<TD class=f9 align=center width=230>
										<?php
										$pb1=0;
										if ($zright['DO_MODER']==1 || $ps_usercode==$rs2['WHOADD'] || $ps_usercode==$rs['WHOADD']) $pb1=1;
										?>
										<a rel="thumbnail" href="main/eskiz/<?php echo $ps1?>" title="<?php echo $zl['421']?>">
										<?php 
										$ps_gwidth=230;
										echo smalleskiz($ps1,$zl['421']);
										?>
										</a>
											
													<?php
													//YouTube
													if (getconf("ISTUBE","VALUEINT")==1){
														if ($ps_type=="show" || $ps_type=="edit"){
															if (recordcount_new("tbl_tube where BASECODE=".$ps_code." and ISMODER=1")>0){
																$rs2_2=mysql_query("select * from tbl_tube where ISMODER=1 and BASECODE=".$ps_code,$conn1);
																	$rs2=mysql_fetch_array($rs2_2);
																	//����������� �����
																	?>
																	<TABLE cellSpacing=1 cellPadding=0 width=100% border=0>
																		<TR class=f9>
																			<TD align=center width=50>
																				<?php
																				if ($ps_type=="edit") echo '<a href="http://youtube.com" target=_blank title="'.$zl['576'].'">';//������� �� YouTube
																				if ($ps_type=="edit" || ($ps_type=="show" && $rs2['NAZV']!="")) {
																				?>
																				<img src="main/color/scheme/<?php echo $ps_color;?>/element_video_youtube.png" border=0 width=32 height=32>
																				<?php
																				}
																				if ($ps_type=="edit") echo '</a>';
																				?>	
																			</TD>
																			<TD>
																				<?php
																				if ($ps_type=="show" && $rs2['NAZV']!=""){
																					?>
																					<a href="javascript:OpenDoc('topic.php?type=showtube&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)" title="<?php echo $zl['575']?>"><?php echo $rs2['NAZV']?></a>
																					<?php
																				}
																				if ($ps_type=="edit"){
																					echo $zl['577'].'<br>';//������ �� ����� YouTube
																					?>
																					<input type="text" name="tube_links" class=input2 size="29" maxlength="200" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs2['LINKS'];?>'><br>
																					<?php
																					echo $zl['578'].'<br>';//�������� ������
																					?>
																					<input type="text" name="tube_nazv" class=input2 size="29" maxlength="200" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs2['NAZV'];?>'>
																					<?php
																				}
																				?>	
																			</TD>
																		</TR>
																	</TABLE>
																	<?php
																mysql_free_result($rs2_2);														
															}
														}
													}
													?>
									</TD>
									<TD class=f9 align=center valign=top width=100% border=0>
														
									<?php
// ����� ������
									if ($ps_type=="show" || $ps_type=="new" || $ps_type=="edit"){
									if ($ps_type=="new" || $ps_type=="edit"){  			
										if ($ps_type=="new") $ps_kat=requestdata('kat');
										if ($ps_type=="edit") $ps_kat=$rs['KAT'];
										?>
										<input type="hidden" name="type" value="<?php echo $ps_type?>link">
										<input type="hidden" name="kat" value="<?php echo $ps_kat?>">
										<?php
										if ($ps_type=="edit"){
											?>
											<input type="hidden" name="code" value="<?php echo $ps_code?>">
											<?php
										}
									}
									?>
									
											<TABLE cellSpacing=3 cellPadding=0 width=100% border=0>
													<?php
													if ($ps_type=="new" || $ps_type=="edit"){  	
														//���������		
														?>										
														<TR valign=top class=f10>
															<TD width=170 align=right>
																<?php echo $zl['162']?>:
															</TD>
															<TD width=100%>
																<b><?php 
																if ($ps_type=="edit"){
																	//�������� ���������
																	?>
																	<a href="topic.php?type=edit&step=1&code=<?php echo $ps_code?>" title="<?php echo $zl['291']?>">
																	<?php
																}
																echo getkatname($ps_kat);
																if ($ps_type=="edit") echo '</a>';
																?></b>
															</TD>
														</tr>
														<?php
													}
													if ($ps_type=="show"){
														//���������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['162']?>:
															</TD>
															<TD>
																<a href="kat.php?type=showkat&type2=<?php echo $rs['KAT']?>">
																<?php 
											  					echo getkatname($rs['KAT']);
												  				?>
												  				</a>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new" || ($ps_type=="show" && $rs['SUBKAT1']>0) || $ps_type=="edit"){
														//������������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['292']?><?php if ($ps_type=="show" && ($rs['SUBKAT2']==0 && $rs['SUBKAT3']==0)) {echo ':';}else{ echo ' 1:';}?>
															</TD>
															<TD>
																<?php 
																if ($ps_type=="new" || $ps_type=="edit"){
																	?>
												  					<select name="subkat1" size="1">
																		<option value="0"></option>
																		<?php
																		$rs3_2 = mysql_query("select * from tbl_subkat where KATCODE=".$ps_kat." order by NAZV",$conn1);
																			while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {
																				?>
																				<option value="<?php echo $rs3['CODE']?>" <?php if ($ps_type=="edit" && $rs3['CODE']==$rs['SUBKAT1']) echo 'selected';?>><?php echo $rs3['NAZV']?></option>
																				<?php
																			}
																		mysql_free_result($rs3_2);
																		?>
												  					</select>
												  					<?php
												  				}
												  				if ($ps_type=="show"){
												  					echo '<a href="subkat.php?type=showsubkat&type2='.$rs['SUBKAT1'].'">';
												  					echo getsubkatname($rs['SUBKAT1']);
												  					echo '</a>';
												  				}
												  				?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new" || ($ps_type=="show" && $rs['SUBKAT2']>0) || $ps_type=="edit"){
														//������������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['292']?> 2:
															</TD>
															<TD>
																<?php 
																if ($ps_type=="new" || $ps_type=="edit"){
																	?>
												  					<select name="subkat2" size="1">
																		<option value="0"></option>
																		<?php
																		$rs3_2 = mysql_query("select * from tbl_subkat where KATCODE=".$ps_kat." order by NAZV",$conn1);
																			while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {
																				?>
																				<option value="<?php echo $rs3['CODE']?>" <?php if ($ps_type=="edit" && $rs3['CODE']==$rs['SUBKAT2']) echo 'selected';?>><?php echo $rs3['NAZV']?></option>
																				<?php
																			}
																		mysql_free_result($rs3_2);
																		?>
												  					</select>
												  					<?php
												  				}
												  				if ($ps_type=="show"){
												  					echo '<a href="subkat.php?type=showsubkat&type2='.$rs['SUBKAT2'].'">';
												  					echo getsubkatname($rs['SUBKAT2']);
												  					echo '</a>';
												  				}
												  				?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new" || ($ps_type=="show" && $rs['SUBKAT3']>0) || $ps_type=="edit"){
														//������������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['292']?> 3:
															</TD>
															<TD>
																<?php 
																if ($ps_type=="new" || $ps_type=="edit"){
																	?>
												  					<select name="subkat3" size="1">
																		<option value="0"></option>
																		<?php
																		$rs3_2 = mysql_query("select * from tbl_subkat where KATCODE=".$ps_kat." order by NAZV",$conn1);
																			while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {
																				?>
																				<option value="<?php echo $rs3['CODE']?>" <?php if ($ps_type=="edit" && $rs3['CODE']==$rs['SUBKAT3']) echo 'selected';?>><?php echo $rs3['NAZV']?></option>
																				<?php
																			}
																		mysql_free_result($rs3_2);
																		?>
												  					</select>
												  					<?php
												  				}
												  				if ($ps_type=="show"){
												  					echo '<a href="subkat.php?type=showsubkat&type2='.$rs['SUBKAT3'].'">';
												  					echo getsubkatname($rs['SUBKAT3']);
												  					echo '</a>';
												  				}
												  				?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new" || $ps_type=="edit"){
														//��������:
														?>					
														<TR valign=top class=f10>
															<TD align=right>
																<hr>
																<?php echo $zl['108']?>
															</TD>
															<TD>
																<hr>
																<input type="text" name="nazv" class=input2 size="54" maxlength="250" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['NAZV'];?>' onkeyup="showResultTopic(this.value)">
															</TD>
														</TR>
														<?php
													}
													if (($ps_type=="show" && $rs['RELEASE2']!="") || $ps_type=="new" || $ps_type=="edit"){
														//��� �������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['293']?>:
															</TD>
															<TD>
																<?php
																if ($ps_type=="new" || $ps_type=="edit"){
																	?>
																	<input type="text" name="release" class=input2 size="4" maxlength="4" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['RELEASE2'];?>'>
																	<?php
																}
																if ($ps_type=="show") echo $rs['RELEASE2'];
																?>
															</TD>
														</TR>
														<?php
													}
													if (($ps_type=="show" && $rs['COUNTRY']!="") || $ps_type=="new" || $ps_type=="edit"){
														//������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['294']?>:
															</TD>
															<TD>
																<?php
																if ($ps_type=="new" || $ps_type=="edit"){
																	?>
																	<input type="text" name="country" class=input2 size="20" maxlength="200" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['COUNTRY'];?>'>
																	<?php
																}
																if ($ps_type=="show") echo $rs['COUNTRY'];
																?>
															</TD>
														</TR>
														<?php
													}
													//IMDB ������ ��� �����
													$ps4=lcase(getkatname($ps_kat));
													if ((($ps_type=="new" || $ps_type=="edit") && ($ps4=="�����" || $ps4=="������" || $ps4=="video")) || ($ps_type=="show" && $rs['IMDB']!="")){
														//������ ��
														?>
														<TR class=f10>
															<TD align=right>
																<?php echo $zl['295']?> IMDB:
															</TD>
															<TD>
																<?php
																if ($ps_type=="new" || $ps_type=="edit"){
																	//��� �������
																	?>
																	<input type="text" name="imdb" class=input2 size="42" maxlength="200" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['IMDB'];?>'>
																	<font size=1>(<?php echo $zl['296']?>)</font>
																	<?php
																}
																if ($ps_type=="show"){
																	//������� �
																	?>
																	<a target=_blank href="<?php echo $rs['IMDB'];?>" title="<?php echo $zl['297']?> IMDB">
																	<img src="main/color/scheme/<?php echo $ps_color;?>/element_imdb.png" border=0>
																	</a>
																	<?php
																}
																?>
															</TD>
														</TR>
														<?php
													}
													//�������� ���.����
													if ($ps_type=="show" || $ps_type=="new" || $ps_type=="edit"){
														if ($ps_type=="show") $ps_kat=$rs['KAT'];
														$rs2_2=mysql_query("select * from tbl_dopf where KATCODE=".$ps_kat,$conn1);
															$rs2=mysql_fetch_array($rs2_2);
															if ($rs2['CODE']!=''){
																for ($pi1=1; $pi1<=5;$pi1++)
																	{
																	if ($rs2['DOPF'.$pi1]!=''){
																		if (($ps_type=="show" && $rs['DOPF'.$pi1]!='') || $ps_type!="show"){
																			?>
																			<TR valign=top class=f10>
																				<TD align=right>
																					<?php echo $rs2['DOPF'.$pi1]?>:
																				</TD>
																				<TD>
																					<?php
																					if ($ps_type=="new" || $ps_type=="edit"){
																						?>
																						<input type="text" name="dopf<?php echo $pi1?>" class=input2 size="54" maxlength="250" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['DOPF'.$pi1];?>'>
																						<?php
																					}
																					if ($ps_type=="show") echo $rs['DOPF'.$pi1];
																					?>
																				</TD>
																			</TR>
																			<?php
																		}
																	}
																}
															}
														mysql_free_result($rs2_2);														
													}
													if ($ps_type=="new" || $ps_type=="edit"){
														//������:
														//��������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['298']?>
															</TD>
															<TD>
																<input type="file" name="ps_file" class=input size="44"><br>
																<?php
																//���� �������� URL - �� �����
																if (getconf("ISGETINET_POSTER","VALUEINT")==1){
																	echo $zl['582'];//��� URL
																	?>
																	<input type="text" name="url_poster" class=input2 size="44" maxlength="500" onFocus="id=className;" onBlur="id=''" value=''><br>
																	<?php
																}
																$ps_maxsize=getconf("MAXSIZEPOSTER","VALUESTR");
																if ($ps_maxsize=='') $ps_maxsize=200;				
																echo '<font size=1>'.$zl['276'].' '.$ps_maxsize.' '.$zl['503'].'</font>';//����. ������ //��
																?>																
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="show"){
														//������:
														//��
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['113']?>
															</TD>
															<TD>
																<?php echo $rs['RAZMER'];?> <?php echo $zl['114']?>
															</TD>
														</TR>
														<?php
													}
													?>

											</TABLE>
									<?php
										}
// ����� �����
									?>
									
									</TD>
								</TR>
							</TABLE><br>
							<?php
						}
		    		}
		    		if ($ps_type=="show"){
		    			//������ ��
		    			$ps_div="votes";
		    			?>
		    			<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> >
							<TABLE cellSpacing=1 cellPadding=0 width=100% class=table_int_table border=0>
								<TR>
									<TD class=f8>
										<b><u><?php echo $zl['289']?>:</u></b>
										<?php
										$pb1=0;
										$rs2_2 = mysql_query("select * from tbl_votes where VOTES=1 and BASECODE=".$ps_code." order by DATEVOTES",$conn1);
											while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
												if ($pb1==1) echo ', ';
												//���������� � ������������
												echo '<a href="user.php?type=show&code='.$rs2['USERCODE'].'" title="'.$zl['12'].'">'.getuserlogin($rs2['USERCODE']).'</a>';
												$pb1=1;
											}
										mysql_free_result($rs2_2);	
										//������ ������						
										?>

										<br>
										<b><u><?php echo $zl['290']?>:</u></b>
										<?php
										$pb1=0;
										$rs2_2 = mysql_query("select * from tbl_votes where VOTES=-1 and BASECODE=".$ps_code." order by DATEVOTES",$conn1);
											while (($rs2=mysql_fetch_assoc($rs2_2))!==false){
												if ($pb1==1) echo ', ';
												//���������� � ������������
												echo '<a href="user.php?type=show&code='.$rs2['USERCODE'].'" title="'.$zl['12'].'">'.getuserlogin($rs2['USERCODE']).'</a>';
												$pb1=1;
											}
										mysql_free_result($rs2_2);							
										?>
									</TD>
								</TR>
							</table>
							<TABLE cellSpacing=1 cellPadding=0 width=100% border=0><TR htight=2><TD></TD></TR></TABLE>
						</div>
											
		    			<?php
		    			//������ � ��������-�������� (���� ��������)
		    			if (getconf("ISSHOPWORK","VALUEINT")==1){
							$rs2_2 = mysql_query("select * from tbl_conf_shop order by NAZV",$conn1);
								while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
									$ps_shoplink='';
									$ps_pricecash='';
									$rs3_2=mysql_query("select * from tbl_shop where BASECODE=".$ps_code." and SHOPCODE=".$rs2['CODE'],$conn1);
										$rs3=mysql_fetch_array($rs3_2);
										$ps_shoplink=$rs3['SHOPLINK'];
										$ps_pricecash=$rs3['PRICECASH'];
									mysql_free_result($rs3_2);
									if ($ps_shoplink!=''){
										echo '<b><font size=3>:: <a target=_blank href="'.$ps_shoplink.'" title="'.$zl['550'].'">';//������� � �������
										//������ ��
										echo $zl['548'].': ';
										echo '<u>'.$rs2['NAZV'].'</u> ';
										//��
										echo $zl['549'].' <font size=5>'.$ps_pricecash.'</font></b></font></a><br>';
									}
								}
							mysql_free_result($rs2_2);
		    				echo '<br>';
						}
		    		}
		    		?>
		    		
						<TABLE cellSpacing=2 class=table_int_table cellPadding=0 width=100% border=0>
							<TR valign=top>
								<TD class=f9>  
									<?php
									if ($ps_type=="new" || $ps_type=="edit"){  			
										if ($ps_type=="new") $ps_kat=requestdata('kat');
										if ($ps_type=="edit") $ps_kat=$rs['KAT'];
										?>
										<input type="hidden" name="type" value="<?php echo $ps_type?>link">
										<input type="hidden" name="kat" value="<?php echo $ps_kat?>">
										<?php
										if ($ps_type=="edit"){
											?>
											<input type="hidden" name="code" value="<?php echo $ps_code?>">
											<?php
										}
									}
									?>
									<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>

												<?php
													if ($ps_type=="new"){  	
														//���������		
														?>										
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['162']?>:
															</TD>
															<TD align=left>
																&nbsp;&nbsp;<b><?php 
																echo getkatname($ps_kat);
																?></b>
															</TD>
														</tr>
														<?php
													}
													if ($ps_type=="new"){
														//������������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['292']?><?php if ($ps_type=="show" && ($rs['SUBKAT2']==0 && $rs['SUBKAT3']==0)) {echo ':';}else{ echo ' 1:';}?>
															</TD>
															<TD>
																<?php 
																if ($ps_type=="new"){
																	?>
												  					<select name="subkat1" size="1">
																		<option value="0"></option>
																		<?php
																		$rs3_2 = mysql_query("select * from tbl_subkat where KATCODE=".$ps_kat." order by NAZV",$conn1);
																			while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {
																				?>
																				<option value="<?php echo $rs3['CODE']?>" <?php if ($ps_type=="edit" && $rs3['CODE']==$rs['SUBKAT1']) echo 'selected';?>><?php echo $rs3['NAZV']?></option>
																				<?php
																			}
																		mysql_free_result($rs3_2);
																		?>
												  					</select>
												  					<?php
												  				}
												  				?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new"){
														//������������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['292']?> 2:
															</TD>
															<TD>
																<?php 
																if ($ps_type=="new"){
																	?>
												  					<select name="subkat2" size="1">
																		<option value="0"></option>
																		<?php
																		$rs3_2 = mysql_query("select * from tbl_subkat where KATCODE=".$ps_kat." order by NAZV",$conn1);
																			while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {
																				?>
																				<option value="<?php echo $rs3['CODE']?>" <?php if ($ps_type=="edit" && $rs3['CODE']==$rs['SUBKAT2']) echo 'selected';?>><?php echo $rs3['NAZV']?></option>
																				<?php
																			}
																		mysql_free_result($rs3_2);
																		?>
												  					</select>
												  					<?php
												  				}
												  				?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new"){
														//������������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['292']?> 3:
															</TD>
															<TD>
																<?php 
																if ($ps_type=="new"){
																	?>
												  					<select name="subkat3" size="1">
																		<option value="0"></option>
																		<?php
																		$rs3_2 = mysql_query("select * from tbl_subkat where KATCODE=".$ps_kat." order by NAZV",$conn1);
																			while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {
																				?>
																				<option value="<?php echo $rs3['CODE']?>" <?php if ($ps_type=="edit" && $rs3['CODE']==$rs['SUBKAT3']) echo 'selected';?>><?php echo $rs3['NAZV']?></option>
																				<?php
																			}
																		mysql_free_result($rs3_2);
																		?>
												  					</select>
												  					<?php
												  				}
												  				?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new"){
														//��������:
														?>					
														<TR valign=top class=f10>
															<TD align=right>
																<hr>
																<?php echo $zl['108']?>
															</TD>
															<TD>
																<hr>
																<input type="text" name="nazv" class=input2 size="54" maxlength="250" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['NAZV'];?>' onkeyup="showResultTopic(this.value)">
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new"){
														//��� �������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['293']?>:
															</TD>
															<TD>
																<?php
																if ($ps_type=="new"){
																	?>
																	<input type="text" name="release" class=input2 size="4" maxlength="4" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['RELEASE2'];?>'>
																	<?php
																}
																?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new"){
														//������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['294']?>:
															</TD>
															<TD>
																<?php
																if ($ps_type=="new"){
																	?>
																	<input type="text" name="country" class=input2 size="20" maxlength="200" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['COUNTRY'];?>'>
																	<?php
																}
																?>
															</TD>
														</TR>
														<?php
													}
													//IMDB ������ ��� �����
													$ps4=lcase(getkatname($ps_kat));
													if ( (($ps_type=="new") && ($ps4=="�����" || $ps4=="������" || $ps4=="video")) ){
														//������ ��
														?>
														<TR class=f10>
															<TD align=right>
																<?php echo $zl['295']?> IMDB:
															</TD>
															<TD>
																<?php
																if ($ps_type=="new"){
																	//��� �������
																	?>
																	<input type="text" name="imdb" class=input2 size="42" maxlength="200" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['IMDB'];?>'>
																	<font size=1>(<?php echo $zl['296']?>)</font>
																	<?php
																}
																?>
															</TD>
														</TR>
														<?php
													}
													//�������� ���.����
													if ($ps_type=="new"){
														$rs2_2=mysql_query("select * from tbl_dopf where KATCODE=".$ps_kat,$conn1);
															$rs2=mysql_fetch_array($rs2_2);
															if ($rs2['CODE']!=''){
																for ($pi1=1; $pi1<=5;$pi1++)
																	{
																	if ($rs2['DOPF'.$pi1]!=''){
																			?>
																			<TR valign=top class=f10>
																				<TD align=right>
																					<?php echo $rs2['DOPF'.$pi1]?>:
																				</TD>
																				<TD>
																					<input type="text" name="dopf<?php echo $pi1?>" class=input2 size="54" maxlength="250" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['DOPF'.$pi1];?>'>
																				</TD>
																			</TR>
																			<?php
																	}
																}
															}
														mysql_free_result($rs2_2);														
													}
													if ($ps_type=="new"){
														//������:
														//��������
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['298']?>
															</TD>
															<TD>
																<input type="file" name="ps_file" class=input size="44"><br>
																<?php
																//���� �������� URL - �� �����
																if (getconf("ISGETINET_POSTER","VALUEINT")==1){
																	echo $zl['582'];//��� URL
																	?>
																	<input type="text" name="url_poster" class=input2 size="44" maxlength="500" onFocus="id=className;" onBlur="id=''" value=''><br>
																	<?php
																}
																$ps_maxsize=getconf("MAXSIZEPOSTER","VALUESTR");
																if ($ps_maxsize=='') $ps_maxsize=200;				
																echo '<font size=1>'.$zl['276'].' '.$ps_maxsize.' '.$zl['503'].'</font>';//����. ������ //��
																?>																
															</TD>
														</TR>
														<?php
													}
							/*
													if (getconf("ISTUBE","VALUEINT")==1){
														if ($ps_type=="new"){
															?>
															<TABLE cellSpacing=1 cellPadding=0 width=75% border=0 class=table_int_int_table>
																<TR class=f9>
																	<TD align=center width=40>
																		<a href="http://youtube.com" target=_blank title="<?php echo $zl['576']?>">
																		<img src="main/color/scheme/<?php echo $ps_color;?>/element_video_youtube.png" height="32" width="32" border=0>
																		</a>
																	</TD>
																	<TD>
																		<?php
																		echo $zl['577'].'<br>';//������ �� ����� YouTube
																		?>
																		<input type="text" name="tube_links" class=input2 size="50" maxlength="200" onFocus="id=className;" onBlur="id=''" value=''><br>
																		<?php
																		echo $zl['578'].'<br>';//�������� ������
																		?>
																		<input type="text" name="tube_nazv" class=input2 size="50" maxlength="200" onFocus="id=className;" onBlur="id=''" value=''>
																	</TD>
																</TR>
															</TABLE>
															<?php
														}
													}
							*/
											?>
										<TR><TD width=30pt>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</TD>
											<TD width=50% valign=top class=f9>
											<?php
												
												if (recordcount_new("tbl_cross where FIRSTCODE=".$ps_code." or SECONDCODE=".$ps_code)>0){
													//��������� ������ �� �������
													$pmas_cross=array();
													$pi_c=0;
													rehash_cross($ps_code);
													//������� ������� �
													?>
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B><?php echo $zl['299']?>:</b><br>
													<TABLE cellSpacing=2 cellPadding=0 width=100% border=0>
														<?php
														//������� �������� �������
														for ($pi1=1; $pi1<=(count($pmas_cross));$pi1++){
															if ($pmas_cross[$pi1][1]!=$ps_code){
																$rs3_2=mysql_query("select NAZV,ISMODER,POSTER,KAT,RAZMER from tbl_base where CODE=".$pmas_cross[$pi1][1],$conn1);
																	$rs3=mysql_fetch_array($rs3_2);
																	if ($rs3['ISMODER']==1){
																		?>
																		<TR class=f8>
																			<TD align=center width=20>
																				<?php
																				//���� ���� ������ - ���������� ��������� ������
																				$ps12=$rs3['POSTER'];
																				if ($ps12!=''){
																					$ps_gwidth=18;
																					echo smalleskiz($ps12);
																				}else{
																					echo '&bull;';
																				}
																				?>
																			</TD>
																			<TD align=left>
																				<a href="topic.php?type=show&code=<?php echo $pmas_cross[$pi1][1]?>" title="<?php echo '��������� �������. ������: '.$rs3['RAZMER'].' ��.'?>">
																				<?php 
																				echo $rs3['NAZV'];
																				if ($rs3['KAT']!=$rs['KAT']) echo ' ['.getkatname($rs3['KAT']).']';
																				//echo '('.$rs3['RAZMER'].'��.)';
																				?>
																				</a>
																				<?php
																				if ($zright['DO_MODER']==1 || $ps_usercode==$rs['WHOADD']){
																					//������� ������
																					//������������� ������� ������?
																					?>
																					<a href="topic.php?type=delcross&code=<?php echo $pmas_cross[$pi1][2]?>&backcode=<?php echo $ps_code?>" title="<?php echo $zl['300']?>" OnClick="return confirm('<?php echo $zl['301']?>'); return true;">
																					<img src="main/color/scheme/<?php echo $ps_color;?>/element_remove.png" width=10 height=10 border=0>
																					</a>
																					<?php
																				}
																				?>
																			</TD>
																		</TR>
																		<?php
																	}
																mysql_free_result($rs3_2);
															}
														}
														?>
													</table>
													
													<?php
												}
												if (($zright['DO_MODER']==1 || $ps_usercode==$rs['WHOADD']) && $ps_type=="show"){
													//�������� ������ � ������ ��������
													?>
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=1><a href="javascript:OpenDoc('topic.php?type=addcross&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)"><?php echo $zl['302']?></a>
													</font>
													<?php
												}
											?></TD>

											<TD width=50% valign=top class=f9>
												<?php
												if (getconf("ISPERSENABLED","VALUEINT")==1){
													if (recordcount_new("tbl_cross2 where SECONDCODE=".$ps_code)>0){
														//����������
														?>
														&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B><?php echo $zl['358']?>:</b><br>
														<TABLE cellSpacing=2 cellPadding=0 width=100% border=0>
															<?php
															$pi2=0;
															$rs2_2 = mysql_query("select * from tbl_cross2 where SECONDCODE=".$ps_code." order by CODE",$conn1);
																while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
																	$pi2=$pi2+1;
																	$ps1=$rs2['FIRSTCODE'];
																	$rs3_2=mysql_query("select NAZV,ISMODER,POSTER,LINKS from tbl_persona where CODE=".$ps1,$conn1);
																		$rs3=mysql_fetch_array($rs3_2);
																		if ($rs3['ISMODER']==1){
																			?>
																			<TR class=f8>
																				<TD align=center width=20>
																					<?php
																					//���� ���� ������ - ���������� ��������� ������
																					$ps12=$rs3['POSTER'];
																					if ($ps12!=''){
																						$size = getimagesize($zserver."main/persona/".$ps12);
																						$pi_w = $size[0];
																						$pi_h = $size[1];					
																						if ($pi_w>18){
																							$pi3=$pi_w/18;
																							$pi_w=18;
																							$pi_h=round($pi_h/$pi3);
																						}
																						if ($pi_w<18){
																							$pi3=18/$pi_w;
																							$pi_w=18;
																							$pi_h=round($pi_h*$pi3);
																						}
																						?>
																						<img src="main/persona/<?php echo $ps12?>" width=<?php echo $pi_w?> height=<?php echo $pi_h?>>
																						<?php
																					}else{
																						echo '&bull;';
																					}
																					?>
																				</TD>
																				<TD align=left>
																					<a href="persona.php?type=show&code=<?php echo $ps1?>" title="�������� ����������">
																					<?php echo $rs3['NAZV'].' ('.$rs3['LINKS'].')'?>
																					</a>
																					<?php
																					if ($zright['DO_MODER']==1 || $ps_usercode==$rs['WHOADD']){
																						//������� ������
																						//������������� ������� ������?
																						?>
																						<a href="persona.php?type=delcross&code=<?php echo $rs2['CODE']?>&type2=1&backcode=<?php echo $ps_code?>" title="<?php echo $zl['300']?>" OnClick="return confirm('<?php echo $zl['301']?>'); return true;">
																						<img src="main/color/scheme/<?php echo $ps_color;?>/element_remove.png" width=10 height=10 border=0>
																						</a>
																						<?php
																					}
																					?>
																				</TD>
																			</TR>
																			<?php
																		}
																	mysql_free_result($rs3_2);
																}
															mysql_free_result($rs2_2);
															?>
														</table>
														<?php
													}
													if (($zright['DO_MODER']==1 || $ps_usercode==$rs['WHOADD']) && $ps_type=="show"){
														//�������� ������ � �����������
														?>
														&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=1><a href="javascript:OpenDoc('topic.php?type=addcrosspersona&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)"><?php echo $zl['383']?></a>
														</font>

														<?php
													}
												}
												?>
											</TD>
										</TR>
									</TABLE>
									<?php
									if ($ps_type=="show"){
										//��������	
										?>
										<center>
										<TABLE cellSpacing=5 cellPadding=0 class=table_int_int_table width=90% border=0>
											<TR valign=top class=f10>
												<TD>
													<center>
													<b><u><?php echo $zl['165']?>:</u></b>

													<?php
													if ($zright['DO_MODER']==1 || $rs['WHOADD']==$ps_usercode || $zright['DO_KAT']==1 || $zright['DO_SET']==1){
													?>
													&nbsp;&nbsp;<a href="javascript:OpenDoc('topic.php?type=flyedit&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)" title="������� ��������������"><img src="main/color/scheme/<?php echo $ps_color;?>/element_edit.png" border=0 width=16 height=16 alt="������� ��������������"></a>
													<?php
													}
													?>

													</center>
													<br>
													<?php 
													
                                                                                                        $rs['OPIS']=regex_tag($rs['OPIS'], $ps_code);    //����� ��-�����

												//	$rs['OPIS']=regex_tag2($rs['OPIS'], $ps_code, $conn1, "", 1);	//���������� ����������
													$rs['OPIS']=regex_tag2($rs['OPIS'], $ps_code, $conn1, "������", 1);	//���������� ����������
													$rs['OPIS']=regex_tag2($rs['OPIS'], $ps_code, $conn1, "������", 1);	//���������� ����������
													$rs['OPIS']=regex_tag2($rs['OPIS'], $ps_code, $conn1, "����", 1);	//���������� ����������
													$rs['OPIS']=regex_tag2($rs['OPIS'], $ps_code, $conn1, "����", 1);	//���������� ����������
													$rs['OPIS']=regex_tag2($rs['OPIS'], $ps_code, $conn1, "��������", 1);	//���������� ����������
													$rs['OPIS']=regex_tag2($rs['OPIS'], $ps_code, $conn1, "����������", 1);	//���������� ����������

													$ps_filmopis=str_replace(chr(13),"<br>",$rs['OPIS']);
													$ps_filmopis=commentdo($ps_filmopis);
													echo $ps_filmopis;
													?><br>
													
												</TD>
											</TR>
										</TABLE>

<!--// ������� ����� //!-->

										<?php
										//���������
										if ($ps_type=="show"){
											$pi_poster=0;
											echo '<br>';
											$rs2_2 = mysql_query("select * from tbl_poster where BASECODE=".$ps_code,$conn1);
												while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
													$pi_poster=$pi_poster+1;
													$ps1=$rs2['POSTER'];
													if ($ps1!=""){
														//���� ������ - �� ��������� DIV
														if ($pi_poster==2){
															$ps_div="poster";
															//������ ��������� - ������
															//������ ��������� - ��������
															?>
															<br><br>
															<TABLE cellSpacing=5 cellPadding=0 class=table_int_int_table width=90% border=0>
																<TR valign=top class=f10>
																	<TD>	
																		<center>
																		<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
																			<b><u><?php echo $zl['303']?></u></b><br><br>
																		</div>
																		<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
																			<b><u><?php echo $zl['304']?></u></b><br>
																		</div>															
																		<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> >
															<?php
														}
														//���������� ��������
														$size = getimagesize($zserver."main/poster/".$ps1);
														$pi_w = $size[0];
														$pi_h = $size[1];					
														$pi_co=240;
														if ($pi_h>$pi_co){
															$pi3=$pi_h/$pi_co;
															$pi_h=$pi_co;
															$pi_w=round($pi_w/$pi3);
														}
														if ($pi_h<$pi_co){
															$pi3=$pi_co/$pi_h;
															$pi_h=$pi_co;
															$pi_w=round($pi_w*$pi3);
														}
														$pb1=0;
														if ($zright['DO_MODER']==1 || $ps_usercode==$rs2['WHOADD'] || $ps_usercode==$rs['WHOADD']) $pb1=1;
														//�������� ��������
														?>
														<a rel="thumbnail" href="main/poster/<?php echo $ps1?>" <?php if ($pb1==1) echo 'ismoder="'.$ps_color.'" t_code="'.$rs2['CODE'].'" t_msg1="'.$zl['273'].'" t_msg2="'.$zl['272'].'"';?> title="<?php echo $zl['177']?>">
														<img src="main/poster/<?php echo $ps1?>" width="<?php echo $pi_w?>" height="<?php echo $pi_h?>" border=0> 
														</a>
														<?php
													}
												}
											mysql_free_result($rs2_2);	
											if ($pi_poster>1) echo '</td></tr></table></div>';
											if ($zright['DO_MODER']==1 || $rs['WHOADD']==$ps_usercode){
												//�������� ��������
												?>
												<br>
												<a href="javascript:OpenDoc('topic.php?type=addposter&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)" title="<?php echo $zl['305']?>">
												<font size=1><?php echo $zl['305']?></font>
												</a> 
												<?php
											}
										}
										?>
										</center>
										<?php
										//�� ���������� ��������� ��� �������
										if ($ps_usercode==$rs['WHOADD'] || $zright['DO_MODER']==1){
											//������ ���� - � DIV
											$ps_div="adddata";
											//��� ����������� - ������
											//��� ����������� - ��������
											?>
											<br>
											<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
												&nbsp;&nbsp;&nbsp;
												:: <?php echo $zl['306']?>
											</div>
											<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
												&nbsp;&nbsp;&nbsp;
												:: <?php echo $zl['307']?>
											</div>
											<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> >
												<TABLE cellSpacing=5 cellPadding=0 width=100% border=0>
													<TR valign=top class=f10>
														<TD align=right width=150>
															<hr>
															<?php
															//���� ����������:
															echo $zl['110'];
															?>
														</TD>
														<TD>	
															<hr>
															<?php echo cdate($rs['DATEADD']);?>
														</TD>
													</TR>
													<TR valign=top class=f10>
														<TD align=right>
															<?php
															//��� �������:
															echo $zl['111'];
															//���������� � ������������
															?>
														</TD>
														<TD>
															<a title="<?php echo $zl['112']?>" href='user.php?type=show&code=<?php echo $rs['WHOADD']?>'>
															<?php echo getuserlogin($rs['WHOADD']);?>
															</a>
															<?php
															$ps_israt=1;
															echo getstar(floor(getuserratings($rs['WHOADD'])*0.1));
															$ps_israt=0;
															?>
														</TD>
													</TR>
													<?php
													if ($rs['WHOEDIT']>0){
														//���� ��������������:
														//��� ������������:
														?>
														<TR valign=top class=f10>
															<TD align=right width=150>
																<?php echo $zl['308']?>
															</TD>
															<TD>
																<?php echo cdate($rs['DATEEDIT']);?>
															</TD>
														</TR>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['309']?>
															</TD>
															<TD>
																<a href='user.php?type=show&code=<?php echo $rs['WHOEDIT']?>'>
																<?php echo getuserlogin($rs['WHOEDIT']);?>
																</a>
																<?php
																$ps_israt=1;
																echo getstar(floor(getuserratings($rs['WHOEDIT'])*0.1));
																$ps_israt=0;
																?>
															</TD>
														</TR>
														<?php
													}
													//���� ���������:
													?>
													<TR valign=top class=f10>
														<TD align=right width=150>
															<?php echo $zl['310']?>
														</TD>
														<TD>
															<?php 
															if ($rs['ISMODER']==0){
																if ($rs['ISDOPEDIT']==0){
																	echo $zl['311'];//��������� �� ���������
																	if ($rs['WHODOPEDIT']!=""){
																		echo '<br>'.$zl['312'].'.';//���� �� ���������
																		echo ' '.$zl['313'].': '.$rs['WHYDOPEDIT'].'<br>';//������� ���������
																			//��� ��������
																			//���������� � ������������
																		echo $zl['314'].': <a href="user.php?type=show&code='.$rs['WHODOPEDIT'].'" title="'.$zl['12'].'">'.getuserlogin($rs['WHODOPEDIT']).'</a>';
																	}
																}else{
																	echo $zl['315'];//��������� �� ���������
																	echo '<br>';
																	echo $zl['316'].': '.$rs['WHYDOPEDIT'].'<br>';//������� ��������
																	//��� ������
																	//���������� � ������������
																	echo $zl['317'].': <a href="user.php?type=show&code='.$rs['WHODOPEDIT'].'" title="'.$zl['12'].'">'.getuserlogin($rs['WHODOPEDIT']).'</a>';
																}
															}else{
																echo cdate($rs['DATEMODER']);
															}
															?>
														</TD>
													</TR>
													<?php 
													if ($rs['ISMODER']==1){															
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php
																//���������
																echo $zl['391'].':';
																?>
															</TD>
															<TD>
																<a href='user.php?type=show&code=<?php echo $rs['WHOMODER']?>'>
																<?php echo getuserlogin($rs['WHOMODER']);?>
																</a>
																<?php
																$ps_israt=1;
																echo getstar(floor(getuserratings($rs['WHOMODER'])*0.1));
																$ps_israt=0;
																?>
															</TD>
														</TR>
														<?php
													}
													?>
												</TABLE>
											</div>
											<?php
										}
									}
									if ($ps_type=="new" || $ps_type=="edit"){
										$ps_istiny=getconf("ISTINY_TOPIC","VALUEINT");	
										if ($ps_istiny==1){
											?>
											<script type="text/javascript" src="main/config/tiny_mce/tiny_mce.js"></script>
											<script type="text/javascript">
											tinyMCE.init({
												// General options
												mode : "textareas",
												//theme : "simple",
												theme : "advanced",
												force_br_newlines : true,
		plugins : "save,advhr,advimage,advlink,iespell,inlinepopups,media,contextmenu,paste,directionality,xhtmlxtras,imagemanager,filemanager,template",
		editor_deselector : "mceNoEditor",
													
			// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,fontselect,fontsizeselect,|,bullist,numlist,hr,|,undo,redo,|,link,unlink,image,code,forecolor,backcolor,charmap,template",
		theme_advanced_buttons2 : "",
		theme_advanced_buttons3 : "",
												theme_advanced_toolbar_location : "top",
												theme_advanced_toolbar_align : "left",
												theme_advanced_statusbar_location : "bottom",
												theme_advanced_resizing : true,

												// Office example CSS
												content_css : "css/office.css",

												// Drop lists for link/image/media/template dialogs
												template_external_list_url : "js/template_list.js",
												external_link_list_url : "js/link_list.js",
												external_image_list_url : "js/image_list.js",
												media_external_list_url : "js/media_list.js",

												// Replace values for the template plugin
												template_replace_values : {
													username : "Magneto",
													staffid : "4732893875"
												}
											});
											</script>
											<center>
											<textarea name="opis" style="width:95%; height=400"><?php 
											if ($ps_type=="edit") echo $rs['OPIS'];?></textarea>
											</center>
											<?php
										}else{
											//������ �����
											//������
											//������
											//�������������� �����
											//�������� �����������										
											?>
											<TABLE cellSpacing=0 cellPadding=0 width=660 border=0>
												<TR valign=top>
													<TD width=540>
														<TABLE cellSpacing=0 cellPadding=0 border=0>
															<TR valign=top>
																<TD width=100% class=f9b align=center>
																	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																	<input type="button" value=" � " title="<?php echo $zl['470']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[b]','[/b]');">
																	<input type="button" value=" � " title="<?php echo $zl['471']?>" class=inputb1 style="font-style: italic;" onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[i]','[/i]');">
																	<input type="button" value=" � " title="<?php echo $zl['472']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[u]','[/u]');">
																	&nbsp;
																	<input type="button" value="HR" title="<?php echo $zl['473']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('','[hr]');">
																	<input type="button" value="URL" title="<?php echo $zl['474']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[url]','[/url]');">
&nbsp;<input type="button" value="Ora" title="��������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*color=orange]','[*/color]');">
<input type="button" value="Red" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*color=Red]','[*/color]');">
<input type="button" value="Yel" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*color=yellow]','[*/color]');">
<input type="button" value="Green" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*color=green]','[*/color]');">
<input type="button" value="Gray" title="����� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*color=gray]','[*/color]');">
<input type="button" value="Blue" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*color=blue]','[*/color]');">&nbsp;
<input type="button" value="Img" title="�������� �����������" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*img]','[*/img]');">&nbsp;
<input type="button" value="L" title="��������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*left]','[*/left]');">
<input type="button" value="C" title="��������� �� ������" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*center]','[*/center]');">
<input type="button" value="R" title="��������� ������" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it2('[*right]','[*/right]');">
																</TD>
															</TR>
														</TABLE>
													</TD>
												</TR>
											</TABLE>										
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<script type="text/javascript">
		tinyMCE.init({
			// General options
		mode : "textareas",
		//theme : "simple",
		theme : "advanced",
		force_br_newlines : true,
		plugins : "save,advhr,advimage,advlink,iespell,inlinepopups,media,contextmenu,paste,directionality,xhtmlxtras,imagemanager,filemanager,template",
		editor_deselector : "mceNoEditor",
													
			// Theme options
		theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,fontselect,fontsizeselect,|,bullist,numlist,hr,|,undo,redo,|,link,unlink,image,code,forecolor,backcolor,charmap,template",
		theme_advanced_buttons2 : "",
		theme_advanced_buttons3 : "",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,

			// Office example CSS
		content_css : "css/office.css",

			// Drop lists for link/image/media/template dialogs
		template_external_list_url : "js/template_list.js",
		external_link_list_url : "js/link_list.js",
		external_image_list_url : "js/image_list.js",
		media_external_list_url : "js/media_list.js",

			// Replace values for the template plugin
		template_replace_values : {
		username : "Magneto",
		staffid : "4732893875"
			}
		});
	</script>
											<textarea class=TEXTAREA1 name="opis" cols="107" rows="20"><?php 
											if ($ps_type=="edit") echo $rs['OPIS'];?></textarea><br>			
											<?php
										}
									}
									//������
									?>
									<TABLE cellSpacing=2 cellPadding=0 width=100% border=0>
										<TR valign=top class=f10>
											<TD align=right width=150>
												<hr>
												<font size=5><b>
												<?php echo $zl['318']?>:
												</b></font><br>
												<?php 
												if ($ps_type=="new"){
													?>
													<script language="JavaScript">
														function clean_textarea(){
															document.frmlogin.links_area.value="";
															document.frmlogin.link_1.value="";
															/*
															var text2 = document.getElementById('links_area');
															text2.innerHTML = '';
															var text2 = document.getElementById('link_1');
															text2.value = '';
															*/
														}
														function clean_textarea2(){
															document.frmlogin.link_1.value="_";
														}
													</script>													
													<div id="textarea_show" onClick="javascript:showel('mg_textarea');javascript:showel('textarea_hide');javascript:hideel('textarea_show');javascript:hideel('mg_linksarea');clean_textarea2();" style="cursor: pointer;">
														<?php
														//���� ��������� ����
														echo '<font size=1>:: '.$zl['650'].' ::</font>';
														?>
													</div>												
													<div id="textarea_hide" onClick="javascript:showel('mg_linksarea');javascript:showel('textarea_show');javascript:hideel('textarea_hide');javascript:hideel('mg_textarea');clean_textarea();" style="cursor: pointer; display: none;">
														<?php
														//���� ������� ������
														echo '<font size=1>:: '.$zl['651'].' ::</font>';
														?>
													</div>												
													<?php
												}
												?>
											</TD>
											<TD>
												<hr>
												<?php 
												if ($ps_type=="new"){
													?>
													<div id="mg_textarea" style="display: none;">
														<textarea class=mceNoEditor name="links_area" cols="140" rows="20"></textarea><br>
													</div>
													<?php
												}
												?>
												<div id="mg_linksarea">
													<?php
													if ($ps_type=="new" || $ps_type=="edit"){	
														$pi2=getconf("LINKSONTOPIC","VALUESTR");
														if ($pi2=='')$pi2=10;//������� ������ ����� ����
														if ($ps_type=="edit"){
															$pi2=$pi2+recordcount_new("tbl_link where BASECODE=".$ps_code);
														}
														?>
														<input type="hidden" name="linkcount" value="<?php echo $pi2?>">
														<?php
														for ($pi1=1; $pi1<=$pi2;$pi1++)
															{
															$ps_linkold=0;
															//��������� - ���� �� ��� ����
															if ($ps_type=="edit"){
																$rs3_2=mysql_query("select * from tbl_link where BASECODE=".$ps_code." order by LINKPOS,LINKOPIS limit ".($pi1-1).",1",$conn1);
																$rs3=mysql_fetch_array($rs3_2);
																$ps_linkold=$rs3['CODE'];
															}
															//�������
															//�������� ������
															//���� ����������
															//magnet-������
															?>
															<input type="hidden" name="linkold_<?php echo $pi1?>" value="<?php echo $ps_linkold?>">
															<?php echo $zl['319']?> �<input type="text" name="linkpos_<?php echo $pi1?>" class=input2 size="1" maxlength="3" onFocus="id=className;" onBlur="id=''" value="<?php echo $pi1?>">
															<?php echo $zl['320']?> <font size=1>(<?php echo $zl['321']?>)</font><br>
															<input type="text" name="linkopis_<?php echo $pi1?>" class=input2 size="80" maxlength="200" onFocus="id=className;" onBlur="id=''" value="<?php if ($ps_type=='edit') echo $rs3['LINKOPIS'];?>"><br>
															<?php 
															echo $zl['285'];
															if ($ps_type=="edit" && $rs3['WHOADD']>0){
																echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=1>';
																echo $zl['111'];//��� �������:
																echo ' <a href="user.php?type=show&code='.$rs3['WHOADD'].'" title="'.$zl['12'].'">'.getuserlogin($rs3['WHOADD']).'</a></font>';//���������� � ������������
															}
															?><br>
															<input type="text" name="link_<?php echo $pi1?>" class=input2 size="80" maxlength="500" onFocus="id=className;" onBlur="id=''" value="<?php if ($ps_type=='edit') echo $rs3['LINK'];?>"><br>
															<br>
															<?php
															if ($ps_type=="edit"){
																mysql_free_result($rs3_2);
															}
															//���� ��� ����� ������� � ������ ������ - �� ��������� � ���������� �����
															if ($ps_type=="new" && $pi1==1){
																?>
																<div id="newlinks_hide" onClick="javascript:showel('mg_newlinks');javascript:hideel('newlinks_hide');" style="cursor: pointer;">
																	<?php
																	//���� ��� ������...
																	echo ':: '.$zl['479'];
																	?>
																</div>
																<div id="mg_newlinks" style="display:none">
																<?php
															}
														}
														if ($ps_type=="new") echo '</div>';
													}
													if ($ps_type=="show"){
														$pb1=getconf("ISSHOWLINKTOUNREG","VALUEINT");

														$pb1_bot = 0;
														if ( strstr($_SERVER['HTTP_USER_AGENT'], 'Yandex') ) 		{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'Googlebot') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'Slurp') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'WebCrawler') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'ZyBorg') ) 	{ $pb1_bot=1;} 
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'google') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'scooter') ) 	{ $pb1_bot=1;} 
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'stack') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'aport') ) 	{ $pb1_bot=1;} 
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'lycos') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'fast') ) 		{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'rambler') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'Yahoo') ) 	{ $pb1_bot=1;}
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'Begun') ) 	{ $pb1_bot=1;} 
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'Twiceler') ) 	{ $pb1_bot=1;} 
														elseif ( strstr($_SERVER['HTTP_USER_AGENT'], 'MSN') )		{ $pb1_bot=1;} 
														if ($ps_status==0 && $pb1!=1 && $pb1_bot!=1){
															//��� ��������� ������ ����������
															//������������������
															?>
															<b><?php echo $zl['322']?> <a href="index.php?type=register"><?php echo $zl['323']?></a></b>
															<?php
														}else{
															if ($pb1!=1 && $pb1_bot!=1){
																//��������� - ������� ��� ������
																$ps_rat=getconf("MINLINKTODOWN","VALUESTR");
																$rs3_2=mysql_query("select RATINGS from tbl_user where CODE=".$ps_usercode,$conn1);
																	$rs3=mysql_fetch_array($rs3_2);
																	$ps_rat2=$rs3['RATINGS'];
																mysql_free_result($rs3_2);
																if ($ps_rat2=='') $ps_rat2=0;
															}else{
																$ps_rat2=1;
																$ps_rat=1;
															}
															if ($ps_rat2<$ps_rat && $pb1_bot!=1){
																//��� ��������� ������ ���������� ����� ������� �� �����
																//��� �������
																?>
																<b><?php echo $zl['324']?> <?php echo $ps_rat?>. <?php echo $zl['325']?> <?php echo $ps_rat2?>.</b>
																<?php
															}else{
																?>
																<script>
																	var xmlHttp;
																	function savedown(str){
																		xmlHttp=GetXmlHttpObject();
																		if (xmlHttp==null){
																			//alert ("������� �� ������������ HTTP-Request");
																			return;
																		} 
																		var url="topic.php";
																		url=url+"?type=download&code="+str;
																		url=url+"&randoms="+Math.random();
																		xmlHttp.open("GET",url,true);
																		xmlHttp.send(null);
																	}
																	function GetXmlHttpObject(){
																		var xmlHttp=null;
																		try{
																			// Firefox, Opera 8.0+, Safari
																			xmlHttp=new XMLHttpRequest();
																		}catch (e){
																			// Internet Explorer
																			try{
																				xmlHttp=new ActiveXObject("Microsoft.XMLHttp");
																			}catch (e){
																				try{
																					xmlHttp=new ActiveXObject("MSXML2.XMLHttp");
																				}catch (e){
																					try{
																						xmlHttp=new ActiveXObject("MSXML2.XMLHttp.3.0");
																					}catch (e){
																						try{
																							xmlHttp=new ActiveXObject("MSXML2.XMLHttp.4.0");
																						}catch (e){
																							xmlHttp=new ActiveXObject("MSXML2.XMLHttp.5.0");
																						}
																					}
																				}
																			}
																		}
																		return xmlHttp;
																	}
																</script> 	
																<?php
																$pi1=0;
																$pb1="ISMODER=1 and ";
																if ($rs['ISMODER']==0) $pb1="";
																$rs2_2 = mysql_query("select * from tbl_link where ".$pb1." BASECODE=".$ps_code." order by LINKPOS, LINKOPIS, CODE",$conn1);
																	while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
																		$pi1=$pi1+1;
																		echo '<b>'.$pi1.".</b> ";
																		if ($rs2['LINKOPIS']!=""){
																			echo '<b>'.$rs2['LINKOPIS']."</b> ";
																		}
																		//���������� �� ������� �����
																		$ps_razmer2=0;
																		$ps4=$rs2['LINK'];
																		if (instr(1,$ps4,"&xl=")!=0){
																			$ps_razmer2=mid($ps4,instr(1,$ps4,"&xl=")+4,strlen($ps4));
																		}
																		if (strlen($ps_razmer2)>1){
																			$ps_razmer2=left_1($ps_razmer2,instr(1,$ps_razmer2,"&")-1);
																			$ps_razmer2=round($ps_razmer2/1024/1024);
																		}					
																		echo ' <font size=1>';	
																		if ($ps_razmer2>0){
																			echo $ps_razmer2.' MB - '; 
																		}
																		//�������
																		echo '('.cdate($rs2['DATEADD']).' - <a class=link1 href="user.php?type=show&code='.$rs2['WHOADD'].'">'.getuserlogin($rs2['WHOADD']).'</a> - '.$zl['326'].': '.$rs2['DOWN'].')</font><br>';
																		if ($rs['ISMODER']==0) {
																			echo '<a href="'.$rs2['LINK'].'">'.$rs2['LINK'].'</a><br><br>';
																		}else{
																			//���� �������� �������� ������ ����� ����� ����
																			if (getconf("ISLINKNEWW","VALUEINT")==1 && $pb1_bot!=1){
																				//�������
																				?>
																				<a href="javascript:OpenDoc('topic.php?type=download2&code=<?php echo $rs2['CODE']?>',<?php echo rndwindow()?>)"><?php echo $zl['327']?></a>
																				<?php
																			}else{
																				//�������
																				echo '<a href="'.$rs2['LINK'].'" onClick="savedown('.$rs2['CODE'].')">'.$zl['327'].'</a>';
																			}
																		
																		//$bp1_str = "";
																		//$bp1_str = eregi_replace("(.*)dn=(.*)","\\2",$rs2['LINK']);
																		$bp1_str = utf8_cp1251(eregi_replace("(.*)dn=(.*)","\\2",$rs2['LINK']));
																		$bp1_str=str_replace("+"," ",$bp1_str);
																		?>
																		&nbsp;&nbsp;<font size=1 color=<?php echo $zcmas[7]?>><?php echo $bp1_str?></font><br><br>
																		<?php
																		

																		}
																	}
																mysql_free_result($rs2_2);
															}
														}
													}
													?>
												</div>
											</TD>
										</TR>
									</TABLE>

									<?php
									if ($zright['DO_KAT']==1 && $ps_type=="show"){
										$ps_div="loaders";
										?>
										<center><font size=1 color="<?php echo $zcmas[20];?>">
										<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
											������ ������ ��������� ��� ������
										</div>
										<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
											�������� ������ ��������� ��� ������
										</div>
										</font></center>
									<?php
									}
									?>

					    		</TD>
					    	</TR>
					    </TABLE>

					    <?php

					if ($zright['DO_KAT']==1 && $ps_type=="show"){
		    			//��� �������� ����
		    			$ps_div="loaders";
		    			?>
		    			<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> >
						<TABLE cellSpacing=1 cellPadding=0 width=100% border=0><TR height=2><TD></TD></TR></TABLE>
						<TABLE cellSpacing=1 cellPadding=0 width=100% class=table_int_table border=0>
							<TR>
							<TD class=f8>
							<b><u>��� ������ ���������:</u></b>
							<?php

							$pbs=1;
						//	$pb3="ISMODER=1 and ";
						//	if ($rs['ISMODER']==0) $pb3="";
							$rs3_2 = mysql_query("select * from tbl_link where BASECODE=".$ps_code." order by LINKPOS, LINKOPIS, CODE",$conn1);
							while (($rs3=mysql_fetch_assoc($rs3_2))!==false) {

							echo "<br>������ ".$pbs.": ";
							$pb1=0;
								$rs2_2 = mysql_query("select USERCODE from tbl_stat where LINKCODE=".$rs3['CODE'],$conn1);
								while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
								if ($pb1==1) echo ', ';
									//���������� � ������������
									echo '<a href="user.php?type=show&code='.$rs2['USERCODE'].'" title="'.$zl['12'].'">'.getuserlogin($rs2['USERCODE']).'</a>';
									$pb1=1;
								}
								mysql_free_result($rs2_2);
							$pbs=$pbs+1;
							}
							mysql_free_result($rs3_2);

							?>
							</TD>
							</TR>
						</table>
						<TABLE cellSpacing=1 cellPadding=0 width=100% border=0><TR height=2><TD></TD></TR></TABLE>
					</div>
					<?php
					}
					?>
					    <br>
					<?php

					    //���� ����� ��� �������������� - �� �������� � ����-���������� (���� ��������� �����������)
					    if ($ps_type=="new" || $ps_type=="edit"){
					    	if (getconf("ISSHOPWORK","VALUEINT")==1){
					    		//��������-��������
					    		?>
								<TABLE cellSpacing=5 cellPadding=0 width=100% class=table_int_table border=0>
									<TR valign=top class=f10>
										<TD align=right width=150>
											<font size=5><b>
											<?php echo $zl['545']?>:
											</b></font>
										</TD>									
										<TD>
											<?php
											$rs2_2 = mysql_query("select * from tbl_conf_shop order by NAZV",$conn1);
												while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
													$ps_shoplink='';
													$ps_pricecash='';
													if ($ps_type=="edit"){
														$rs3_2=mysql_query("select * from tbl_shop where BASECODE=".$ps_code." and SHOPCODE=".$rs2['CODE'],$conn1);
															$rs3=mysql_fetch_array($rs3_2);
															$ps_shoplink=$rs3['SHOPLINK'];
															$ps_pricecash=$rs3['PRICECASH'];
														mysql_free_result($rs3_2);
													}
													echo '<b><u>'.$rs2['NAZV'].'</u></b><br>';
													//������ �� �����
													echo $zl['546'].':';
													?>
													<input type="text" name="shoplink_<?php echo $rs2['CODE']?>" class=input2 size="60" maxlength="250" onFocus="id=className;" onBlur="id=''" value="<?php echo $ps_shoplink?>"><br>
													<?php
													//����
													echo $zl['547'].':';
													?>
													<input type="text" name="shopcash_<?php echo $rs2['CODE']?>" class=input2 size="10" maxlength="40" onFocus="id=className;" onBlur="id=''" value="<?php echo $ps_pricecash?>"><br>
													<br>
													<?php
												}
											mysql_free_result($rs2_2);
											?>
										</TD>
									</TR>
								</TABLE>
								<br>
					    		<?php
					    	}
						}					    		
						if ($ps_type=="show" && $ps_comment==1 && $rs['ISMODER']==1){
							$ps_constr="tbl_comment where ISMODER=1 and BASECODE=".$ps_code;
							$ps_perpage=getconf("COMMENTPERPAGE","VALUESTR");//�� ������� �� ��������
							$pi_count=recordcount_new($ps_constr);
							$pi3=ceil($pi_count/$ps_perpage);
							if ($ps_page>$pi3) $ps_page=$pi3;
							$pi4=($ps_page-1)*$ps_perpage;
							if ($pi_count>$ps_perpage){
								//��������:
								?>
								<form method="send" name="frmadd" action="topic.php">
									<input type="hidden" name="type" value="<?php echo $ps_type?>">
									<input type="hidden" name="code" value="<?php echo $ps_code?>">
									<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
										<?php
										for ($pi1=1; $pi1<=$pi3;$pi1++)
											{						
											?>
											<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
											<?php
										}
										?>
									</select>
									&nbsp;<?php 
									//�������
									inputstyle($zl['171']);
									?>
								</form>
								<?php
							}
							//�����������
							?>
							
							<a name="comment"></a>
							<b><?php echo $zl['328']?>:</b>
			      			<?php
							//������� ����������
							$pi1=$pi4;
							$pi_c=0;
							$ps_constr2="tbl_comment where ISMODER=1 and BASECODE=".$ps_code;
							if (recordcount_new($ps_constr2)>0){
								$ps_constr2="select * from tbl_comment where ISMODER=1 and BASECODE=".$ps_code." order by DATEADD desc limit ".$pi4.",".$ps_perpage;
								$rs2_2 = mysql_query($ps_constr2,$conn1);
									while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
										$pi_c++;
										if (fmod($pi_c,2)==0){
											$ps_backc='table_int_table2';
										}else{
											$ps_backc='table_int_table';
										}
										?>
										<TABLE cellSpacing=5 class=<?php echo $ps_backc?> cellPadding=0 width=100% border=0>
											<TR valign=top>
												<TD class=f9 width=150 align=center>
													<font size=1><u><?php echo cdate($rs2['DATEADD'])?></u></font><br>
													<?php
													$rs3_2=mysql_query("select * from tbl_user where CODE=".$rs2['WHOADD'],$conn1);
														$rs3=mysql_fetch_array($rs3_2);
														if ($rs3['ISBAN']==1){
															//������������ ������������
															?>
															<img src="main/color/scheme/<?php echo $ps_color;?>/element_lock.png" width=16 height=16 alt="<?php echo $zl['172']?>">
															<?php
														}
														//���������� � ������������
														?>
														<a href="user.php?type=show&code=<?php echo $rs2['WHOADD']?>" title="<?php echo $zl['12']?>">
														<?php echo $rs3['LOGIN'];?>
														</a><br>
														<?php
														if ($rs3['POSTER']!="" && mayavatar($rs2['WHOADD'])==1){
															?>
															<img src="main/avatar/<?php echo $rs3['POSTER']?>" width=64 height=64 border=0 <?php if ($ps_isr==1) echo 'class="reflex itiltnone iopacity100"';?>>
															<br>														
															<?php
														}
														//������� ������������
														echo '<font size=1>'.getstatusname($rs3['STATUS']).'</font><br>';
														//�������
														echo '<font size=1>'.$zl['255'].': '.$rs3['RATINGS'].'</font><br>';
														$ps_israt=1;
														echo getstar(floor($rs3['RATINGS']*0.1)).' ';
														$ps_israt=0;
													mysql_free_result($rs3_2);
													?>
												</TD>
												<td class=f9>
													<?php
													$ps_opis=$rs2['OPIS']; 
													$ps_opis=str_replace(chr(13),"<br>",$ps_opis);
													//������������ ����� �����������
													$ps_comment=commentdo($ps_opis);
													echo $ps_comment;
													?><br>
													&nbsp;
													<br>
												</td>
												<td width=20>
													<?php
													if (($zright['DO_MODER']==1 && isadekvat($rs2['WHOADD'])==1)|| $rs2['WHOADD']==$ps_usercode){
														//������� �����������
														//������������� ������� �����������?
														?>
														<a href="topic.php?type=delcomment&code=<?php echo $rs2['CODE']?>&type2=<?php echo $ps_code?>&page=<?php echo $ps_page?>" title="<?php echo $zl['179']?>" OnClick="return confirm('<?php echo $zl['180']?>'); return true;">
														<img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=16 height=16 border=0>
														</a>
														<?php
													}
													?>
												</td>
											</TR>										
										</TABLE>			
										<?php
									}									
								mysql_free_result($rs2_2);					
							}
			    			?>
				    		<br>								
							<?php
							if ($pi_count>$ps_perpage){
								//��������:
								?>
								<form method="send" name="frmadd1" action="topic.php">
									<input type="hidden" name="type" value="<?php echo $ps_type?>">
									<input type="hidden" name="code" value="<?php echo $ps_code?>">
									<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
										<?php
										for ($pi1=1; $pi1<=$pi3;$pi1++)
											{						
											?>
											<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
											<?php
										}
										?>
									</select>
									&nbsp;<?php
									//�������
									inputstyle($zl['171']);
									?>
								</form>
								<?php
							}									
							//���������� �����������
							if ($ps_status>0 && maycomment($ps_usercode)==1){
								//�������� �����������
								?>
								<a name="addcomment"></a>
								<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0 bgcolor="<?php echo $zcmas[2]?>">
									<TR valign=top>
										<TD class=f9b align=center width=100% valign="middle">
											<form method="post" name="frmcomment" action="topic.php">
												<input type="hidden" name="type" value="addcomment">
												<input type="hidden" name="code" value="<?php echo $ps_code?>">
												<font size=3><?php echo $zl['329']?></font><br>
												<br>
												<?php
												if ($ps_msg=="blank") $ps_msg=$zl['330'];//������ �����������
												if ($ps_msg=="badcode") $ps_msg=$zl['331'];//������������ ����������� �����
												if ($ps_msg!=""){
													echo '<font color="'.$zcmas[16].'">'.$ps_msg.'</font><br><br>';
												}
												//������ �����
												//������
												//������
												//�������������� �����
												//�������� �����������
												?>
												<TABLE cellSpacing=0 cellPadding=0 width=660 border=0>
													<TR valign=top>
														<TD width=540>
															<TABLE cellSpacing=0 cellPadding=0 border=0>
																<TR valign=top>
																	<TD width=100% class=f9b align=center>
																		<input type="button" value=" � " title="<?php echo $zl['470']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[b]','[/b]');">
																		<input type="button" value=" � " title="<?php echo $zl['471']?>" class=inputb1 style="font-style: italic;" onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[i]','[/i]');">
																		<input type="button" value=" � " title="<?php echo $zl['472']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[u]','[/u]');">
																		&nbsp;
																		<input type="button" value="HR" title="<?php echo $zl['473']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('','[hr]');">
																		<input type="button" value="URL" title="<?php echo $zl['474']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[url]','[/url]');">
&nbsp;<input type="button" value="Ora" title="��������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*color=orange]','[*/color]');">
<input type="button" value="Red" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*color=Red]','[*/color]');">
<input type="button" value="Yel" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*color=yellow]','[*/color]');">
<input type="button" value="Green" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*color=green]','[*/color]');">
<input type="button" value="Gray" title="����� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*color=gray]','[*/color]');">
<input type="button" value="Blue" title="������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*color=blue]','[*/color]');">&nbsp;
<input type="button" value="Img" title="�������� �����������" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*img]','[*/img]');">&nbsp;
<input type="button" value="L" title="��������� �����" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*left]','[*/left]');">
<input type="button" value="C" title="��������� �� ������" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*center]','[*/center]');">
<input type="button" value="R" title="��������� ������" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[*right]','[*/right]');">
																	</TD>
																</TR>
															</TABLE>
														</TD>
														<TD>
															<TABLE class=table_int_table cellSpacing=0 cellPadding=0 width=100 border=0>
																<TR valign=top>
																	<TD width=100% class=f9b align=center>
																		<div id="smiles_hide" onClick="javascript:showel('mg_smiles');javascript:hideel('smiles_hide');javascript:showel('smiles_show');" style="cursor: pointer;">
																			<?php
																			//������
																			echo $zl['475'];
																			?>
																		</div>
																		<div id="smiles_show" style="display:none" onClick="javascript:hideel('mg_smiles');javascript:hideel('smiles_show');javascript:showel('smiles_hide');" style="cursor: pointer;">
																			<?php
																			//������
																			echo $zl['475'];
																			?>
																		</div>																	
																	</TD>
																</TR>
															</TABLE>		
														</TD>
													</TR>
												</TABLE>
												<div id="mg_smiles" style="display:none">
													<TABLE class=table_int_table cellSpacing=0 cellPadding=0 width=660 border=0>
														<TR valign=top>
															<TD>
																<?php
																//������� ��� ������ �� �����
																foreach (glob($zserver."main/color/scheme/".$ps_color."/smiles/*.gif") as $filename) {
																	$pi1=$pi1+1;
																	$ps1=left_1($filename,(strlen($filename)-4));
																	for ($pi2=1; $pi2<=strlen($ps1);$pi2++){
																		if (mid($ps1,$pi2,1)=="/"){
																			$ps3=mid($ps1,$pi2+1,strlen($ps1));
																		}
																	}
																	$ps_smilename=trim($ps3);
																	$ps_smilefile=$ps_smilename.".gif";
																	?>
																	<a>
																	<img src="main/color/scheme/<?php echo $ps_color?>/smiles/<?php echo $ps_smilefile?>" onclick="tag_it('','[<?php echo $ps_smilename?>]');" alt="[<?php echo $ps_smilename?>]">
																	</a>
																	<?php
																}																
																?>
															</TD>
														</TR>
													</TABLE>
													<br>
												</div>																				
												<textarea class=TEXTAREA1 name="comment" cols="107" rows="10"><?php if (requestdata("comment")!="") echo requestdata("comment");?></textarea><br>
												<br>
												<?php
												//��� ������������� � ���� - ����� �� ���������
												if ($zright['DO_VERADD']!=1){
													echo $zl['332'].' ';//������� ����������� �����:
													$ps1=right_1(rndwindow(),5);
													$_SESSION['number']=$ps1
													?>
													<input type="hidden" name="firsttext" value="<?php echo md5($ps1)?>">
													<img src="subpicture.php?rnd=<?php echo rndwindow();?><?php echo rndwindow();?>">
													<input type="text" name="lasttext" class=input2 size="6" maxlength="10" onFocus="id=className;" onBlur="id=''" value=""><br>
													<br>
													<?php
												}
												//���������
												inputstyle($zl['333']);
												?>
												<br><br>
											</form>
										</TD>
										<td>
										</td>
									</TR>
								</TABLE>
								<br>
								<?php
							}else{
								$ps2="";
								if ($ps_status==0){
									//��������� ����������� ����� ������ ����������������� ������������
									$ps2=$zl['334'];
								}else{
									$rs3_2=mysql_query("select * from tbl_user where CODE=".$ps_usercode,$conn1);
										$rs3=mysql_fetch_array($rs3_2);
										if ($rs3['ISCOMMENT']==0) $ps2=$zl['335'];//��� ��������� ��������� �����������
										//��� ���� ����� �������������� ���������� ����� ������� �� ����
										//��� �������
										$ps_rat=$rs3['RATINGS'];
										if ($ps_rat=='') $ps_rat=0;
										if ($ps_rat<getconf("RATINGFORCOMMENT","VALUESTR")) $ps2=$zl['336']." ".getconf("RATINGFORCOMMENT","VALUESTR").'<br>'.$zl['325'].': '.$ps_rat;
									mysql_free_result($rs3_2);									
								}
								if ($ps2!=""){
									echo '<font color="'.$zcmas[16].'"><center><b>'.$ps2.'</b></center></font><br>';
								}
							}
						}
						?>
						<center>
	    				<?php 
	    				if ($ps_type=="new") inputstyle($zl['337']);//��������
	    				if ($ps_type=="edit") inputstyle($zl['70']);//��������
						if ($ps_type=="show"){
							?>
							<center>
							<TABLE cellSpacing=5 cellPadding=0 class=table_int_int_table width=550 border=0>
								<TR valign=top class=f10>
									<?php
									if ($zright['DO_MODER']==1 && $rs['ISMODER']==0){
										//����������� �������
										//�����������
										?>
										<TD align=center>
											<a href="topic.php?type=moderyes&code=<?php echo $ps_code?>" title="<?php echo $zl['338']?>">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_accept.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['339']?></b>
											</a>
										</TD>
										<td width=50>
										</td>
										<?php
									}
									if ($zright['DO_MODER']==1 && $rs['ISDOPEDIT']!=1){
										//��������� �� ���������
										//�� ���������
										?>
										<TD align=center>
											<a href="javascript:OpenDoc('topic.php?type=moderdop&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)" title="<?php echo $zl['340']?>">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_goback.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['341']?></b>
											</a>
										</TD>
										<?php
									}
									if ($rs['WHOADD']==$ps_usercode || $zright['DO_MODER']==1){
										//������������� �������
										//�������������
										?>
										<TD align=center>
											<a href="topic.php?type=edit&code=<?php echo $ps_code?>" title="<?php echo $zl['342']?>">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_edit2.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['343']?></b>
											</a>
										</TD>
										<?php
									}
									if (($rs['WHOADD']==$ps_usercode && $zright['DO_DELSVOI']==1) || $zright['DO_MODER']==1){
										?>
										<TD align=center>
											<?php
											//������� �������
											//������������� ������� �������?
											//�������
											?>
											<a href="topic.php?type=moderno&code=<?php echo $ps_code?>" title="<?php echo $zl['344']?>" OnClick="return confirm('<?php echo $zl['345']?>'); return true;">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_remove.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['346']?></b>
											</a>
										</TD>
										<?php
									}
									//���������� ������ �� ������ ������������� �����������, ���� �����. ���������
									if (getconf("ISADDALTLINKS","VALUEINT")==1){
										$pi1=getconf("RATFORLINKS","VALUESTR");
										$pi2=getuserratings($ps_usercode);
										if ($zright['DO_MODER']==1) $pi2=$pi1;
										if ($pi2>=$pi1){
											if ($rs['WHOADD']!=$ps_usercode && $zright['DO_ADD']==1){
												//���������� ������ � �������
												//�������� ������
												?>
												<TD align=center>
													<a href="javascript:OpenDoc('topic.php?type=altlink&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)" title="<?php echo $zl['456']?>">
													<img src="main/color/scheme/<?php echo $ps_color;?>/element_addalt.png" border=0 width=32 height=32><br>
													<b><?php echo $zl['457']?></b>
													</a>
												</TD>
												<?php
											}
										}
									}
									?>
								</TR>
							</TABLE>
							</center>
							<?php
						}
						if ($ps_type=="show"){
							$ps_popular="kat";
							$ps_type2=$rs['KAT'];
							$ps_katname=getkatname($ps_type2);
						}
	    				?>
	    				</center>
    				</form>
	    			<?php
    			}
    			if ($ps_step=="3"){
    				//�������!
    				?>
    				<center>
    				<br>
					<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=500 border=0>
						<TR valign=top>
							<TD class=f10b align=center>
								<br>
								<?php 
								//�������!
								echo $zl['347'];
								?><br>
								<?php
								if ($zright['DO_VERADD']!=1){
									echo $zl['348'].'.';//������� ���������� �� ���������
								}else{
									echo $zl['349'].'.<br><br>';//������� ���������
									//����������� �������
									?>
									<a href="topic.php?type=show&code=<?php echo $ps_code?>"><?php echo $zl['160']?></a>
									<?php									
								}
								//�������� ��� �������
								?>
								<br><br>
								<a href="topic.php?type=new"><?php echo $zl['350']?></a><br>
								<br>
				    		</TD>
				    	</TR>
				    </TABLE>
				    </center>
	    			<?php
    			}
    			if ($ps_step=="4"){
    				//�������!
    				?>
					<br>
    				<center>
					<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=500 border=0>
						<TR valign=top>
							<TD class=f10 align=center>
								<br><b>
								<?php echo $zl['347']?><br>
								<?php
								if ($zright['DO_VERADD']!=1){
									echo $zl['351'];//��������� ���������� �� ���������. �� ������� ��������� ������� ����� ����������.
								}else{
									echo $zl['352'].'.<br><br>';//������� ��������
									//����������� �������
									?>
									<a href="topic.php?type=show&code=<?php echo $ps_code?>"><?php echo $zl['160']?></a>
									<?php
									//����������� ���������� ����� 
									//�
									$ps_sec=3;
									$ps_sec2=$ps_sec*1000;
									echo '</b><br><br><font size=1>'.$zl['666'].' '.$ps_sec.' '.$zl['25'].'</font>';
									?>
									<script language="JavaScript">
										window.setTimeout('gototopic()',<?php echo $ps_sec2?>)
										function gototopic(){ 
											window.location="topic.php?type=show&code=<?php echo $ps_code?>";
										}										
									</script>			
									<?php
								}
								?>
								<br><br>
				    		</TD>
				    	</TR>
				    </TABLE>
				    </center>
	    			<?php
    			}
    			?>
    			<br>
    			<?php
			}




    		//===========================================================================================
    		if ($ps_type=="newnews" || $ps_type=="editnews"){
    			
    			?><TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0><TR><TD><?php
    			    								
    			if ($ps_type=="newnews") us_text($zl['262']);//���������� �������
    			if ($ps_type=="editnews") {
    				us_text($zl['263']);//�������������� �������
    				$rs_2=mysql_query("select * from tbl_news where CODE=".$ps_code,$conn1);
    				$rs=mysql_fetch_array($rs_2);
    			}
    			
    			?></TD></TR></TABLE><?php
    								
				if ($ps_type=="newnews" || $ps_type=="editnews"){
					//��������
					//����� �������
					//����������, ��������� ��������� ����
					?>
					<script type="text/javascript" language="JavaScript">
						function check()
							{
							arr_field=new Array("nazv","opis");
							arr_desc_field=new Array("<?php echo $zl['284']?>","<?php echo $zl['353']?>");
							error="";
							for(i=0;i<arr_field.length;i++){
								if(document.forms['frmlogin'].elements[arr_field[i]].value==''){
									//document.forms['frmlogin'].elements[arr_field[i]].focus();
									error=error+"-"+arr_desc_field[i]+"\n";
								}
							}
							if (error!=""){
						    	alert("<?php echo $zl['286']?>:\n"+error);
								return false;
							}
						}
					</script>
					<form method="post" name="frmlogin" action="topic.php" onsubmit="return check();">
	    			<?php
	    		}
	    		?>
	    		<br>
				<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0>
					<TR valign=top>
						<TD class=f9>  
							<input type="hidden" name="type" value="<?php echo $ps_type?>2">
							<?php
							if ($ps_type=="editnews"){
								?>
								<input type="hidden" name="code" value="<?php echo $ps_code?>">
								<?php
							}
							//���� �������
							//�������
							?>
							<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
								<TR>
									<TD width=50% valign=top>
										<TABLE cellSpacing=5 cellPadding=0 width=100% border=0>
											<TR valign=top class=f10>
												<TD align=right>
													<?php echo $zl['354']?>:
												</TD>
												<TD>
													<input type="text" name="nazv" class=input2 size="54" maxlength="250" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="editnews") echo $rs['NAZV'];?>'>
												</TD>
											</TR>
											<TR valign=top class=f10>
												<TD align=right>
													<?php echo $zl['355']?>:
												</TD>
												<TD>
													<textarea class=TEXTAREA1 name="opis" cols="107" rows="20"><?php 
													if ($ps_type=="editnews") echo $rs['OPIS'];?></textarea><br>			
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
				<center>
				<br>
				<?php 
				if ($ps_type=="newnews") inputstyle($zl['337']);//��������
				if ($ps_type=="editnews") inputstyle($zl['70']);//��������
				echo '</center></form>';
			}


			?>
    	</TD>
    			
		<?php 
		if ($ps_style=="") require_once('inc_right.php');
		?>
			
		</TD>	      									
	</TR>
</TABLE>
<?php 
if ($ps_style=="") require_once('inc_down.php');
mysql_close($conn1);
?>	
</body>
</html>
