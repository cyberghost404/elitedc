<?php
$ps1=$_SERVER["PHP_SELF"];
$ps1=ucase($ps1);
$pb1=0;
for ($pi1=strlen($ps1);$pi1>=1;$pi1--){
	if ($pb1==0){
		if (mid($ps1,$pi1,1)=="/"){
			$ps2=mid($ps1,$pi1+1,strlen($ps1));
			$pb1=1;
		}
	}
}	
if ($_SERVER['QUERY_STRING']!=""){
	$ps3=$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']; 
}else{
	$ps3=$_SERVER['PHP_SELF']; 
}
?>
<TD width=200px valign=top>
	<table cellSpacing=0 cellPadding=0 border=0>
		<td width="200px" height="1px" bgcolor="<?php echo $zcmas[4]?>"></td>
	</table>


		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
  			<TR class=f10 height=1>
  				<td>

	<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
		<TR class=f10 height=14>
			<td width=27 align=center>
  				<img src="main/color/scheme/<?php echo $ps_color;?>/element_user.png" width=16 height=16>
  			</TD>
				<td><font color="<?php echo $zcmas[50]?>">
		      			<b><?php echo $zl['483']?></b>
  				</font></TD>
		</TR>
	</TABLE>
				</td>
			</TR>
		</TABLE>




	<TABLE cellSpacing=0 cellPadding=0 width=200 border=0 class=table_leftmenu bgcolor="<?php echo $zcmas[1]?>">
		<?php 
		//������� ��������
		leftmproc("index.php",$zl['40'],$zl['41'],"element_menu_main.png");//�� �������
		//��������� ��� ���.�������� (���� ����)
		$rs_2 = mysql_query("select * from tbl_page where ISSHOW=1 order by POSITION,NAZV",$conn1);
			while (($rs=mysql_fetch_assoc($rs_2))!==false) {
				$ps1=$rs['NAZV'];
				if (instr(1,$ps1,"���� ����")>0){
					$ps1=trim(str_replace("����� ����:","",$ps1));
					leftmproc('pages.php?code='.$rs['CODE'],$ps1,$zl['171'],"element_menu_main.png");//�������
				}
			}
		mysql_free_result($rs_2);
		//��������� ��� ���.������ (���� ����)
		$rs_2 = mysql_query("select * from tbl_menulinks order by NAZV",$conn1);
			while (($rs=mysql_fetch_assoc($rs_2))!==false) {
				leftmproc($rs['LINKHREF'],$rs['NAZV'],$zl['171'],"element_menu_main.png");//�������
			}
		mysql_free_result($rs_2);
//		if (getconf("ISPERSENABLED","VALUEINT")==1){
//			$pi1=recordcount_new("tbl_persona where ISMODER=1");
//			leftmproc("subkat.php?type=persona",$zl['358']." <font size=1>(".$pi1.")</font>",$zl['358'],"element_menu_main.png");//����������
//		}
		
		//������ �� ���������� ������
		if (getconf("IS_SHOW_DCAGENT","VALUEINT")==1){
			$ps1=' '.getconf("DCAGENT_NAZV","VALUESTR");
			//�������
			leftmproc(getconf("DCAGENT_LINK","VALUESTR"),$zl['327'].$ps1,$zl['449'],"element_menu_dcagent.png");//������� ������ DC++
		}
//		if (getconf("ISNEWS","VALUEINT")==1){
//			//������� �������
//			leftmproc("subkat.php?type=shownews",$zl['44'],$zl['45'],"element_menu_main.png");//������������ � ���������
//		}
//		$pi1=recordcount_new("tbl_user");
//		//������������
//		leftmproc("user.php",$zl['46']." <font size=1>(".$pi1.")</font>",$zl['47'],"element_menu_users.png");//������ �������������
		?>
	</TABLE>
	<?php
	if ($ps_usercode!=""){
	?>

<!--// ��������� //!-->
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
			<TR valign=top>
				<TD width=200 class=table_menu height=14>
				<?php
				//���� ���������
				//������
				//��������
				$ps_div="lm_trouble";
				?>
				<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_trouble.png" border=0 height=16 title="<?php echo $zl['519']?>: <?php echo $zl['481']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['519']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_off.png" border=0 height=16 title="<?php echo $zl['481']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_trouble.png" border=0 height=16 title="<?php echo $zl['519']?>: <?php echo $zl['482']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['519']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_on.png" border=0 height=16 title="<?php echo $zl['482']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				</TD>
			</TR>
		</TABLE>
			<?php
			$ps_div="lm_trouble";
			?>
			<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> >
			<TABLE cellSpacing=0 cellPadding=0 width=200 valign=top class=table_leftmenu_user border=0>
				<TR>		
					<TD width=5></TD>		
						<TD class=table_leftmenu_user_menu>
							<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
								<?php
								//�������� ���������
								leftmproc2("javascript:OpenDoc('trouble.php?type=new',".rndwindow().")",$zl['520'],$zl['521'],"element_menu_trouble_new.png");//�������� ��������� ������������
								$pi1=recordcount_new("tbl_trouble where TOCODE=".$ps_usercode);
								$ps1='';
								if ($pi1>0) $ps1=" <font size=1>(".$pi1.")</font>";
								//��������
								leftmproc2("trouble.php?type=msgin",$zl['523'].$ps1,$zl['523'],"element_menu_trouble_send.png");
								$ps1='';
								$pi1=recordcount_new("tbl_trouble where FROMCODE=".$ps_usercode);
								if ($pi1>0) $ps1=" <font size=1>(".$pi1.")</font>";
								//������������
								leftmproc2("trouble.php?type=msgsend",$zl['522'].$ps1,$zl['522'],"element_menu_trouble_in.png");
								?>
							</TABLE>
						</TD>
					<TD width=4></TD>
				</TR>
			</TABLE>
			</div>


<!--// ���� ������������ //!-->
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
			<TR valign=top>
				<TD width=200 class=table_menu height=14>
				<?php
				//���� ������������
				//������
				//��������
				$ps_div="lm_user";
				?>
				<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_user.png" border=0 height=16 title="<?php echo $zl['483']?>: <?php echo $zl['481']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['483']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_off.png" border=0 height=16 title="<?php echo $zl['481']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_user.png" border=0 height=16 title="<?php echo $zl['483']?>: <?php echo $zl['482']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['483']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_on.png" border=0 height=16 title="<?php echo $zl['482']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				</TD>
			</TR>
		</TABLE>
			<?php
			$ps_div="lm_user";
			?>
			<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> >				
			<TABLE cellSpacing=0 cellPadding=0 width=200 valign=top class=table_leftmenu_user border=0>
				<TR>		
					<TD width=5></TD>		
						<TD class=table_leftmenu_user_menu>
							<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
							<?php
							if ($zright['DO_ADD']==1){
								//�������� �������
								leftmproc2("topic.php?type=new",$zl['49'],$zl['50'],"element_menu_rozd.png");//�������� ����� �������
								$pi1=recordcount_new("tbl_base where ISMODER=1 and ISDOPEDIT=0 and WHOADD=".$ps_usercode);
								if ($pi1>0){
									//��� �������
									leftmproc2("subkat.php?type=mylink",$zl['51']." <font size=1>(".$pi1.")</font>",$zl['51'],"element_menu_moi.png");
								}
								$pi1=recordcount_new("tbl_base where ISMODER=0 and ISDOPEDIT=1 and WHOADD=".$ps_usercode);
								if ($pi1>0){
									//����������
									leftmproc2("subkat.php?type=onmoderedit",$zl['52']." <font size=1>(".$pi1.")</font>",$zl['53'],"element_menu_dorab.png");//������� �� ���������
								}
								$pi1=recordcount_new("tbl_base where ISMODER=0 and ISDOPEDIT=0 and WHOADD=".$ps_usercode);
								if ($pi1>0){
									//�� ���������
									leftmproc2("subkat.php?type=onmoder",$zl['54']." <font size=1>(".$pi1.")</font>",$zl['55'],"element_menu_onmod.png");//������� �� ���������
								}
							}
							if ($zright['DO_PERS']==1 && getconf("ISPERSENABLED","VALUEINT")==1){
								//�������� ����������
								leftmproc2("persona.php?type=new",$zl['375'],$zl['375'],"element_menu_pers.png");
								$pi1=recordcount_new("tbl_persona where ISMODER=1 and ISDOPEDIT=0 and WHOADD=".$ps_usercode);
								if ($pi1>0){
									//��� ����������
									leftmproc2("subkat.php?type=mypersona",$zl['376']." <font size=1>(".$pi1.")</font>",$zl['376'],"element_menu_moipers.png");
								}
								$pi1=recordcount_new("tbl_persona where ISMODER=0 and ISDOPEDIT=1 and WHOADD=".$ps_usercode);
								if ($pi1>0){
									//����������
									leftmproc2("subkat.php?type=onmodereditpersona",$zl['52']." <font size=1>(".$pi1.")</font>",$zl['378'],"element_menu_dorabpers.png");//���������� �� ���������
								}
								$pi1=recordcount_new("tbl_persona where ISMODER=0 and ISDOPEDIT=0 and WHOADD=".$ps_usercode);
								if ($pi1>0){
									//�� ���������
									leftmproc2("subkat.php?type=onmoderpersona",$zl['54']." <font size=1>(".$pi1.")</font>",$zl['377'],"element_menu_onmodpers.png");//���������� �� ���������
								}
							}
							//�������
							leftmproc2("user.php?type=show&code=".$ps_usercode,$zl['56'].' <font size=1>('.getuserratings($ps_usercode).')</font>',$zl['57'],"element_menu_profile.png");//������ ��������
							?>
							</TABLE>
						</TD>
					<TD width=4></TD>
				</TR>
			</TABLE>
			</div>



<!--// ���� �������� //!-->
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
			<TR valign=top>
				<TD width=200 class=table_menu height=14>
				<?php
				//���� ��������
				//������
				//��������
				$ps_div="lm_news";
				?>
				<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_news.png" border=0 height=16 title="<?php echo $zl['485']?>: <?php echo $zl['481']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['485']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_off.png" border=0 height=16 title="<?php echo $zl['481']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_news.png" border=0 height=16 title="<?php echo $zl['485']?>: <?php echo $zl['482']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['485']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_on.png" border=0 height=16 title="<?php echo $zl['482']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				</TD>
			</TR>
		</TABLE>
		<?php
		$ps_div="lm_news";
		?>
		<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> >				
			<TABLE cellSpacing=0 cellPadding=0 width=200 valign=top class=table_leftmenu_user border=0>
				<TR>		
					<TD width=5></TD>
						<TD class=table_leftmenu_user_menu>
							<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
							<?php
							$rs_2=mysql_query("select * from tbl_user where CODE=".$ps_usercode,$conn1);
								$rs=mysql_fetch_array($rs_2);
								$pd1=$rs['LASTNEWS'];
								$pd2=$rs['LASTNEWSCOMMENT'];
								$pd3=$rs['LASTNEWSPOSTER'];
								$pd4=$rs['LASTNEWSPERSONA'];
							mysql_free_result($rs_2);
							$pi1=recordcount_new("tbl_base where ISMODER=1 and DATEMODER>'".$pd1."'");
							//����� �������
							leftmproc2("subkat.php?type=lastnews",$zl['167']." <font size=1>(".$pi1.")</font>",$zl['58'],"element_menu_nov.png");//����� ������� � ���������� ������
							if ($ps_comment==1){
								$pd1=$pd2;
								$pi1=recordcount_new("tbl_comment where ISMODER=1 and DATEADD>'".$pd1."'");
								//����� �����������
								leftmproc2("subkat.php?type=lastcomment",$zl['168']." <font size=1>(".$pi1.")</font>",$zl['59'],"element_menu_com.png");//����� ����������� � ���������� ������
							}
							$pd1=$pd3;
							$pi1=recordcount_new("tbl_poster where ISMODER=1 and DATEADD>'".$pd1."'");
							//����� ���������
							leftmproc2("subkat.php?type=lastposter",$zl['60']." <font size=1>(".$pi1.")</font>",$zl['61'],"element_menu_screen.png");//����� ��������� � ���������� ������
							$pi1=recordcount_new("tbl_persona where ISMODER=1 and DATEMODER>'".$pd4."'");
							if (getconf("ISPERSENABLED","VALUEINT")==1){
								//����� ����������
								leftmproc2("subkat.php?type=lastpersona",$zl['388']." <font size=1>(".$pi1.")</font>",$zl['389'],"element_menu_novpers.png");//����� ���������� � ���������� ������
							}
							//��� �����������
							//������� ��� �����������
							$pi1=recordcount_new("tbl_fav where USERCODE=".$ps_usercode);
							//������� - ������� ���������
							$pi2=0;
							$ps1='';
							if ($pi1>0){
								$ps_constr="select tbl_fav.CODE from tbl_fav,tbl_base where tbl_fav.USERCODE=".$ps_usercode." and tbl_fav.BASECODE=tbl_base.CODE and tbl_fav.DATELAST<=tbl_base.DATEMODER";
								$pi2=recordcount($ps_constr);
							}
							if ($pi2>0) $ps1='<img src="main/color/scheme/'.$ps_color.'/element_menu_modernoteupd.gif" border=0 title="'.$zl['445'].'">';
							leftmproc2("subkat.php?type=fav",$zl['491']." <font size=1>(".$pi1."/".$pi2.")</font>".$ps1,$zl['492'],"element_menu_fav.png");
							if (getconf("ISWANTED","VALUEINT")==1){
								//���� �������
								$pi1=recordcount_new("tbl_wanted where PRIMARYCODE=0 and ISDO=0");
								$pi2=recordcount_new("tbl_wanted where PRIMARYCODE=0 and ISDO=0 and WHOADD=".$ps_usercode);
								//������� ���� �� ����������� �� �����������
								$pi3=0;
								if ($pi2>0){
									$rs_2 = mysql_query("select * from tbl_wanted where ISDO=0 and WHOADD=".$ps_usercode,$conn1);
										while (($rs=mysql_fetch_assoc($rs_2))!==false){
											$pi3=$pi3+recordcount_new("tbl_wanted where PRIMARYCODE=".$rs['CODE']." and ISDO=0");
										}
									mysql_free_result($rs_2);								
								}
								$ps1='';
								//���� ���������� ������
								if ($pi3>0) $ps1='<img src="main/color/scheme/'.$ps_color.'/element_menu_modernoteupd.gif" border=0 title="'.$zl['614'].'">';
								$ps2='';
								if ($pi1>0) $ps2=" <font size=1>(".$pi1.")</font>";
								if ($pi2>0) $ps2=" <font size=1>(".$pi1."/".$pi2.")</font>";
								if ($pi3>0) $ps2=" <font size=1>(".$pi1."/".$pi2."/".$pi3.")</font>";
								//���� �������
								leftmproc2("wanted.php",$zl['615'].$ps2.$ps1,$zl['615'],"element_menu_wanted.png");
							}
							?>
							</TABLE>
						</TD>
					<TD width=4></TD>
				</TR>
			</TABLE>
			</div>
	

<!--// ������������� ���� //!-->
	<?php
	if ($zright['DO_MODER']==1 || $zright['DO_USER']==1){
	?>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
			<TR valign=top>
				<TD width=200 class=table_menu height=14>
				<?php
				//���� ����������
				//������
				//��������
				$ps_div="lm_moder";
				?>
				<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_moder.png" border=0 height=16 title="<?php echo $zl['480']?>: <?php echo $zl['481']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['480']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_off.png" border=0 height=16 title="<?php echo $zl['481']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_moder.png" border=0 height=16 title="<?php echo $zl['480']?>: <?php echo $zl['482']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['480']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_on.png" border=0 height=16 title="<?php echo $zl['482']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				</TD>
			</TR>
		</TABLE>

		<?php
		//������ 3 - ���������
		if ($zright['DO_MODER']==1 || $zright['DO_USER']==1){
			$ps_div="lm_moder";
			?>
			<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> >
			<TABLE cellSpacing=0 cellPadding=0 width=200 valign=top class=table_leftmenu_user border=0>
				<TR>		
					<TD width=5></TD>
						<TD class=table_leftmenu_user_menu>
							<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
								<?php
								if ($zright['DO_MODER']==1){
									//��������� ������
									$pi1=recordcount_new("tbl_base where ISMODER=0 and ISDOPEDIT=0");
									leftmproc2("subkat.php?type=ismoder",$zl['48']." <font size=1>(".$pi1.")</font>",$zl['48'],"element_menu_moder.png");
									if (getconf("ISADDALTLINKS","VALUEINT")==1){
										//��������� ������
										$pi1=recordcount("select tbl_link.CODE from tbl_link,tbl_base where tbl_link.ISMODER=0 and tbl_link.BASECODE=tbl_base.CODE and tbl_base.ISMODER=1");
										leftmproc2("subkat.php?type=ismoderaltlink",$zl['461']." <font size=1>(".$pi1.")</font>",$zl['462'],"element_menu_moderaltlink.png");//��������� ������ �� ������ �������������
									}
									if (getconf("ISPERSENABLED","VALUEINT")==1){
										//��������� ����������
										$pi1=recordcount_new("tbl_persona where ISMODER=0 and ISDOPEDIT=0");
										leftmproc2("subkat.php?type=ismoderpersona",$zl['380']." <font size=1>(".$pi1.")</font>",$zl['48'],"element_menu_moderpersona.png");
									}
									$pi1=recordcount_new("tbl_base where ISMODER=0 and ISDOPEDIT=1");
									if ($pi1>0){
										//�� ���������
										leftmproc2("subkat.php?type=onmoderedit&type2=all",$zl['567']." <font size=1>(".$pi1.")</font>",$zl['53'],"element_menu_dorab.png");//������� �� ���������
									}
									//�������� ��������� ��������� � ��������
									$ps1='';
									$rs_2=mysql_query("select CODE from tbl_modernote order by DATEADD desc limit 1",$conn1);
										$rs=mysql_fetch_array($rs_2);
										$pd1=$rs['CODE'];
									mysql_free_result($rs_2);									
									$pd2=requestcookie("mg_modernote");
									if ($pd1!=$pd2) $ps1='<img src="main/color/scheme/'.$ps_color.'/element_menu_modernoteupd.gif" border=0 title="'.$zl['445'].'">';
									//������� �����������
									//�������� ������
									leftmproc2("subkat.php?type=modernote",$zl['432'].$ps1,$zl['433'],"element_menu_modernote.png");
								}
								if ($zright['DO_USER']==1){
									//���������� �� IP
									//������ �������������� IP
									$pi1=recordcount_new("tbl_banip");
									leftmproc2("user.php?type=banlist",$zl['434']." <font size=1>(".$pi1.")</font>",$zl['435'],"element_menu_banlist.png");
								}
								?>
							</TABLE>
						</TD>
					<TD width=4></TD>
				</TR>
			</TABLE>
			</div>
			<?php
		}
	}
	?>


<!--// ������ ��������� //!-->
	<?php
	if ($zright['DO_MODER']==1 || $zright['DO_SET']==1){
	?>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
			<TR valign=top>
				<TD width=200 class=table_menu height=14>
				<?php
				//���� ���������
				//������
				//��������
				$ps_div="lm_set";
				?>
				<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_set.png" border=0 height=16 title="<?php echo $zl['486']?>: <?php echo $zl['481']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['486']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_off.png" border=0 height=16 title="<?php echo $zl['481']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<TR valign=middle>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/element_lm_set.png" border=0 height=16 title="<?php echo $zl['486']?>: <?php echo $zl['482']?>">
							</TD><TD width=3>&nbsp;</TD>
							<TD width=143 class=f9>
								&nbsp;<font color="<?php echo $zcmas[50]?>"><?php echo $zl['486']?></font>
							</TD>
							<TD width=25 align=center>
								&nbsp;<img src="main/color/scheme/<?php echo $ps_color;?>/menu_mess_on.png" border=0 height=16 title="<?php echo $zl['482']?>">
							</TD>
						</TR>
					</TABLE>
				</div>
				</TD>
			</TR>
		</TABLE>

		<?php
		//������ 3 - ���������
		if ($zright['DO_MODER']==1 || $zright['DO_SET']==1){
			$ps_div="lm_set";
			?>
			<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_mg_".$ps_div)!=1) echo 'style="display:none"';?> >				
			<TABLE cellSpacing=0 cellPadding=0 width=200 valign=top class=table_leftmenu_user border=0>
				<TR>		
					<TD width=5></TD>
						<TD class=table_leftmenu_user_menu>
							<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
								<?php
								if ($zright['DO_KAT']==1){
									//���������
									leftmproc2("kat.php?type=edit",$zl['62'],$zl['63'],"element_menu_download.png");//���������� �����������
								}
								if ($zright['DO_SET']==1){
									//���������
									leftmproc2("settings.php",$zl['64'],$zl['65'],"element_menu_conf.png");//��������� �������
								}
								?>
							</TABLE>
						</TD>
					<TD width=4></TD>
				</TR>
			</TABLE>
			</div>
			<?php
		}
		
	}
}
	?>


<!--// ����� //!-->
	<?php
	if (getconf("ISFINDLEFT","VALUEINT")==1){
		//�����
		//������ ������ ������
		?>
		<script>
			var xmlHttp;
			function showResultMagneto(str){
				if (str.length==0){ 
					document.getElementById("magneto_search").innerHTML="";
					document.getElementById("magneto_search").style.display="none";
					return;
				}
				xmlHttp=GetXmlHttpObject();
				if (xmlHttp==null){
					//alert ("������� �� ������������ HTTP-Request");
					return;
				} 
				var url="topic.php?type=new_pre2";
				//url=url+"?search="+encodeURIComponent(str);
				url=url+"&search="+str;
				url=url+"&stest=���";
				url=url+"&randoms="+Math.random();
				xmlHttp.onreadystatechange=stateChangedMagneto;
				xmlHttp.open("GET",url,true);
				xmlHttp.send(null);
			}
			function stateChangedMagneto(){ 
				if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
					{ 
					document.getElementById("magneto_search").innerHTML=xmlHttp.responseText;
					document.getElementById("magneto_search").style.display="";
				} 
			}
			function GetXmlHttpObject(){
				var xmlHttp=null;
				try{
					// Firefox, Opera 8.0+, Safari
					xmlHttp=new XMLHttpRequest();
				}catch (e){
					// Internet Explorer
					try{
						xmlHttp=new ActiveXObject("Microsoft.XMLHttp");
					}catch (e){
						try{
							xmlHttp=new ActiveXObject("MSXML2.XMLHttp");
						}catch (e){
							try{
								xmlHttp=new ActiveXObject("MSXML2.XMLHttp.3.0");
							}catch (e){
								try{
									xmlHttp=new ActiveXObject("MSXML2.XMLHttp.4.0");
								}catch (e){
									xmlHttp=new ActiveXObject("MSXML2.XMLHttp.5.0");
								}
							}
						}
					}
				}
				return xmlHttp;
			}		
		</script> 			
		<TABLE width="200" height=30 cellSpacing="0" cellPadding="0" border=0 class=table_leftmenu_user>
			<FORM name="frmfind" METHOD="send" ACTION="subkat.php">
			<TR height="30">
				<TD class=f11 align="center"> 
	      			<input type="hidden" name="type" value="find">
	      			<input class=input3 type="text" name="search" size="18" maxlength="25" value="<?php echo $ps_search?>" onFocus="id=className;" onblur="id=''" onkeyup="showResultMagneto(this.value); return true;">
					<input type="checkbox" name="fullsearch" value="1" title="<?php echo $zl['496']?>">      	
	      			<input type="submit" class=inputb3 value="<?php echo $zl['267']?>" onMouseOver="id=className" onMouseOut="id=''">
					<div id="magneto_search" align=left></div>
				</TD>
			</TR>
			</FORM>
		</TABLE>
	    <?php
	}else{
		?>
		<TABLE width="200" height=8 cellSpacing="0" cellPadding="0" border=0 class=table_leftmenu_user>
			<TR height="4">
				<TD> 
				</TD>
			</TR>
		</TABLE>
	    <?php
	}
    //chat
    $ps_ischat=getconf("ISCHAT","VALUEINT");
    if ($ps_ischat==1){
    	//��������� ������� �� � ����� ���
    	if ($ps_usercode>0){
			$rs_2=mysql_query("select ISCHAT from tbl_user where CODE=".$ps_usercode,$conn1);
				$rs=mysql_fetch_array($rs_2);
				$ps_ischat2=$rs['ISCHAT'];
			mysql_free_result($rs_2);  
			if ($ps_ischat2=='0' || $ps_ischat2=='') $ps_ischat=0;
		}
    	if ($ps_ischat==1){
			?>
			<TABLE width="200" cellSpacing="0" cellPadding="0" border=0 class=table_leftmenu_user>
				<?php
				if (maycomment($ps_usercode)==1){
			    	?>			
					<TR height=1>
						<TD>
						</TD>			
						<TD>
						</TD>
						<TD>
						</TD>			
					</TR>
					<?php
				}
				?>
				<TR>
					<TD width=8>
					</TD>			
					<TD class=table_leftmenu_user_menu>
						<iframe frameborder=0 scrolling="auto" src='chat.php' height=240 width=188></iframe>
					</TD>
					<TD width=4>
					</TD>			
				</TR>
				<?php
				//��������� ����� �������� ���
				if ($zright['DO_MODER']==1){
					?>
					<TR height=8 class=f9b>
						<TD>
						</TD>			
						<TD align=center height=10>
							<?php
							//��������� ����� �������� ���
							if ($zright['DO_MODER']==1){
								//�������� ���� ����
								//������������� �������� ���� ����?
								?>
								<img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=10 height=10>
								<a href="chat.php?type=clearchat" title="<?php echo $zl['68']?>" class=link1 OnClick="return confirm('<?php echo $zl['69']?>'); return true;"><?php echo $zl['68']?></a>
								<?php
							}
							?>
						</TD>
						<TD>
						</TD>			
					</TR>
					<?php
				}
				?>
			</TABLE>
			<TABLE width="200" height=1 cellSpacing="0" cellPadding="0" border=0 class=table_leftmenu_user>
				<TR>
					<TD>
					</TD>
				</TR>
			</TABLE>		    	
			<?php
	    	//� ��� ������ ���� ���, � ���� ��������� ����������
	    	if (maycomment($ps_usercode)==1){
	    		//� ���
		    	?>
				<TABLE width="200" height=30 cellSpacing="0" cellPadding="0" border=0 class=table_leftmenu_user>
					<FORM name="frmchat" METHOD="send" ACTION="chat.php" onsubmit="return check();">
						<TR height="30">
							<TD width=8>
							</TD>			
							<script type="text/javascript" language="JavaScript">
								function check()
									{
									var ps1=document.getElementById("opis").value;
									document.getElementById("opis").value="";
									msgtochat(ps1);
									return false;
								}
							</script>
							<script>
								var xmlHttp;
								function msgtochat(str){
									document.frmchat.opis.value='';
									xmlHttp=GetXmlHttpObject();
									if (xmlHttp==null){
										//alert ("������� �� ������������ HTTP-Request");
										return;
									} 
									var url="chat.php";
									//url=url+"?type=addmsg&opis="+encodeURIComponent(str);
									url=url+"?type=addmsg&opis="+str;
									xmlHttp.open("GET",url,true);
									xmlHttp.send(null);
									parent.frames[0].location = "chat.php";
								}
								function GetXmlHttpObject(){
									var xmlHttp=null;
									try{
										// Firefox, Opera 8.0+, Safari
										xmlHttp=new XMLHttpRequest();
									}catch (e){
										// Internet Explorer
										try{
											xmlHttp=new ActiveXObject("Microsoft.XMLHttp");
										}catch (e){
											try{
												xmlHttp=new ActiveXObject("MSXML2.XMLHttp");
											}catch (e){
												try{
													xmlHttp=new ActiveXObject("MSXML2.XMLHttp.3.0");
												}catch (e){
													try{
														xmlHttp=new ActiveXObject("MSXML2.XMLHttp.4.0");
													}catch (e){
														xmlHttp=new ActiveXObject("MSXML2.XMLHttp.5.0");
													}
												}
											}
										}
									}
									return xmlHttp;
								}
							</script> 							
							<TD class=table_int_table align=center>
				      			<input type="hidden" name="type" value="addmsg">
				      			<input type="hidden" name="type2" value="restore">
				      			<input class=input2 type="text" name="opis" size="17" maxlength="250" value="" onFocus="id=className;" onblur="id=''">
				      			<input type="submit" class=inputb3 value="<?php echo $zl['67']?>" onMouseOver="id=className" onMouseOut="id=''">
							</TD>
							<TD width=4>
							</TD>			
						</TR>
					</FORM>
				</TABLE>
				<TABLE width="200" height=10 cellSpacing="0" cellPadding="0" border=0 class=table_leftmenu_user>
					<TR>
						<TD>

						</TD>
					</TR>
				</TABLE>
				<script type="text/javascript" language="JavaScript">
						{    
						document.frmchat.opis.value='';
						}
				</script>	  					
				<?php
			}
		}
    }
    ?>
	<TABLE cellSpacing=0 cellPadding=0 width=200 border=0 class=table_leftmenu>
		<?php 
		//������� ���������
		if ($ps_menukat==""){
			$ps_menukat=requestdata("menukat");
		}
		$rs_2 = mysql_query("select * from tbl_kat order by POSITION,NAZV",$conn1);
			while (($rs=mysql_fetch_assoc($rs_2))!==false) {
				$ps_c="";
				$pi1=recordcount_new("tbl_base where ismoder=1 and KAT=".$rs['CODE']);
				if ($pi1>0) $ps_c=" <font size=1>(".$pi1.")</font>";
				leftmproc("kat.php?type=showkat&type2=".$rs['CODE'],$rs['NAZV'].$ps_c,$rs['NAZV'],"element_menu_kat.png");
				if (($ps_type2==$rs['CODE'] && $ps_type=="showkat") || $ps_kat==$rs['CODE'] || $ps_menukat==$rs['CODE']){
					?>
					<TR>
						<TD width=24>
						</TD>
						<TD width=188 class=table_leftmenu_subkat>
							<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=middle>
								<?php
								$rs2_2 = mysql_query("select * from tbl_subkat where KATCODE=".$rs['CODE']." order by POSITION,NAZV",$conn1);
									while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
										$ps_c="";
										$pi1=recordcount_new("tbl_base where ismoder=1 and (SUBKAT1=".$rs2['CODE']." or SUBKAT2=".$rs2['CODE']." or SUBKAT3=".$rs2['CODE'].")");
										if ($pi1>0) $ps_c=" (".$pi1.")";
										leftmproc2("subkat.php?type=showsubkat&type2=".$rs2['CODE'],$rs2['NAZV'].$ps_c,$rs2['NAZV'],"element_menu_subkat.png");
									}
								mysql_free_result($rs2_2);		
								?>
							</TABLE>
						</TD>
						<TD width=4>
						</TD>
					</TR>
					<?php
				}				
			}
		mysql_free_result($rs_2);		
	?>


	<table cellSpacing=0 cellPadding=0 border=0>
		<td width="200px" height="1px" bgcolor="<?php echo $zcmas[4]?>"></td>
	</table>


	<br>
  	<TABLE cellSpacing=4 cellPadding=4 width=90% align=center valign=middle border=0>
  		<TR class=f9 width=200 height=30>

  			<td width=50% align=right valign=middle>
			<a href="rss/index.php" target="_blank" title="RSS-<?php echo $zl['418'].' - '.getconf("PROJECTNAME","VALUESTR")?>">
			<img src="main/color/scheme/<?php echo $ps_color;?>/rss.gif" width=25 height=25 border=0>
			</a>
			</td>

		<?php
	//vkontakte
		if (getconf("ISVKONTAKTE","VALUEINT")==1){
		//���� ������ ���������
			?>
			<td width=50% align=left valign=middle>
			<a href="<?php echo getconf("LINKVKONTAKTE","VALUESTR")?>" target="_blank" title="<?php echo $zl['664']?>">
			<img src="main/color/scheme/<?php echo $ps_color;?>/vkontakte.png" width=25 height=25 border=0>
			</a>
			</td>
		<?php
		}
		?>
		</TR>
	</TABLE>




	<br>
</TD>

<TD width=1>&nbsp;</TD>

<?php

function leftmproc($ps_url,$ps_name,$ps_title, $ps_eskiz){
	global $ps2,$ps_color;
	$ps5=$ps_url;
	$pi5=rndwindow();
	?>
	<TR height=24>

		<TD width=28 align=center>
			<img src="main/color/scheme/<?php echo $ps_color; ?>/<?php echo $ps_eskiz?>" name="<?php echo str_replace(".","",$ps_eskiz)?>_1_<?php echo $pi5?>" width=16 height=16>
		</TD>
		<TD class=f9<?php if (ucase($ps2)==ucase($ps5)) echo "b";?>>
			<a class="link2" href="<?php echo $ps_url?>" title="<?php echo $ps_title?>" onMouseOver="window.status=''; ICOIn('<?php echo str_replace(".","",$ps_eskiz)?>_1_<?php echo $pi5?>'); return true;" onmouseout="ICOOut('<?php echo str_replace(".","",$ps_eskiz)?>_1_<?php echo $pi5?>'); return true;">
	  		<?php echo $ps_name?></a>
		</TD>

	</TR>
	<?php
return;
}


function leftmproc2($ps_url,$ps_name,$ps_title, $ps_eskiz){
	global $ps2,$ps_color;
	$ps5=$ps_url;
	$pi5=rndwindow();
	if ($_SERVER['QUERY_STRING']!=""){
		$ps3="http://".$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING']; 
	}else{
		$ps3="http://".$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF']; 
	}
	?>
	<TR height=22>
		<TD width=100%>
			<TABLE width=100% height=100% border=0 cellSpacing=0 cellPadding=0 >
				<TR height=100%>
					<TD width=24 align=center>
						<img src="main/color/scheme/<?php echo $ps_color; ?>/<?php echo $ps_eskiz?>" width=16 height=16 name="<?php echo str_replace(".","",$ps_eskiz)?>_2_<?php echo $pi5?>">
					</TD>
					<TD class=f8<?php if (ucase($ps3)==ucase($ps_url)) echo "b";?>>
						<a class="link2" href="<?php echo $ps_url?>" title="<?php echo $ps_title ?>" onMouseOver="window.status=''; ICOIn('<?php echo str_replace(".","",$ps_eskiz)?>_2_<?php echo $pi5?>'); return true;" onmouseout="ICOOut('<?php echo str_replace(".","",$ps_eskiz)?>_2_<?php echo $pi5?>'); return true;">
				  		<?php echo $ps_name?></a>
					</TD>
				</TR>
			</TABLE>
		</TD>
	</TR>
	<?php
return;
}
?>
