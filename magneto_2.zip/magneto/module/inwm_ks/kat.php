<?php
//require_once('main/config/functlist.php' );
require_once('inc_katfunct.php' );
openconn1();

verifyuser();
iswork();

if ($ps_type=="delkat" || $ps_type=="editdopf" || $ps_type=="editdopf2" || $ps_type=="delsubkat" || $ps_type=="edit" || $ps_type=="edit2") dopverify("DO_KAT");
	
if ($ps_type=="editdopf") $ps_style="short";

if ($ps_type2!="") $ps_katname=getkatname($ps_type2);


//======================================================
if ($ps_type=="editdopf2"){
	$ps_dopf1=requestdata('dopf1');
	$ps_dopf2=requestdata('dopf2');
	$ps_dopf3=requestdata('dopf3');
	$ps_dopf4=requestdata('dopf4');
	$ps_dopf5=requestdata('dopf5');
	//��������� - ���� �� ����� ������
	$rs_2=mysql_query("select * from tbl_dopf where KATCODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['CODE']==''){
			$ps_constr="insert into tbl_dopf (KATCODE,DOPF1,DOPF2,DOPF3,DOPF4,DOPF5) values (".$ps_code.",'".$ps_dopf1."','".$ps_dopf2."','".$ps_dopf3."','".$ps_dopf4."','".$ps_dopf5."')";
		}else{
			$ps_constr="update tbl_dopf set DOPF1='".$ps_dopf1."',DOPF2='".$ps_dopf2."',DOPF3='".$ps_dopf3."',DOPF4='".$ps_dopf4."',DOPF5='".$ps_dopf5."' where CODE=".$rs['CODE'];
		}
	mysql_free_result($rs_2);	
	$rs_s2=mysql_query($ps_constr,$conn1);
	goback();
}


//======================================================
if ($ps_type=="delkat"){
	//���� ���� ������������ - �� ������� ������
	if (recordcount_new("tbl_subkat where KATCODE=".$ps_type2)==0){
		$rs_s2=mysql_query("delete from tbl_dopf where KATCODE=".$ps_type2,$conn1);	
		$rs_s2=mysql_query("delete from tbl_kat where CODE=".$ps_type2,$conn1);	
	}
	header("Location: kat.php?type=edit&msg=ok");
}

//======================================================
if ($ps_type=="delsubkat"){
	$rs_s2=mysql_query("delete from tbl_subkat where CODE=".$ps_type2,$conn1);	
	//� ���� ������ ��������� �� 0
	$rs_s2=mysql_query("update tbl_base set KAT1=99 where KAT1=".$ps_type2,$conn1);	
	$rs_s2=mysql_query("update tbl_base set KAT2=99 where KAT2=".$ps_type2,$conn1);	
	$rs_s2=mysql_query("update tbl_base set KAT3=99 where KAT3=".$ps_type2,$conn1);	
	header("Location: kat.php?type=edit&msg=ok");
}

//======================================================
if ($ps_type=="edit2"){
	$rs_2 = mysql_query("select * from tbl_kat",$conn1);
		while (($rs=mysql_fetch_assoc($rs_2))!==false) {
			$rs_s2=mysql_query("update tbl_kat set NAZV='".requestdata('kat_'.$rs['CODE'])."',POSITION=".requestdata('position_'.$rs['CODE'])." where CODE=".$rs['CODE'],$conn1);
			$rs2_2 = mysql_query("select * from tbl_subkat where KATCODE=".$rs['CODE'],$conn1);
				while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
					$rs_s2=mysql_query("update tbl_subkat set NAZV='".requestdata('subkat_'.$rs2['CODE'])."',POSITION=".requestdata('subposition_'.$rs2['CODE'])." where CODE=".$rs2['CODE'],$conn1);
				}
			mysql_free_result($rs2_2);
			if (requestdata("subkat_".$rs['CODE']."_n")!=""){
				$rs_s2=mysql_query("insert into tbl_subkat (KATCODE,NAZV,POSITION) values (".$rs['CODE'].",'".requestdata("subkat_".$rs['CODE']."_n")."',".requestdata("subposition_".$rs['CODE']."_n").")",$conn1);
			}
		}
	mysql_free_result($rs_2);
	if (requestdata("kat_n")!=""){
		$rs_s2=mysql_query("insert into tbl_kat (NAZV,POSITION) values ('".requestdata("kat_n")."',".requestdata("position_n").")",$conn1);
	}
	header("Location: kat.php?type=edit&msg=ok");
	exit;
}
?>
<HTML>
<HEAD>
	<?php
	$ps1="";
	if ($ps_type=="editdopf") $ps1=$zl['477'];//�������������� ���� ���������
	if ($ps_type=="edit") $ps1=$zl['63'];//���������� �����������
	if ($ps_type=="showkat") $ps1=$ps_katname;
	?>
	<TITLE><?php echo getconf("PROJECTNAME","VALUESTR").' - '.$ps1 ?></TITLE>
	<?php site_header()?>
</HEAD>
<BODY leftMargin=0 topMargin=0>
<?php 
if ($ps_style=="") require_once('inc_top.php');
?>
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	<TR valign=top>
		<?php 
		if ($ps_style=="") require_once('inc_left.php');
		?>

		<TD class=f10>
    		<?php




			//==========================================================================================
			if ($ps_type=="editdopf"){
				windowsize (450,650);
				?>
				<center>
				<br>
				<?php
				//�������������� ���� ���������
				us_text2($zl['477']);
				echo '<b><font size=3>'.getkatname($ps_code).'</font></b><br>';
				$rs_2=mysql_query("select * from tbl_dopf where KATCODE=".$ps_code,$conn1);
					$rs=mysql_fetch_array($rs_2);
					//�������� ���.����
					?>
					<form method="post" name="frmlogin" action="kat.php" border=0>
						<input type="hidden" name="type" value="<?php echo $ps_type?>2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<?php echo $zl['478']?> 1:
						<input type="text" name="dopf1" class=input2 size="50" maxlength="50" onFocus="id=className;" onBlur="id=''" value="<?php echo $rs['DOPF1']?>"><br>
						<br>
						<?php echo $zl['478']?> 2:
						<input type="text" name="dopf2" class=input2 size="50" maxlength="50" onFocus="id=className;" onBlur="id=''" value="<?php echo $rs['DOPF2']?>"><br>
						<br>
						<?php echo $zl['478']?> 3:
						<input type="text" name="dopf3" class=input2 size="50" maxlength="50" onFocus="id=className;" onBlur="id=''" value="<?php echo $rs['DOPF3']?>"><br>
						<br>
						<?php echo $zl['478']?> 4:
						<input type="text" name="dopf4" class=input2 size="50" maxlength="50" onFocus="id=className;" onBlur="id=''" value="<?php echo $rs['DOPF4']?>"><br>
						<br>
						<?php echo $zl['478']?> 5:
						<input type="text" name="dopf5" class=input2 size="50" maxlength="50" onFocus="id=className;" onBlur="id=''" value="<?php echo $rs['DOPF5']?>"><br>
						<br>
						<?php
						//��������
						inputstyle($zl['70']);
						?>
						<br>
						<br>
					</form>	
					<?php
				mysql_free_result($rs_2);				
			}











    		//===========================================================================================
    		if ($ps_type=="edit"){
    			//���������� �����������

				?>
				<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0>
					<TR><TD>
				<?php

    			us_text($zl['63']);

				?></TD></TR></TABLE><?php

    			if ($ps_msg=='ok') echo '<b>'.$zl['152'].'!</b><br>';//��������� �������
    			?>
				<center>
				<form method="post" name="frmlogin" action="kat.php">
					<input type="hidden" name="type" value="edit2">
		      		<TABLE cellSpacing=0 cellPadding=0 border=0>
						<?php
						$rs_2 = mysql_query("select * from tbl_kat order by NAZV",$conn1);
							while (($rs=mysql_fetch_assoc($rs_2))!==false) {
								//��������:
								?>
				      			<TR class=f10 valign=top height=50>
				      				<td>
				      					<?php echo $zl['108']?> <input type="text" name="kat_<?php echo $rs['CODE']?>" size="40" maxlength="100" class=input2 onFocus="id=className;" onBlur="id=''" value="<?php echo $rs['NAZV']?>"><br>
				      					<?php
										$rs2_2 = mysql_query("select * from tbl_subkat where KATCODE=".$rs['CODE']." order by POSITION, NAZV",$conn1);
											while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
												//�������� ������� �������� �� ���� ������������.
												$pi1=recordcount_new("tbl_base where SUBKAT1=".$rs2['CODE']." or SUBKAT2=".$rs2['CODE']." or SUBKAT3=".$rs2['CODE']);
												//������� ������������
												//�� ���� ������������ ���������������� ������:
												//������������� ������� ������������?
				      							?>
						      					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						      					<input type="text" name="subkat_<?php echo $rs2['CODE']?>" size="30" maxlength="100" class=input2 onFocus="id=className;" onBlur="id=''" value="<?php echo $rs2['NAZV']?>">
												<input type="text" name="subposition_<?php echo $rs2['CODE']?>" size="1" maxlength="5" class=input2 onFocus="id=className;" onBlur="id=''" value="<?php echo $rs2['POSITION']?>">
						      					<a title="<?php echo $zl['153']?>" href="kat.php?type=delsubkat&type2=<?php echo $rs2['CODE']?>" OnClick="return confirm('<?php echo $zl['154']?> <?php echo $pi1?>\n\n <?php echo $zl['155']?>'); return true;"><img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=16 height=16 border=0></a><br>
						      					<?php
											}
										mysql_free_result($rs2_2);
				      					?>
				      					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				      					<input type="text" name="subkat_<?php echo $rs['CODE']?>_n" size="30" maxlength="100" class=input2 onFocus="id=className;" onBlur="id=''" value="">
				      					<input type="text" name="subposition_<?php echo $rs['CODE']?>_n" size="1" maxlength="5" class=input2 onFocus="id=className;" onBlur="id=''" value="1"><br>
				      					<br>
									</td>
				      				<td width=150 align=center>
				      					<?php
				      					//�������
				      					?>
				      					<?php echo $zl['156']?>: <input type="text" name="position_<?php echo $rs['CODE']?>" size="5" maxlength="5" class=input2 onFocus="id=className;" onBlur="id=''" value="<?php echo $rs['POSITION']?>">
									</td>
				      				<td>
				      					<?php
			      						//������������� ���.���� ���������
			      						?>
			      						&nbsp;<a title="<?php echo $zl['476']?>" href="javascript:OpenDoc('kat.php?type=editdopf&code=<?php echo $rs['CODE']?>',<?php echo rndwindow()?>)"><img src="main/color/scheme/<?php echo $ps_color;?>/element_edit.png" width=16 height=16 border=0></a>
			      						<?php
				      					if (recordcount_new("tbl_subkat where KATCODE=".$rs['CODE'])==0){
				      						//������� ���������
				      						//������������� ������� ���������?
				      						?>
				      						&nbsp;<a title="<?php echo $zl['157']?>" href="kat.php?type=delkat&type2=<?php echo $rs['CODE']?>" OnClick="return confirm('<?php echo $zl['158']?>'); return true;"><img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=16 height=16 border=0></a>
				      						<?php
				      					}
				      					?>
									</td>
      							</tr>
      							<?php
							}
						mysql_free_result($rs_2);
						//��������:
						//�������
						?>
		      			<TR class=f10 height=40 valign=top>
		      				<td>
		      					<?php echo $zl['108']?> <input type="text" name="kat_n" size="40" maxlength="100" class=input2 onFocus="id=className;" onBlur="id=''" value=""><br>
							</td>
		      				<td width=150 align=center>
		      					<?php echo $zl['156']?>: <input type="text" name="position_n" size="5" maxlength="5" class=input2 onFocus="id=className;" onBlur="id=''" value="1">
							</td>
		      				<td>
							</td>
						</tr>
					</table>
					<?php 
					//���������
					inputstyle($zl['75']);
					?>
				</form>
    			<br>
    			<?php
			}



    		//===========================================================================================
    		if ($ps_type=="showkat"){
				//���� ������
	      		if (getconf("ISFINDTOP_2","VALUEINT")==1){
	      			?>
					<script>
						var xmlHttp;
						function showResultMagneto2(str){
							if (str.length==0){ 
								document.getElementById("magneto_search_top").innerHTML="";
								document.getElementById("magneto_search_top").style.display="none";
								return;
							}
							xmlHttp=GetXmlHttpObject();
							if (xmlHttp==null){
								//alert ("������� �� ������������ HTTP-Request");
								return;
							} 
							var url="index.php?type=new_pre";
							//url=url+"?search="+encodeURIComponent(str);
							url=url+"&search="+str;
							url=url+"&stest=���";
							url=url+"&randoms="+Math.random();
							xmlHttp.onreadystatechange=stateChangedMagneto2;
							xmlHttp.open("GET",url,true);
							xmlHttp.send(null);
						}
						function stateChangedMagneto2(){ 
							if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
								{ 
								document.getElementById("magneto_search_top").innerHTML=xmlHttp.responseText;
								document.getElementById("magneto_search_top").style.display="";
							} 
						}
					</script> 			
		      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
						<FORM name="frmfind" METHOD="send" ACTION="subkat.php">
			      			<TR class=f10>
				      			<?php
				      			//�����
				      			//� ���
		      					?>
			      				<td valign=top align=center>
						      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat>

								<?php pan_search(); ?>

									<TR height=30>
						      				<td class=f10 align=center>
								      			<input type="hidden" name="type" value="find">
												&nbsp;<b><?php echo $zl['594']?></b>
								      			<input class=input type="text" name="search" size="70" maxlength="25" value="<?php echo $ps_search?>" onFocus="id=className;" onblur="id=''" onkeyup="showResultMagneto2(this.value); return true;">
												<input type="checkbox" name="fullsearch" value="1" title="<?php echo $zl['496']?>">      	
								    			<font size=1><?php echo lcase($zl['496'])?></font>
								      			&nbsp;&nbsp;&nbsp;
								    			<input type="submit" class=inputb3 value="<?php echo $zl['267']?>" onMouseOver="id=className" onMouseOut="id=''"><br>
												<div id="magneto_search_top" align=left></div>
						      				</TD>
						      			</TR>					      									
						      		</TABLE>
						      	</td>
							</TR>
						</FORM>					      					
		      		</table>
				<br>
	    			<?php
	    		}       			

				?>
				<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0>
					<TR><TD>
				<?php

    			us_text($ps_katname);

				?></TD></TR></TABLE><?php

    			?>
    			<br>
	      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	      			<TR class=f10>
		      			<?php
		      			$pi1=0;
						$rs_2 = mysql_query("select * from tbl_subkat where KATCODE=".$ps_type2." order by POSITION, NAZV",$conn1);
							while (($rs=mysql_fetch_assoc($rs_2))!==false) {
		      					$pi1=$pi1+1
		      					?>
			      				<td valign=top width="50%">
						      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat onMouseOver="id=className" onMouseOut="id=''">
						      			<TR class=f10 height=16>
						      				<td>
									      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
									      			<TR class=f10 height=16>
									      				<td width=25 align=center>
						      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
						      							</TD>
									      				<td>
									      					<b><a class=link1 href="subkat.php?type=showsubkat&type2=<?php echo $rs['CODE']?>"><font color="<?php echo $zcmas[50]?>"><?php echo $rs['NAZV']?></font></a></b>
									      					<?php
															$pi2=recordcount_new("tbl_base where ISMODER=1 and (SUBKAT1=".$rs['CODE']." or SUBKAT2=".$rs['CODE']." or SUBKAT3=".$rs['CODE'].")");
									      					if ($pi2>0) echo ' <i><font color='.$zcmas[50].'>('.$pi2.')</font></i>';
									      					?>
						      							</TD>
													<?php viewcategory($ps_katname); ?>
						      						</TR>
						      					</TABLE>
						      				</TD>
						      			</TR>
						      			<TR class=f10>
						      				<td>
						      					<?php
						      					if ($pi2==0){
						      						//������ ���
						      						?>
					      							<br>
					      							<center>
					      							<b><?php echo $zl['159']?></b><br>
					      							<br>
					      							</center>
					      							<?php
					      						}else{
													$rs2_2=mysql_query("select * from tbl_base where ISMODER=1 and (SUBKAT1=".$rs['CODE']." or SUBKAT2=".$rs['CODE']." or SUBKAT3=".$rs['CODE'].") order by DATEMODER desc limit 1",$conn1);
														$rs2=mysql_fetch_array($rs2_2);
														$ps_subkat3=$rs['CODE'];
														viewinfo($rs2['CODE']);
													mysql_free_result($rs2_2);
					      						}
						      					?>
						      				</TD>
						      			</TR>
						      		</TABLE>
			      				</td>
			      				<?php
			      				if (fmod($pi1,2)!=0){
				      				echo '<td width=2>&nbsp;';
				      				echo '</td>';
				      			}else{
				      				?>
				      				</TR>
					      			<TR class=f10 height=2>
					      				<td>
					      				</td>
					      			</tr>							      				
				      				<TR class=f10>
		      						<?php
	      						}
							}
						mysql_free_result($rs_2);
		      			?>
					</TR>
	      			<TR class=f10 height=10>
	      				<td>
	      				</td>
	      			</tr>							      				
	      		</table>
    			<?php
			}



			?>
    	</TD>

		<?php 
		if ($ps_style=="") require_once('inc_right.php');
		?>
      									
	</TR>
</TABLE>
<?php 
if ($ps_type=="showkat") $ps_popular="kat";
if ($ps_style=="") require_once('inc_down.php');
mysql_close($conn1);
?>	
</body>
</html>
