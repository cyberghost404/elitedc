<?php
/********* PHP O�-���� v1.0 ************ 
Copyright 2003, PHP Active Stalker. 
E-mail: stalker@phpactive.ru
Website: http://www.phpactive.ru
**********************************************/ 
$ip = $_SERVER['REMOTE_ADDR'];
$time = time();
$agent = $_SERVER['HTTP_USER_AGENT'];

$minutes = 5;
$found = 0;
$users = 0;
$user  = "";

$tmpdata = $zserver."module/".$zmodule."/online/data";


if (!is_file("$tmpdata/online.txt"))	
	{
	$s = fopen("$tmpdata/online.txt","w");
	fclose($s);
	chmod("$tmpdata/online.txt",0666);
	}

$f = fopen("$tmpdata/online.txt","r+");
flock($f,2);

while (!feof($f))
	{
	$user[] = chop(fgets($f,65536));
	}

fseek($f,0,SEEK_SET);
ftruncate($f,0);

foreach ($user as $line)
	{
	list($savedip,$savedtime,$savedagent) = split("\|",$line);
	if ($savedip == $ip) {$savedtime = $time;$found = 1;}
	if ($time < $savedtime + ($minutes * 60)) 
		{
		fputs($f,"$savedip|$savedtime|$savedagent\n");
		$users = $users + 1;
		}
	}

if ($found == 0) 
	{
	fputs($f,"$ip|$time|$agent\n");
	$users = $users + 1;
	}

fclose ($f);
print "<b>, ������ </b>&nbsp;<i>(<font color=white>$users</font>)</i>";
?>
