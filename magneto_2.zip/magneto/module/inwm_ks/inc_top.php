<TABLE class=table_toppanel cellSpacing=0 cellPadding=0 width=100% height=20 border=0 bgcolor="<?php echo $zcmas[4];?>">
	<TR height=100% class=f9b>
		
		<?php
		if (getconf("ISWORK","VALUEINT")==0){
			//������� ���������
			?>
			<TD width=200><font color="<?php echo $zcmas[50]?>">
				<center><b><?php echo $zl['2']?></b></center>
			</font></TD>
			<?php
		}else{
			?>
	<TD width=100% align=center><font color="<?php echo $zcmas[50]?>">


	<a href="index.php"><font color="<?php echo $zcmas[50];?>"><?php echo $zl['40'];?></font></a> �
	<a href="index.php?type=info"><font color="<?php echo $zcmas[50];?>"><?php echo $zl['4003'];?></font></a> �

	<?php
	if (getconf("ISWANTED","VALUEINT")==1){
	?>

	<a href="wanted.php"><font color="<?php echo $zcmas[50];?>"><?php echo $zl['615'];?></font></a> �

	<?php
	}
	if (getconf("ISNEWS","VALUEINT")==1){
	//������� �������
	?>
	<a href="subkat.php?type=shownews"><font color="<?php echo $zcmas[50];?>"><?php echo $zl['44'];?></font></a> �


	<?php
	$ps1=getconf("NETSITE","VALUESTR");
	if ($ps1!=''){
		?>
		<a class=link1 target="_blank" href="<?php echo $ps1;?>" title="<?php echo $ps1;?>"><font color="<?php echo $zcmas[50];?>"><?php echo ucase($znetname);?></font></a> � 
		<?php
		}
	?>

	<?php
	}
	//����������
	if (getconf("ISPERSENABLED","VALUEINT")==1){
		$pi1=recordcount_new("tbl_persona where ISMODER=1");
	?>
	<a href="subkat.php?type=persona"><font color="<?php echo $zcmas[50];?>"><?php echo $zl['358'];?></font></a> (<?php echo $pi1;?>) �
	<?php
	}
	$pi1=recordcount_new("tbl_user");
	//������������
	?>
	<a href="user.php"><font color="<?php echo $zcmas[50];?>"><?php echo $zl['46'];?></font></a> (<?php echo $pi1;?>) �
	<a href="rss.php" target="_blank"><font color="<?php echo $zcmas[50];?>"><?php echo $zl['4004'];?></font></a>


	</font></TD>

		<?php
		}
		?>

	</font></TR>
</TABLE>

<script type="text/javascript" src="main/config/jquery.js"></script>
<script type="text/javascript" src="main/config/jquery.keyboardLayout.js"></script>
<link rel="stylesheet" type="text/css" href="main/config/script/jquery.keyboardLayout.css" />


<script type="text/javascript" src="main/config/tooltips.js"></script>

<style>
#tooltip {
background:#fdfdfd; 
border:1px solid #efefef; 
color:#000000; 
font: 10px Verdana, Arial, Tahoma, sans-serif;
margin:2px; 
padding:2px 3px; 
position:absolute; 
visibility:hidden 
} 
</style>

<TABLE cellSpacing="0" cellPadding="0" width="100%" height="100" border="0" class="table_header" >
	<TR height="100%" class="f9b">

<!--// ����� ����� /!-->
		<td width="220" align=center valign="middle" class="f8">

		<?php
		if (getconf("ISWORK","VALUEINT")!=0){
		?>

			<TABLE cellSpacing="0" cellPadding="0" width=220 border=0 class="f8">

				<font color="<?php echo $zcmas[50]?>">
	
				<TR height=1>
				<TD width=175 height=1 align="left" valign="middle"></TD><TD width=50 height=1 align="right" valign="middle"></TD>
				</TR>


				<TR><TD>&nbsp;&nbsp;
				<?php
				//������ � �������:

				echo $zl['26'].'</TD><TD align="right"><u><b>'.recordcount_new("tbl_base where ISMODER=1").'</b></u>';
				?>
				</TD></TR>



				<?php
				//������ �� ���������:
				if (getconf("ISADDALTLINKS","VALUEINT")==1){
				?>
					<TR><TD>&nbsp;&nbsp;
					<?php
					echo $zl['4005'];
					?>:
					</TD><TD align="right"><a href="subkat.php?type=ismoder"><b><u><font color="<?php echo $zcmas[50]?>"><?php echo recordcount_new("tbl_base where ISMODER=0 and ISDOPEDIT=0")?></u></b></font></a>
					</TD></TR>
				<?php
				}
				?>



				<TR><TD>&nbsp;&nbsp;
				<?php
				//������:
				echo $zl['4006'].':</TD><TD align="right"><b>'.recordcount_new("tbl_link where ISMODER=1").'</b>';
				?>

				</TD></TR>
				<TR><TD>&nbsp;&nbsp;
				<?php
				//�����������:
				echo $zl['4007'].':</TD><TD align="right"><b>'.recordcount_new("tbl_comment where ISMODER=1").'</b>';
				?>

				</TD></TR>

				<TR><TD>&nbsp;&nbsp;
				
				<?php
				$pd1=dateadd("n",-getconf("ONLINETIME","VALUESTR"),mktime());
				$pi1=recordcount_new("tbl_user where LASTVISIT>'".sqldatetime2($pd1)."'");
				//�������� ������� ���� ��������
				$pi_max=getconf("MAXUSERCOUNT","VALUESTR");
				//� �������� ����:
				$pi_maxdate=getconf("MAXUSERDATE","VALUESTR");

				//������ �� �����:
				echo $zl['4008'].'/'.$zl['4009'].' :'?></TD><TD align="right"><b><a class=link1 href="user.php?type2=online">
					<?php
					if ($pi1>=$pi_max){
						echo '<font color="red">'.$pi1.'</font>';
					}else{
						echo $pi1;
					}

					//���� ������ ������ - �� ���������
					if ($pi1>$pi_max){
						$rs_s2=mysql_query("update tbl_conf set VALUESTR=".$pi1." where PARAM='MAXUSERCOUNT'");
						$rs_s2=mysql_query("update tbl_conf set VALUESTR='".sqldatetime2(mktime())."' where PARAM='MAXUSERDATE'");
						$pi_max=$pi1;
					}

					?></a></b>/<b><?php echo $pi_max?></b>

				</TD></TR>

				<TR><TD>&nbsp;&nbsp;



				</TD></TR>

				</font>
			</TABLE>

			<?php
		}else{
			if ($ps_usercode==0){
				//�����
				//������
				//����
				?>
				<center><form method="post" name="frmlogin" action="index.php">
					<input type="HIDDEN" name="type" value="login">

					<TABLE cellSpacing="0" cellPadding="0" width="100%" align=center valign=center border="0">
						<TR><TD width=190 class=f8b><center><font color=red>���� ��� �������������!</font></center></TD></TR>
					</TABLE>
					<TABLE cellSpacing="0" cellPadding="0" width="100%" align=center valign=center border="0">
						<TR height="1" class="f8b">
							<TD width=90></TD>
							<TD width=100></TD>
						</TR>
						<TR height="12" class="f8b">
							<TD align="right" valign="bottom" width="110" height="12">
								<br><?php echo $zl['31']?>:&nbsp;
							</TD>
							<TD align="left" valign="bottom" height="12">
								<input type="text" name="magneto_login" size="9" maxlength="40" class=input2 onFocus="id=className;" onblur="id=''">
							</TD>
						</TR>
						<TR height="12" class="f8b">
							<TD align="right" valign="top" width="110" height="12">
							<?php echo $zl['32']?>:&nbsp;	
							</TD>
							<TD align="left" valign="top" height="12">
								<script type="text/javascript">
									$(function(){
									$(':password').keyboardLayout();
									});
								</script>
								<input type="password" name="magneto_pass" class=input2 size="9" maxlength="20" onFocus="id=className;" onblur="id=''">


							</TD>
						</TR>

						<TR height="12" class="f8b">
							<TD align="right" valign="middle" width="110" height="12">
							&nbsp;
							</TD>
							<TD align="left" valign="middle" height="12">
								<input class=inputb3 type="submit" value="<?php echo $zl['33']?>" onMouseOver="id=className" onMouseOut="id=''"><br>
							</TD>
						</TR>



					</TABLE>
					<?php
					if ($ps_msg=="badpass") $ps_msg2=$zl['34'];//������������ ����� ��� ������!
					if ($ps_msg=="newpass") $ps_msg2=$zl['35'];//������� ��� ����� �������
					if ($ps_msg2!="") {
						echo '<font color="'.$zcmas[16].'"><b>';
						echo $ps_msg2.'<br>';
						if ($ps_msg2==$zl['34']){//������������ ������!
							//������������?
							echo '<a href="index.php?type=restore">'.$zl['36'].'</a>';
						}						
						echo '</b></font>';
					}

					?>
				</form><center>
		<?php
			}
		}
		?>


		</TD>

<!--// ������� ����� /!-->


		<td width="15" align=left valign="middle">
		</TD>
		<td align="center">
			<a href="index.php">
			<?php
			//������� �� ������� ��������
			//����!  _winner - ������ ����! ��� ����������
			?>
			<img src="main/color/scheme/<?php echo $ps_color;?>/element_header.png" border=0 title="<?php echo $zl['30']?>">
			</a>
		</TD>
		<td width="15" align=right valign="middle">
		</TD>


<!--// ������ ����� /!-->
		<TD width="198" align="center" valign="middle">
		<?php
//			require_once("main/mod/head_right.php");
		?>
		</TD>

	</TR>
</TABLE>				
		