<?php
$ps_work=getconf("ISWORK","VALUEINT");
if ($ps_lock==1) $ps_work=0;
if ($ps_work==1){
	?>
	<table cellspacing=0 cellpadding=0 width=100% height=2 border=0 bgcolor="<?php echo $zcmas[1]?>" align=center>
		<td></td>
	</table>
	<table cellspacing=0 cellpadding=0 width=100% height=1 border=0 bgcolor="<?php echo $zcmas[30]?>" align=center>
		<td></td>
	</table>	
	<table cellspacing=0 cellpadding=0 width=100% height=2 border=0 bgcolor="<?php echo $zcmas[1]?>" align=center>
		<td></td>
	</table>
	<?php
}?>
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
	<tr height=100>
		<td <?php if ($ps_work==1) echo 'width=320';?> align=center class=f10 valign=middle>
			<?php
			//��������� �������� � ����������
			$rs_2=mysql_query("select OPIS from tbl_page where NAZV='�������: ��������'",$conn1);
				$rs=mysql_fetch_array($rs_2);
				echo $rs['OPIS'];
			mysql_free_result($rs_2);		
			?>			
		</td>
		<?php 
		if ($ps_work==1){
			?>
			<td>
	      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	      			<TR>
						<td valign=top align=right>
				      		<TABLE cellSpacing=0 cellPadding=0 width=220 border=0 class=table_down_kat>
				      			<TR class=f10 height=16>
				      				<td>
							      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat_element height=100%>
							      			<TR class=f10 height=100%>
							      				<td width=25 align=center >
				      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
				      							</TD>
							      				<td><font color="<?php echo $zcmas[50]?>">
													<?php
													
													//������ ������������
													echo '<b>'.$zl['11'].'</b>';
													?>
												</font>
				      							</TD>
				      						</TR>
				      					</TABLE>
				      				</TD>
				      			</TR>

				      			<TR class=f10>
				      				<td>
				      					<TABLE cellSpacing=1 cellPadding=0 width=100% border=0>
					      					<?php
					      					$pi1=0;
											$rs_2 = mysql_query("select CODE,RATINGS,LOGIN,POSTER from tbl_user order by RATINGS DESC limit 20",$conn1);
												while (($rs=mysql_fetch_assoc($rs_2))!==false) {
													$pi1=$pi1+1;
													?>
													<tr class=f10>
														<td width=20>
															<?php echo '&nbsp;'.$pi1.'.';?>
														</td>
														<td align=center width=20>
															<?php 
															$ps_israt=1;
															echo getstar(floor($rs['RATINGS']*0.1));
															$ps_israt=0;
															?>
														</td>
														<?php
														//������� � ������ ������ �������������
														if (getconf("ISAVAINDOWN","VALUEINT")==1){
															?>
															<td width=20>
																<?php 
																$ps_pict=$rs['POSTER'];
																if ($ps_pict!=''){
																	?>
																	<img src="main/avatar/<?php echo $ps_pict?>" width=16 height=16>
																	<?php
																}
																?>
															</td>
															<?php
														}
														?>
														<td>
															<?php
															echo '<a title="'.$zl['12'].'" href="user.php?type=show&code='.$rs['CODE'].'">'.$rs['LOGIN'].'</a>';//���������� � ������������
															?>
														</td>
														<td class=f7>
															<?php
															echo '<b>('.$rs['RATINGS'].')</b>';
															?>
														</td>
													</tr>
													<?php
												}
											mysql_free_result($rs_2);
											?>
										</TABLE>
				      				</TD>
				      			</TR>

					<tr class=f10>
						<td align=center>
							<?php
								$ps_i=1;
								$ps_p="";
								getstar($ps_i);
								while ($ps_i<=9) {
									$ps_p = $ps_p."<img src='main/color/scheme/".$ps_color."/rating_".$ps_i.".png' alt=".$ps_i." title=".$ps_i.">";
									$ps_i=$ps_i+1;
								}
							echo $ps_p;
							?>
						</td>
					</tr>

				      		</TABLE>
				      		<?php
				      		//������ ����������
				      		if (getconf("ISTOPMODER","VALUEINT")==1){
				      			?>

						<table><tr height=2><td width=2></td></tr></table>

					      		<TABLE cellSpacing=0 cellPadding=0 width=220 border=0 class=table_down_kat>
					      			<TR class=f10 height=16>
					      				<td>
								      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat_element height=100%>
								      			<TR class=f10 height=100%>
								      				<td width=25 align=center >
					      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
					      							</TD>
								      				<td><font color="<?php echo $zcmas[50]?>">
														<?php
														//������ ����������
														echo '<b>'.$zl['13'].'</b>';
														?>								    
					      							</font></TD>
					      						</TR>
					      					</TABLE>
					      				</TD>
					      			</TR>
					      			<TR class=f10>
					      				<td>
					      					<TABLE cellSpacing=1 cellPadding=0 width=100% border=0>
						      					<?php
						      					$pi1=0;
												$rs_2 = mysql_query("select CODE,MODERS,RATINGS,LOGIN,POSTER from tbl_user where STATUS>2 order by MODERS DESC limit 5",$conn1);
													while (($rs=mysql_fetch_assoc($rs_2))!==false) {
														$pi1=$pi1+1;
														?>
														<tr class=f10>
															<td width=20>
																<?php echo '&nbsp;'.$pi1.'.';?>
															</td>
														<td align=center width=20>
															<?php 
															$ps_israt=1;
															echo getstar(floor($rs['RATINGS']*0.1));
															$ps_israt=0;
															?>
														</td>

															<?php
															//������� � ������ ������
															if (getconf("ISAVAINDOWN","VALUEINT")==1){
																?>
																<td width=20>
																	<?php 
																	$ps_pict=$rs['POSTER'];
																	if ($ps_pict!=''){
																		?>
																		<img src="main/avatar/<?php echo $ps_pict?>" width=16 height=16>
																		<?php
																	}
																	?>
																</td>
																<?php
															}
															?>															
															<td>
																<?php
																echo '<a title="'.$zl['12'].'" href="user.php?type=show&code='.$rs['CODE'].'">'.$rs['LOGIN'].'</a>';//���������� � ������������
																?>
															</td>
															<td class=f7>
																<?php
																$ps1=$rs['MODERS'];
																if ($ps1=='') $ps1=0;
																echo '<b>('.$ps1.')</b>';
																?>
															</td>
														</tr>
														<?php														
													}
												mysql_free_result($rs_2);
												?>					      			
											</table>
					      				</TD>
					      			</TR>
					      		</TABLE>
					      		<?php
					      	}
					      	?>
						</td>

						<td width=2>&nbsp;</td>

						<td valign=top>
				      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat>
				      			<TR class=f10 height=16>
				      				<td>
							      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat_element height=100%>
							      			<TR class=f10 height=100%>
							      				<td width=25 align=center>
				      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
				      							</TD>
							      				<td><font color="<?php echo $zcmas[50]?>">
													<?php 
													//����������
													echo '<b>'.$zl['14'];
													$pd2=dateadd("d",-getconf("POPULARDAY","VALUESTR"),mktime());
													if ($ps_popular==""){
								      					$ps_constr="select tbl_base.NAZV,tbl_link.BASECODE,tbl_link.LINKOPIS,tbl_link.DOWN from tbl_link,tbl_base where tbl_link.DATEADD>'".sqldatetime2($pd2)."' and tbl_base.ISMODER=1 and tbl_link.ISMODER=1 and tbl_link.DOWN>0 and (tbl_link.BASECODE=tbl_base.CODE)  order by tbl_link.DOWN desc limit 15";
								      					echo ' - '.$zl['15'];//��� �������
													}
													if ($ps_popular=="subkat"){
								      					$ps_constr="select tbl_base.NAZV,tbl_link.BASECODE,tbl_link.LINKOPIS,tbl_link.DOWN from tbl_link,tbl_base where tbl_link.DATEADD>'".sqldatetime2($pd2)."' and tbl_base.ISMODER=1 and tbl_link.ISMODER=1 and tbl_link.DOWN>0 and (tbl_link.BASECODE=tbl_base.CODE and (tbl_base.SUBKAT1=".$ps_type2." or tbl_base.SUBKAT2=".$ps_type2." or tbl_base.SUBKAT3=".$ps_type2."))  order by tbl_link.DOWN desc limit 15";
								      					echo ' - '.$ps_subkatname;
													}
													if ($ps_popular=="kat"){
								      					$ps_constr="select tbl_base.NAZV,tbl_link.BASECODE,tbl_link.LINKOPIS,tbl_link.DOWN from tbl_link,tbl_base where tbl_link.DATEADD>'".sqldatetime2($pd2)."' and tbl_base.ISMODER=1 and tbl_link.ISMODER=1 and tbl_link.DOWN>0 and (tbl_link.BASECODE=tbl_base.CODE and tbl_base.KAT=".$ps_type2.")  order by tbl_link.DOWN desc limit 15";
								      					echo ' - '.$ps_katname;
													}
													?>
													</b>
				      							</font></TD>
				      						</TR>
				      					</TABLE>
				      				</TD>
				      			</TR>
				      			<TR class=f10>
				      				<td>
				      					<?php
				      					$pi1=0;
				      					if (recordcount($ps_constr)>0){
											$rs_2 = mysql_query($ps_constr,$conn1);
												while (($rs=mysql_fetch_assoc($rs_2))!==false) {
													$pi1=$pi1+1;
													echo '&nbsp;'.$pi1.'. ';
													echo '<a title="'.$zl['16'].'" href="topic.php?type=show&code='.$rs['BASECODE'].'">'.$rs['NAZV'].'</a>';//������� �� �������
													if ($rs['LINKOPIS']!="") echo '<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=1>'.$rs['LINKOPIS'].'</font>';
													echo ' <font size=1>('.$rs['DOWN'].')</font>';
													echo '<br>';											
												}
											mysql_free_result($rs_2);
										}
				      					?>
				      				</TD>
				      			</TR>
				      		</TABLE>
						</td>
	      			</tr>
	      		</table>
			</td>
			<TD width=2></TD>	      									
			<?php
		}
		?>
	</tr>
</TABLE>

		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0><TR height=6><TD height=6></TD></TR></TABLE>

<?php
//������������ ������
if ($ps_work==1){
	if (getconf("ISONLINE","VALUEINT")==1){
		?>
		<center>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
			<TR class=f10>
	  			<?php
				$pd1=dateadd("n",-getconf("ONLINETIME","VALUESTR"),mktime());
				$pi1=recordcount_new("tbl_user where LASTVISIT>'".sqldatetime2($pd1)."'");  		
				?>
				<TD width=2>&nbsp;</TD>

				<td valign=top align=center>
		      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat>
		      			<TR class=f10 height=16>
		      				<td>
					      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
					      			<TR class=f10 height=16>
					      				<td width=25 align=center>
		      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
		      							</TD>
					      				<td>
					      					<b><a class=link1 href="user.php?type2=online"><font color="<?php echo $zcmas[50]?>"><?php echo $zl['17']?></font></a></b>
					      					
										<?php
											//������������ ������
					      					if ($pi1>0) echo ' <i><font color='.$zcmas[50].'>('.$pi1.')</font></i>';
					      					?>&nbsp;&nbsp;<font color='<?php echo $zcmas[50];?>'>
					      					<?php
					      					require_once('online/online.php');
											?></font>

		      							</TD>
		      						</TR>
		      					</TABLE>
		      				</TD>
		      			</TR>
						<TR>
		      				<td class=f9>
								<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
					      			<TR class=f9 height=10>
					      				<td>
					      					<?php
					      					$pb_ischat=getconf("ISCHAT","VALUEINT");
					      					//��� ������������:
					      					 echo '&nbsp;<b>'.$zl['20'].'</b>';
					      					$pi1=recordcount_new("tbl_user where LASTVISIT>'".sqldatetime2($pd1)."'");
					      					if ($pi1==0){
					      						echo ' '.$zl['19'];//������ ���
					      					}else{
					      						$pi2=0;
												$rs2_2=mysql_query("select CODE, LOGIN, ISCHAT, STATUS, LASTIP, DATEREG, RATINGS, LASTVISIT from tbl_user where LASTVISIT>'".sqldatetime2($pd1)."' order by LASTVISIT",$conn1);
													while (($rs=mysql_fetch_assoc($rs2_2))!==false) {
														$pi2=$pi2+1;
														if ($rs['STATUS'] > 2) {$pi_color="<font color='orange'><b><i>".$rs['LOGIN']."</i></b></font>";}
														if ($rs['STATUS'] < 3) {$pi_color=$rs['LOGIN'];}

														$pi_title="";	//��������� ��
														if ($zright['DO_USER']==1) {
															$pi_title=':   IP: '.$rs['LASTIP'].' / ���.: '.$rs['DATEREG'].' / ����.: '.$rs['RATINGS'].' / ����.����: '.cdate($rs['LASTVISIT']);
														}

														?>
														<a href="user.php?type=show&code=<?php echo $rs['CODE']?>" target="_blank" alt="<?php echo $zl['12'].$pi_title?>" title="<?php echo $zl['12'].$pi_title?>"><?php echo $pi_color;?></a><?php //���������� � ������������
														if ($pb_ischat==1){
															if ($rs['ISCHAT']==1){
																//� ������������ ��� �������
																?>
																<img src="main/color/scheme/<?php echo $ps_color;?>/element_chat_on.png" width=12 height=12 border=0 title="<?php echo $zl['444']?>">
																<?php
															}
														}
														if ($pi2<>$pi1) echo ', ';
													}
												mysql_free_result($rs2_2);
											}
					      					?>
					      				</td>
					      			</tr>
		<?php
		$datafile ="online/data/online.txt";
		$lines = file($datafile);	//���� � ����������
		$i = sizeof($lines);		//�-�� �������
		$bot = "";
		$a1=$a2=0;
		do {$dt = explode("|", $lines[$a1]);
		//	echo $dt[0]." - ".$dt[1]." - ".$dt[2]."<br>";
			$bote="";
			if ( strstr($dt[2], 'Yandex') ) { $bote='Yandex';} 
			elseif ( strstr($dt[2], 'Googlebot') ) {$bote='Google Bot';} 
			elseif ( strstr($dt[2], 'Slurp') ) {$bote='Slurp';} 
			elseif ( strstr($dt[2], 'WebCrawler') ) {$bote='WebCrawler';} 
			elseif ( strstr($dt[2], 'ZyBorg') ) {$bote='ZyBorg';} 
			elseif ( strstr($dt[2], 'google') ) {$bote='Google Media';} 
			elseif ( strstr($dt[2], 'scooter') ) {$bote='AltaVista';} 
			elseif ( strstr($dt[2], 'stack') ) {$bote='Rambler Stack';} 
			elseif ( strstr($dt[2], 'aport') ) {$bote='Aport';} 
			elseif ( strstr($dt[2], 'lycos') ) {$bote='Lycos';} 
			elseif ( strstr($dt[2], 'fast') ) {$bote='Fast Search';} 
			elseif ( strstr($dt[2], 'rambler') ) {$bote='Rambler';}
			elseif ( strstr($dt[2], 'Yahoo') ) {$bote='Yahoo!!!';}
			elseif ( strstr($dt[2], 'Begun') ) {$bote='Begun Partners';}
			elseif ( strstr($dt[2], 'Twiceler') ) {$bote='Twiceler';}

			 

			if ($bote!="") $bot=$bot."'".$bote."', ";

			$a1++;
		}
		while($a1 < $i);

		if($bot !="") {
				?>
				<TR class=f9 height=10>
					<td>
					<?php
      					//����:
      					echo '&nbsp;'.$zl['4002'].':</b>&nbsp;';

					//������������
					 echo "<font color='gray'>".$bot."</font>"; //���������� � ������������
					?>
					</td>
				</tr>
				<?php
				}
		?>

					      		</table>
		      				</TD>
		      			</TR>					      									
		      		</TABLE>
		      	</td>
			<TD width=2>&nbsp;</TD>	      									
			</TR><TR class=f10 height=4><td></td></tr>							      				
		</table>
		</center>
		<?php
	}
}
?>

<!--// ���� ������� ������ //!-->


<TABLE cellSpacing=0 cellPadding=0 width=100% border=0><TR height=4><TD height=4></TD></TR></TABLE>
	<table cellspacing=0 cellpadding=0 width=100% height=2 border=0 bgcolor="<?php echo $zcmas[1]?>" align=center>
	<td></td>
</table>


<table cellspacing=0 cellpadding=0 width=100% height=1 border=0 bgcolor="<?php echo $zcmas[30]?>" align=center>
	<td class=f7><center>

	<?php echo $zl['4001']?>

	</center></td>
</table>

<table cellspacing=3 cellpadding=0 width=100% border=0 align=center>
	<td class=f8 width=300>
		<?php
		/*
		=====================================================================================================================
		��������� ������, ������ ��� ������� ���������. ��������� ��������� ��� ���������, � ����� ������ ������������ �����.
		��������� ����� �� ���� �������.
		=====================================================================================================================
		*/
		//����������������
		//������
		?>
		<?php echo $zl['21']?>: <b><a target="_blank" href="http://www.userside.org.ua">"UserSide"</a></b>,&nbsp;
		<b><a target="_blank" href="http://inwm.net.ru">SCALOlaz</a></b><br>

		<?php
		//������ ��������� � ����������� �� �����
		$ps_diz='Drimer';
		$ps_dizlink='mailto:drimer.home@gmail.com';
		if ($ps_color=="blue"){
			$ps_diz='Drimer';
			$ps_dizlink='mailto:drimer.home@gmail.com';
		}
		if ($ps_color=="mac_os"){
			$ps_diz='CYBERON';
			$ps_dizlink='mailto:cybernetic@programist.ru';
		}
		if ($ps_color=="atlantida"){
			$ps_diz='Atlant_is';
			$ps_dizlink='mailto:atlant_is@mail.ru';
		}
		if ($ps_color=="homenet"){
			$ps_diz='Atlant_is';
			$ps_dizlink='mailto:atlant_is@mail.ru';
		}
		if ($ps_color=="green"){
			$ps_diz='Parazite & SCALOlaz & TimOn';
			$ps_dizlink='http://inwm.net.ru';
		}
		?>
		<?php echo $zl['22']?>: <a target="_blank" href="<?php echo $ps_dizlink?>"><b><?php echo $ps_diz?></b></a> � <b><a target="_blank" href="http://www.userside.org.ua">"UserSide"</a></b>
	</td>
	<td class=f8b align=center>
		<?php
		//�������
		echo $zl['23'].' "Magneto" v.'.$zver;
		?>
		<br>
		&copy;2008-2010 - <a target="_blank" href="http://www.userside.org.ua/magneto/">http://www.userside.org.ua/magneto/</a>
	</td>
	<td class=f8 width=200>
		<b><font size=1><?php echo $zmodule_name.' v.'.$zmodule_ver.' - '.$zmodule_date;?></font><br></b>
		<?php 
		//����� ������
		echo $zl['673']?>: <b><a target="_blank" href="<?php echo $zmodule_url;?>"><?php echo $zmodule_avtor;?></a></b><br>
		<?php
		$end_time = microtime();
		$end_array = explode(" ",$end_time);
		$end_time = $end_array[1] + $end_array[0];
		$work_time = $end_time - $start_time;
		//�������� ��������������
		//�.
		?>
		<font color="white"><?php echo $zl['24']?>: <?php echo(round($work_time*10)*0.1)?> <?php echo $zl['25']?><br></font>

	</td>
</table>
