<?php
//require_once('main/config/functlist.php');
openconn1();
verifyuser();

//��������� ���� �� ����� �������� � �������� ��?
$rs_2 = mysql_query("select * from tbl_page where ISSHOW=1 and CODE=".$ps_code,$conn1);
	$rs=mysql_fetch_array($rs_2);
	$ps_caption=$rs['NAZV'];
	$ps_code=$rs['CODE'];
	$ps_opis=$rs['OPIS'];
mysql_free_result($rs_2);
$ps_caption=trim(str_replace("�������:","",$ps_caption));								
$ps_caption=trim(str_replace("����� ����:","",$ps_caption));								
if ($ps_code==''){
	header("Location: index.php");exit;
}


//============================================================================================================================================
?>
<HTML>
<HEAD>
	<TITLE><?php echo getconf("PROJECTNAME","VALUESTR").' - '.$ps_caption ?></TITLE>
	<?php site_header()?>
</HEAD>
<BODY leftMargin=0 topMargin=0>
<?php 
if ($ps_style=="") require_once('inc_top.php');
?>	
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	<TR valign=top>
		<?php 
		if ($ps_style=="") {
			if (getconf("ISWORK","VALUEINT")==1){
				require_once('inc_left.php');
			}
		}
		?>

		<TD class=f10>
    		<?php

    		//===========================================================================================
    		if ($ps_type==""){
    			//�������� ��������
				?><TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0><TR><TD><?php

    			us_text($ps_caption);   

				?></TD></TR></TABLE><?php
 			
				echo $ps_opis;
				echo '<br>';
				if ($zright['DO_SET']==1){
					//�������������� ��������
					?>
    				<b>::</b> <a href="settings.php?type=editpages&code=<?php echo $ps_code?>"><?php echo $zl['608']?></a><br>
					<?php
				}
			}


			?>
    	</TD>

	<?php 
	if ($ps_style=="") require_once('inc_right.php');
	?>

	</TR>
</TABLE>
<?php 
if ($ps_style=="") require_once('inc_down.php');
mysql_close($conn1);
?>	
</body>
</html>