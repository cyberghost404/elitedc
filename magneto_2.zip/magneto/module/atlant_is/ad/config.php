<?php
/*************************************************************************************************

    phpAdManager 1.0
	Configuration Module
	Copyright 2003 Hamilton G Laughland

	Author: Hamilton G Laughland
	Website: http://www.laughland.biz

	This script is protected by New Zealand copyright law.

****************************************************************************************************/



/***** Do not change anything below this line *****************************************************/
$prefix = "tbl_";

$banners = $prefix . "banners";
$stats = $prefix . "bannerstats";
$types= $prefix."bannertype";

function doquery($query) {
$result = mysql_query($query);
return $result;
}

$msg = "<table align='center' class='head' width='80%' border='1' cellspacing='0' cellpadding='2'>";
?>
