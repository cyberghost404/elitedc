<?php
 /*************************************************************************************************

    phpAdManager 1.0
	Main Module
	Copyright 2003 Hamilton G Laughland

	Author: Hamilton G Laughland
	Website: http://www.laughland.biz

	This script is protected by New Zealand copyright law.

****************************************************************************************************/
 //���������� ��������� � ������������� �������
$mydir=getcwd();
chdir("..");
chdir("..");
chdir("..");
require_once(getcwd().'/main/config/functlist.php' );
chdir($mydir);
openconn1();
$prefix = "tbl_";
$banners = $prefix . "banners";
$stats = $prefix . "bannerstats";
$types= $prefix."bannertype";


function doquery($query) {
$result = mysql_query($query) or die(mysql_error());
return $result;
}

$action=$_GET['action'];
$btype=$_CET['btype'];
$id=$_REQUEST['id'];
$time=time();

if($action == "show"){
$query = "select * from $banners where id=$id" ;
 $result = doquery($query);
 $row = mysql_fetch_array($result);
 $link = $row['link'];
 $today = date("d m Y");
 $query = "select * from $stats where DATE_FORMAT(amdate, '%d %m %Y') = '$today' and id = $id";
 $result = doquery($query);
 $num_results = mysql_num_rows($result);
 $today = date("Y-m-d");
 $query = "UPDATE $stats SET clicks = clicks + 1 WHERE id = $id AND amdate = '$today'";
 $result = doquery($query);
 header("Location: ".$link);
 exit;
}
?>
