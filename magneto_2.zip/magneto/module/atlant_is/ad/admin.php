<?php
/*************************************************************************************************

    phpAdManager 1.0
	Administration Module
	Copyright 2003 Hamilton G Laughland

	Author: Hamilton G Laughland
	Website: http://www.laughland.biz

	This script is protected by New Zealand copyright law.

****************************************************************************************************/
//���������� ��������� � ������������� �������
$mydir=getcwd();
chdir("..");
chdir("..");
chdir("..");
require_once(getcwd().'/main/config/functlist.php' );
chdir($mydir);

include("config.php");
openconn1();


//�������� ����������
if (isset($_POST['btnSubmit'])){
  $action=$_POST['action'];
  $imgfile=$_POST['imgfile'];
	$link=$_POST['link'];
	$adtext=$_POST['adtext'];
	$status=$_POST['status'];
	$adtype=$_POST['adtype'];
	$link=$_POST['link'];
	$image=$_POST['image'];
	$upimage=$_FILES["upimage"]["name"];
	$alt=$_POST['alt'];
  $id=$_POST['id'];
  $bid = $_POST['bid'];
  $btype = $_POST['btype'];
  $bname = $_POST['bname'];
  $bwidth = $_POST['bwidth'];
  $bheight = $_POST['bheight'];
  $bprice = $_POST['bprice'];
  $adid = $_POST['adid'];
  $lifetime = $_POST['lifetime'];
 }else{
 	$action=$_GET['action'];
  $id=$_GET['id'];
 	$imgfile=$_REQUEST['imgfile'];
	$link=$_REQUEST['link'];
	$adtext=$_REQUEST['adtext'];
	$status=$_REQUEST['status'];
	$adtype=$_REQUEST['adtype'];
	$link=$_REQUEST['link'];
	$image=$_REQUEST['image'];
	$upimage=$_REQUEST['upimage'];
	$alt=$_REQUEST['alt'];
  $bid = $_REQUEST['bid'];
  $btype = $_REQUEST['btype'];
  $bname = $_REQUEST['bname'];
  $bwidth = $_REQUEST['bwidth'];
  $bheight = $_REQUEST['bheight'];
  $bprice = $_REQUEST['bprice'];
  $adid = $_REQUEST['adid'];
  $lifetime = $_REQUEST['lifetime'];
 }

 verifyuser1();

 //echo $ps_status;
 if ($ps_status<4){
    $btypes='';
 }else{
    $btypes='<td align="center"  width="20%"><a class="head" href="admin.php?action=btypes">'.$ul['120'].'</a></td>';
 }
//������������ ������ ��� ������
if($ps_status<1 and $action!='needreg'){
 //$location='<meta http-equiv="refresh" content="0; url=admin.php?action=needreg">' ;
 header("Location: admin.php?action=needreg");exit;
 }elseif($ps_status>=1 and $action=='needreg'){
 $action='add';
 }

// ���������� ������ ���� �������
if ($action=='bupdate' and $ps_status>3){
 if(!isset($bname) || !isset($bheight) || !isset($bwidth) || !isset($bprice)){
  echo $zl['529'];
  return;
 }
 $query = "UPDATE ".$types." SET name = '".$bname."' , rez_hor ='".$bwidth."' , rez_vert ='".$bheight."' , price = '".$bprice."'  WHERE id = '".$bid."'";
 $result = doquery($query);
 //$location='<meta http-equiv="refresh" content="0; url=admin.php?action=btypes">' ;
  header("Location: admin.php?action=btypes");exit;
}

//���������� ������ ���� �������
if($action == "binsert" and $ps_status>3){
 if(!isset($bname) || !isset($bheight) || !isset($bwidth) || !isset($bprice)){
 $location='<meta http-equiv="refresh" content="0; url=admin.php?action=notall">' ;
 return;
 }
 $result = doquery("INSERT INTO ".$types." (id,name,rez_hor,rez_vert,price) VALUES ('','".$bname."','".$bwidth."','".$bheight."',".$bprice.")") or die(mysql_error());
 //$location='<meta http-equiv="refresh" content="0; url=admin.php?action=btypes">' ;
 header("Location: admin.php?action=btypes");exit;
}

//�������� ������ ���� �������
if($action == "bdel" and $ps_status>3){
 $result = doquery("delete from ".$types." where ID=".$bid) or die(mysql_error());
 //$location='<meta http-equiv="refresh" content="0; url=admin.php?action=btypes">' ;
 header("Location: admin.php?action=btypes");exit;
}

//������� �������
if($action == "insert"){
 if((!isset($upimage) and !isset($image)) || !isset($link) || !isset($btype)){
//$location='<meta http-equiv="refresh" content="0; url=admin.php?action=notall">' ;
header("Location: admin.php?action=notall");exit;
 }else{
//�������� ����. ID �������
//$query='select max(id+1) as nexid from '.$banners;
//$result = doquery($query);
  if(isset($lifetime)){
  $arrtime=explode("-",$lifetime);
  $ltime= mktime(23,59,0,$arrtime[1],$arrtime[0],$arrtime[2]) ;
  }else{
  $ltime=time()+86399*30;
  }
$query="INSERT INTO ".$banners." (adtype,link,image,adtext,alt,status,usercode,bannertype, lifetime) VALUES ('".$adtype."','".$link."','images/transp.gif','".$adtext."','".$alt."',".$status.",".$ps_usercode.",".$btype.",".$ltime.")";
//echo $query;
doquery($query) or die(mysql_error());
$result=doquery('select LAST_INSERT_ID() as nexid');
$row = mysql_fetch_array($result);
$nexid=$row["nexid"];
 if($upimage != ""){
  $nimage=$_FILES["upimage"]["tmp_name"];
  $ps_ext=lcase(right_1($_FILES["upimage"]["name"],3));
  $imgfile= "images/".$nexid.'.'.$ps_ext;
  if(!move_uploaded_file($nimage, $imgfile)){echo "Upload failed.";}
  $fp = fopen($imgfile, 'r');
  $temp = fread($fp, filesize($imgfile));
  fclose($fp);
  $fp = fopen($imgfile, 'w');
  fwrite($fp, $temp);
  fclose($fp);
  $image=$imgfile;
  }
  $result=doquery("update $banners set image='$image' where id=$nexid");
 header("Location: admin.php");exit;
}
}
//���������� �������
if($action == "update"){
 if((!isset($upimage) and !isset($image)) || !isset($link) || !isset($btype) || !isset($id)){
header("Location: admin.php?action=notall");exit;
 }else{
 if($upimage != ""){
  $nimage=$_FILES["upimage"]["tmp_name"];
  $ps_ext=lcase(right_1($_FILES["upimage"]["name"],3));
  $imgfile= "images/".$id.'.'.$ps_ext;
  //echo $nimage;
  if(!move_uploaded_file($nimage, $imgfile)){echo "Upload failed.";}
  $fp = fopen($imgfile, 'r');
  $temp = fread($fp, filesize($imgfile));
  fclose($fp);
  //$temp = strip_tags($temp);
  $fp = fopen($imgfile, 'w');
  fwrite($fp, $temp);
  fclose($fp);
  $image=$imgfile;
 }
  if(isset($lifetime)){
  $arrtime=explode("-",$lifetime);
  $ltime= mktime(23,59,0,$arrtime[1],$arrtime[0],$arrtime[2]) ;
  }else{
  $ltime=time()+86399*30;
  }
 $query = "UPDATE ".$banners." SET adtype = '".$adtype."' , link ='".$link."' , image ='".$image."' , adtext = '".$adtext."' , alt ='".$alt."' , status ='".$status."', bannertype=".$btype.", lifetime=".$ltime."  WHERE id = '".$id."'";
 $result = doquery($query) or die(mysql_error());
 header("Location: admin.php?action=edit");exit;
}
}

//���������� ���������
include("templates/header.htm");

//���������� �����
$mydir=getcwd();
chdir("..");
require_once('inc_style.php' );
chdir($mydir);


include("templates/center.htm");




//echo $action;
//echo $upimage;

if(!isset($action)){
 $message = "<tr class=f10><td align='center' class='message' colspan='2'>".$ul[97]."<br>".$ul[98]."</td></tr>";
 $msg .= $message . "</table>";
 echo $msg;
}

//���� ��������
if($action == "btypes" and $ps_status>3){
  $rows='<table class="table_kat" align=center width=80%>';
  $rows.='<tr class=f8><td width=0>'.'ID'.'</td><td>'.'��� � ��������������'.'</td><td>'.'����������'.'</td><td>'.'��������������� ����'.'</td><td>'.'��������'.'</td></tr>';
  $rows.='<form action="admin.php" method="post" enctype="multipart/form-data">
  <input name="action" type="hidden" value="binsert">
  ';
  $query='select * from '.$types;
  $result = doquery($query);
  if(mysql_num_rows($result) != 0){
  while ($row = mysql_fetch_array($result)){
   $bid= $row['ID'];
   $bname = $row['NAME'];
   $bwidth = $row['REZ_HOR'];
   $bheight = $row['REZ_VERT'];
   $bprice = $row['PRICE'];
   $rows.='<tr class=f10>
      <td>'.$bid.'</td>
      <td>'.$bname.'</td>
      <td>'.$bwidth.'x'.$bheight.'</td>
      <td>'.$bprice.'</td>
			<td>'.'<a href="admin.php?action=bedit&bid='.$bid.'">'.$zl[70].'</a>'.
			'&nbsp;<a href="admin.php?action=bdel&bid='.$bid.'"OnClick="return confirm(\''.$ul[126].'\'); return true;">'.$zl[346].'</td>
   </tr>';
   }
   }
   $bid= '';
   $bname = '';
   $bwidth = '';
   $bheight = '';
   $bprice = '';
   $caption='<tr class="f10"><td align=center colspan=2>'.$ul[121].'</td></tr>';
   $rows.='<tr class=f10><td align=center colspan=5>';
   $button='<tr class=f10><td></td><td><input type="submit" name="btnSubmit" value="'.$zl[337].'"></td></tr>';
    include("templates/addtype.htm");
    echo '</td></tr></form></table>';
}

//�������������� ������
if($action == "bedit" and $ps_status>3){
	$rows='<table class="table_kat" align=center width=80%><tr align=center><td>';
  $rows.='<form action="admin.php" method="post" enctype="multipart/form-data">
  <input name="action" type="hidden" value="bupdate">
  <input name="bid" type="hidden" value="'.$bid.'">
  ';
  $query='select * from '.$types.' where ID='.$bid;
  $result = doquery($query);
  if(mysql_num_rows($result) != 0){
  $row = mysql_fetch_array($result);
   $caption='<tr class="f10"><td align=center colspan=2>'.$ul[121].'</td></tr>';
   $bname = $row['NAME'];
   $bwidth = $row['REZ_HOR'];
   $bheight = $row['REZ_VERT'];
   $bprice = $row['PRICE'];
   }
   $button='<tr class=f10><td></td><td><input type="submit" name="btnSubmit" value="'.$zl[70].'"></td></tr>';
    include("templates/addtype.htm");
    echo '</td></tr></form></table>';
}

//���������� �������
if($action == "add"){
 $act = "insert";
 $imgrow = "<tr class=f10><td align='center' class='f10' colspan='2'>".$ul[99]."</td></tr>";
 if($ps_status>3){
 $radio = "&nbsp;".$ul[119]."<input name='status' type='radio' value='0'>&nbsp;".$ul[118]."<input name='status' type='radio' value='1' checked>";
 }else{
 $radio = "<input name='status' type='hidden' value='0'>".$ul[119];
 }
 $adstyle = "&nbsp;image<input name='adtype' type='radio' value='1' checked>&nbsp;rich text / html <input name='adtype' type='radio' value='0'>";
 $btype= "<select name='btype' size='1'>";
  $query='select * from '.$types;
  $result = doquery($query);
  if(mysql_num_rows($result) != 0){
  while ($row = mysql_fetch_array($result)){
   $bid= $row['ID'];
   $bname = $row['NAME'];
   $bwidth = $row['REZ_HOR'];
   $bheight = $row['REZ_VERT'];
   $bprice = $row['PRICE'];
   $btype.="<option value=".$bid.">".trim($bname)." ".$bwidth.'x'.$bheight.' '.$ul[125].' '.$bprice."</option>";
   }
   }
 $lifetime=time()+(86400*30);
 $arrtime=getdate($lifetime);
 $lifetime=$arrtime['mday'].'-'.str_pad($arrtime['mon'],2, "0", STR_PAD_LEFT).'-'.$arrtime['year'] ;
 $btype.="</select>";
 if ($ps_status>3){
 $ltime='<input value="'.$lifetime.'"  name="lifetime"  readonly /> <a href="javascript:showCal(\'Calendar1\')">'.$ul[130].'</a>';
 }else{
 $ltime=$lifetime;
 }
 include("templates/add.htm");
}



if($action == "edit"){
 $query = "select $banners.*,$types.name ,$types.rez_hor, $types.rez_vert, tbl_user.login
 from $banners
 inner join $types on $types.ID=$banners.bannertype
 inner join tbl_user on tbl_user.code=$banners.usercode";
 if($ps_status<4){$query.=' and usercode='.$ps_usercode;}
 $result = doquery($query);
 if(mysql_num_rows($result) != 0){
  while ($row = mysql_fetch_array($result)){
   $id = $row['id'];
   $image = $row['image'];
   $alt = $row['alt'];
   $adtype = $row['adtype'];
   $adtext = $row['adtext'];
   $btype = $row['bannertype'];
   $bwidth=$row['rez_hor'];
 	 $bheight=$row['rez_vert'];
   $bname=$row['name'];
   $uname='������� <a href='.$zpath.'user.php?type=show&code='.$ps_usercode.'>'.$row['login'].'</a>';
   if($adtype == 1){
   
    if (substr($image,-3)=='swf'){
    $adimg = '<embed src="'.$image.'" alt="'.$zpath.'module/'.$zmodule.'/ad/'.$image.'" width="'.$bwidth.'" height="'.$bheight.'">';
   }else{
   $adimg ="<img border='0' src='$image' alt='$zpath' width='$bwidth' height='$bheight'>";
   }
   }else{
    $adimg = $adtext;
   }
   include("templates/list.htm");
  }
  echo "<br>";
 }else{
  $message = "<tr><td align='center' class='message' colspan='2'>No banners found.</td></tr>";
  $msg .= $message . "</table>";
  echo $msg;
 }
}

if($action == "delete"){
 $query = "DELETE FROM $banners WHERE id = $id";
 $result = doquery($query);
}

if($action == "item"){
 $query = "select $banners.*, $types.rez_hor, $types.rez_vert, $types.name from $banners inner join $types on $types.ID=$banners.bannertype WHERE $banners.id = $id";
 if($ps_status<4){$query.=' and usercode='.$ps_usercode;}
 $result = doquery($query) or die(mysql_error());
 $row = mysql_fetch_array($result);
 $id = $row['id'];

 $adtype = $row['adtype'];
 $image = $row['image'];
 $alt = $row['alt'];
 $link = $row['link'];
 $adtext = $row['adtext'];
 $status = $row['status'];
 $bwidth=$row['rez_hor'];
 $bheight=$row['rez_vert'];
 $lifetime=$row['lifetime'];
 $bannertype=$row['bannertype'];
  //���� ����� - �� ����� ������ ��� �������
 if ($ps_status>3){
   $btype= "<select name='btype' size='1'>";
  $query='select * from '.$types;
  $result = doquery($query);
  if(mysql_num_rows($result) != 0){
  while ($row = mysql_fetch_array($result)){
   $bid= $row['ID'];
   $bname = $row['NAME'];
   $bnwidth = $row['REZ_HOR'];
   $bnheight = $row['REZ_VERT'];
   $bprice = $row['PRICE'];
   $btype.="<option value=".$bid;
   if($bid==$bannertype){$btype.=" selected ";}
   $btype.=">".trim($bname)." ".$bnwidth.'x'.$bnheight.' '.$ul[125].' '.$bprice."</option>";
   }
   }
 $btype.="</select>";
 }else{
 $btype = "<input name='btype' type='hidden' value='$bannertype'>".$row['name'].' '.$row['rez_hor'].'x'.$row['rez_vert'];
 }
 if(!isset($adtype) || $adtype == 1){
  $adstyle = "&nbsp;image<input name='adtype' type='radio' value='1' checked>&nbsp;text / html<input name='adtype' type='radio' value='0'>";
 }else{
  $adstyle = "&nbsp;image<input name='adtype' type='radio' value='1'>&nbsp;text / html<input name='adtype' type='radio' value='0' checked>";
 }
 //�������� ������ ����� ������ �������
 if($ps_status>4){
	 if(!isset($status) || $status == 1){
	  $radio = "&nbsp;".$ul[119]."<input name='status' type='radio' value='0'>&nbsp;".$ul[118]."<input name='status' type='radio' value='1' checked>";
	 }else{
	  $radio = "&nbsp;".$ul[119]."<input name='status' type='radio' value='0' checked>&nbsp;".$ul[118]."<input name='status' type='radio' value='1'>";
 	}
 }else{
 	if(!isset($status) || $status == 1){
  	$radio = "<input name='status' type='hidden' value='1'>".$ul[118];
 	}else{
 	 $radio = "<input name='status' type='hidden' value='0'>".$ul[119];
 	}
 }
 $act = "update";
 if($adtype == 1){
  if (substr($image,-3)=='swf'){
  $imgrow = "<tr><td align='center' class='f9' colspan='2'>     
		<object type='application/x-shockwave-flash' 
		data= '$image' height='$bheight' width='$bwidth'>
		<param name='movie' value='$image'>
		<param name='quality' value='high'><embed border='0' src='$image' width='".$bwidth."' height='".$bheight."'></embed></object></td></tr>";
 }else{
	$imgrow = "<tr><td align='center' class='f9' colspan='2'>     
		<img border='0' src='$image' alt='$alt' width='$bwidth' height='$bheight'></td></tr>";
 }
 }else{
  $imgrow = "<tr><td align='center' class='f9' colspan='2'>$adtext</td></tr>";
 }
 $arrtime=getdate($lifetime);
 $lifetime=$arrtime['mday'].'-'.str_pad($arrtime['mon'],2, "0", STR_PAD_LEFT).'-'.$arrtime['year'] ;
 if ($ps_status>3){
 $ltime='<input value="'.$lifetime.'"  name="lifetime"  readonly /> <a href="javascript:showCal(\'Calendar1\')">'.$ul[130].'</a>';
 }else{
 $ltime=$lifetime;
 }
 include("templates/add.htm");
}



if($action == "stats"){
 if(isset($adid)){
  $query = "select $banners.*, $types.rez_hor, $types.rez_vert, $types.name from $banners inner join $types on $types.ID=$banners.bannertype WHERE $banners.id = ".$adid;
  if($ps_status<4){$query.=' and usercode='.$ps_usercode;}
  $result = doquery($query);
  $row = mysql_fetch_array($result);
  $image = $row['image'];
  $adtype = $row['adtype'];
  $adtext = $row['adtext'];
  $height= $row['rez_vert'];
  $width= $row['rez_hor'];
  $imgrow ="<table align='center' class='head' width='80%' border='1' cellspacing='0' cellpadding='2'>";
  if($adtype == 1){
   $imgrow .= "<tr class=f9><td align='center' class='list' colspan='7' height='84'><embed border='0' src='$image' width='$width' height='$height'></td></tr></table>";
  }else{
   $imgrow .= "<tr><td align='center' class='list' colspan='7' height='84'>$adtext</td></tr></table>";
  }
 }
 include('stats.php');
}

if($action=='notall'){
 echo '<center>'.$zl['529'].'</center>';
}
if($action=='needreg'){
 echo '<center>'.$ul['127'].'</center>';
}
include("templates/footer.htm");
?>
