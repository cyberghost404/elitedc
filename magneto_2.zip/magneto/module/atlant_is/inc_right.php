<?php
$ps1=$_SERVER["PHP_SELF"];
$ps1=ucase($ps1);
$pb1=0;
for ($pi1=strlen($ps1);$pi1>=1;$pi1--){
	if ($pb1==0){
		if (mid($ps1,$pi1,1)=="/"){
			$ps2=mid($ps1,$pi1+1,strlen($ps1));
			$pb1=1;
		}
	}
}
if ($_SERVER['QUERY_STRING']!=""){
	$ps3=$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
}else{
	$ps3=$_SERVER['PHP_SELF'];
}
?>

<TD width=2>&nbsp;</TD>

<TD width=190px valign=top>
	<table cellSpacing=0 cellPadding=0 border=0>
		<td width="190px" height="1px" bgcolor="<?php echo $zcmas[4]?>"></td>
	</table>

		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>


			<TR class=f10 height=1>
  				<td>

				<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
					<TR class=f10 height=14>
						<td width=27 align=center>
  							<img src="main/color/scheme/<?php echo $ps_color;?>/element_user.png" width=16 height=16>
  						</TD>
						<td><font color="<?php echo $zcmas[50]?>">
				      			<b><?php echo $zl['483']?></b>
  						</font></TD>
					</TR>
				</TABLE>

				</td>
			</TR>



			<TR class="f9b">
				<td width=190>
				<?php

			if ($ps_usercode==0){
				//�����
				//������
				//����
				?>

				<center><form method="post" name="frmlogin" action="index.php">
					<input type="HIDDEN" name="type" value="login">
					<TABLE cellSpacing="0" cellPadding="0" width="100%" align=center valign=center border="0">

						<TR height="6" class="f8b">
							<TD></TD>
							<TD></TD>
						</TR>


						<TR height="12" class="f8b">
							<TD align="right" valign="bottom" width="110" height="12">
								<br><?php echo $zl['31']?>:&nbsp;
							</TD>
							<TD align="left" valign="bottom" height="12">
								<input type="text" name="magneto_login" size="9" maxlength="40" class=input2 onFocus="id=className;" onblur="id=''">
							</TD>
						</TR>
						<TR height="12" class="f8b">
							<TD align="right" valign="top" width="110" height="12">
							<?php echo $zl['32']?>:&nbsp;
							</TD>
							<TD align="left" valign="top" height="12">
								<script type="text/javascript">
									$(function(){
									$(':password').keyboardLayout();
									});
								</script>
								<input type="password" name="magneto_pass" class=input2 size="9" maxlength="20" onFocus="id=className;" onblur="id=''">


							</TD>
						</TR>

						<TR height="12" class="f8b">
							<TD align="right" valign="middle" width="110" height="12">
								<?php

					if (getconf("ISWORK","VALUEINT")==1){
						//�����������
						echo '<a href="index.php?type=register">'.$zl['37'].'</a>&nbsp;&nbsp;';
					}

								?>
							</TD>
							<TD align="left" valign="middle" height="12">
								<input class=inputb3 type="submit" value="<?php echo $zl['33']?>" onMouseOver="id=className" onMouseOut="id=''"><br>
							</TD>
						</TR>



					</TABLE>
					<?php
					if ($ps_msg=="badpass") $ps_msg2=$zl['34'];//������������ ����� ��� ������!
					if ($ps_msg=="newpass") $ps_msg2=$zl['35'];//������� ��� ����� �������
					if ($ps_msg2!="") {
						echo '<font color="'.$zcmas[16].'"><b>';
						echo $ps_msg2.'<br>';
						if ($ps_msg2==$zl['34']){//������������ ������!
							//������������?
							echo '<a href="index.php?type=restore">'.$zl['36'].'</a>';
						}
						echo '</b></font>';
					}

					?>
				</form><center>
				<?php
			}else{
				?>
				<center>
				<?php
				$rs_2=mysql_query("select RATINGS,LOGIN,POSTER,DATEREG,LASTVISIT from tbl_user where CODE=".$ps_usercode,$conn1);
					$rs=mysql_fetch_array($rs_2);
					$ps2=$rs['POSTER'];
					if ($ps2!=""){
						$ps_isr=getconf("ISREFLEX_AVA","VALUEINT");
						?>
						<br>
						<img src="main/avatar/<?php echo $ps2?>" width=80 height=80 border=0 <?php if ($ps_isr==1) echo 'class="reflex itiltnone iopacity100"';?>>
						<br>
					<?php
					}
					$ps1=$rs['LOGIN'];
					$ps_israt=1;
				mysql_free_result($rs_2);
				//�����
				?>
				<font size=3><a href="user.php?type=show&code=<?php echo $ps_usercode?>"><?php echo $ps1?></a></font><br></center>

				<font size=1><center>
<!--/*
				&nbsp;&nbsp;<?php echo $zl['201'];?><br>&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $rs['DATEREG']?></b><br>
				&nbsp;&nbsp;<?php echo $zl['202'];?><br>&nbsp;&nbsp;&nbsp;&nbsp;<b><?php echo $rs['LASTVISIT']?></b><br>
*//!-->
				&nbsp;&nbsp;��� IP: <b><?php echo $_SERVER["REMOTE_ADDR"];?></b><br>
				&nbsp;&nbsp;<?php echo $zl['115'];?> <b><?php echo $rs['RATINGS']?></b><?php echo getstar(floor($rs['RATINGS']*0.1));?><br>

				<?php
				if ($zright['DO_KAT']==1 || $zright['DO_SET']==1){
					?>
					<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top class=table_leftmenu_user_menu><TR><TD align=center class=f8b>
					<?php
					if ($zright['DO_KAT']==1){
					//���������
					?><a href="kat.php?type=edit"><?php echo $zl['62']?></a><br><?php
					}
					if ($zright['DO_SET']==1){
					//���������
					?><a href="settings.php"><?php echo $zl['64']?></a><br><?php
					}
					?>
					</TD></TR></TABLE>
					<?php
				}
				?>
				<a href="index.php?type=logout"><?php echo $zl['39']?></a></center>
				</font>

				<?php
					$ps_israt=0;
			}

				?>
				</td>
			</TR>
		</TABLE>

<?php


// ���� ������� ���������, ��� �������� ��� ����� ����.
if (getconf("ISWORK","VALUEINT")!=0){



//��������� �������
	if (getconf("ISRNDTOPICLEFT","VALUEINT")==1){
		//��������� �������
		?>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
  			<TR class=f10 height=16>
  				<td>
		      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element>
		      			<TR class=f10 height=16>
		      				<td width=25 align=center>
  								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
  							</TD>
		      				<td><font color="<?php echo $zcmas[50]?>">
		      					<b><?php echo $zl['580']?></b>
  							</font></TD>
  						</TR>
  					</TABLE>
  				</TD>
  			</TR>
			<TR>
  				<td class=f9 align=center>
  					<?php
					$rs_2 = mysql_query("select * from tbl_base where ISMODER=1 order by rand() limit 1",$conn1);
						$rs=mysql_fetch_array($rs_2);
						$ps1=$rs['POSTER'];
						$ps_gwidth=94;
						?>
						<a href="topic.php?type=show&code=<?php echo $rs['CODE']?>" class=linkm1><b><?php echo $rs['NAZV'];?></b></a><br>
						<?php
						if ($ps1!=""){
							?>
							<TABLE cellSpacing=5 cellPadding=0 border=0>
								<TR>
									<TD align=center>
										<a href="topic.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $rs['NAZV']?>">
										<?php echo smalleskiz($ps1);?>
										</a>
									</TD>
								</TR><TR>
									<TD class=f8b align=center>
										<?php
										echo '>> <a class=linkm1 href="kat.php?type=showkat&type2='.$rs['KAT'].'">'.getkatname($rs['KAT']).'</a><br>';
//										echo $zl['110'].' '.cdate($rs['DATEADD']).'<br>';
										echo $zl['113'].' '.$rs['RAZMER'].' '.$zl['114'].'<br>';
										echo $zl['115'].' '.$rs['VOTES'].' ';?>
									</TD>
								</TR>
							</TABLE>
							<?php
						}
					mysql_free_result($rs_2);
					?>
  				</TD>
  			</TR>
  		</TABLE>
		<?php
	}
//��������� ����������
	if (getconf("ISRNDTOPICLEFT","VALUEINT")==1){
		//��������� ����������
		?>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_leftmenu>
  			<TR class=f10 height=1>
  				<td>
		      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
		      			<TR class=f10 height=16>
		      				<td width=25 align=center>
  								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
  							</TD>
		      				<td><font color="<?php echo $zcmas[50]?>">
		      					<b><?php echo $ul['13']?></b>
  							</font></TD>
  						</TR>
  					</TABLE>
  				</TD>
  			</TR>
			<TR>
  				<td class=f9 align=center>
  					<?php
					$rs_2 = mysql_query("select * from tbl_persona where ISMODER=1 order by rand() limit 1",$conn1);
						$rs=mysql_fetch_array($rs_2);
						$ps1=$rs['POSTER'];
						?>
						<a href="persona.php?type=show&code=<?php echo $rs['CODE']?>" class=linkm1><b><?php echo $rs['NAZV']."<br>".$rs['NAZVROD'];?></b></a><br>
						<?php
						if ($ps1!=""){
					$size = getimagesize($zserver."main/persona/".$ps1);
					$pi_w = $size[0];
					$pi_h = $size[1];
					if ($pi_h>128) {
						$pi3=$pi_h/128;
						$pi_h=128;
						$pi_w=round($pi_w/$pi3);
					}
					if ($pi_h<128){
					$pi3=128/$pi_h;
					$pi_h=128;
					$pi_w=round($pi_w*$pi3);
					}
							?>
							<TABLE cellSpacing=5 cellPadding=0 border=0>
								<TR>
									<TD align="center">
										<a href="persona.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $rs['NAZV']." / ".$rs['NAZVROD']?>">
										<img src="main/persona/<?php echo $ps1?>" width=<?php echo $pi_w?> height=<?php echo $pi_h?> border=0>
										</a>
									</TD>
								</TR>
							</TABLE>
							<?php
						}
					mysql_free_result($rs_2);
					?>
  				</TD>
  			</TR>
  		</TABLE>
		<?php
	}

	?>

	<?php
	//������ �����
	if (getconf("ISTAGS","VALUEINT")==1){
		?>
		<TABLE cellSpacing=0 cellPadding=0 width="190pt" border=0 class=table_leftmenu>
   			<TR class=f10 height=14>
  				<td>
		      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element>
		      			<TR class=f10 height=14>
		      				<td width=25 align=center>
  								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
  							</TD>
		      				<td><font color="<?php echo $zcmas[50]?>">
		      					<b><?php echo $ul['14']?></b>
  							</font></TD>
  						</TR>
  					</TABLE>
  				</TD>
  			</TR><TR>
  				<td>

		<div id="flashcontent"></div>
    <script type="text/javascript" src="main/config/swfobject.js"> </script>
		<script type="text/javascript">
			var so = new SWFObject("main/config/tagcloud.swf", "tagcloud", "190", "210", "9", "#ffffff");
			// uncomment next line to enable transparency
			so.addParam("wmode", "transparent");
			so.addVariable("tcolor", "0x000000");
			so.addVariable("mode", "tags");
			so.addVariable("distr", "true");
			so.addVariable("tspeed", "60");
			so.addVariable("tagcloud", "<tags><?php
			//��������� ����
			$ps_col=$zcmas[10];
			$ps_col=str_replace("#","",$ps_col);
			//�������� ����������� ����������
			$ps_koef=1;
			$rs_2 = mysql_query("select tbl_base.DOWN as b_DOWN from tbl_tags,tbl_base where tbl_tags.BASECODE=tbl_base.CODE and tbl_base.ISMODER=1 order by tbl_base.DOWN desc limit 1",$conn1);
				$rs=mysql_fetch_array($rs_2);
				$ps_koef=$rs['b_DOWN'];
			mysql_free_result($rs_2);
			$ps_koef2=25;
			$ps_koef3=$ps_koef2/$ps_koef;
      $maxlen=25;
			$rs_2 = mysql_query("select tbl_base.DOWN as b_DOWN, tbl_base.CODE as b_CODE, substr(tbl_base.NAZV,1,case when locate('/',tbl_base.NAZV)>0 then locate('/',tbl_base.NAZV)-1 else ".$maxlen." end) as b_NAZV from tbl_tags,tbl_base where tbl_tags.BASECODE=tbl_base.CODE and tbl_base.ISMODER=1",$conn1);
				while (($rs=mysql_fetch_assoc($rs_2))!==false){
					$ps_size=ceil($rs['b_DOWN']*$ps_koef3);
					if ($ps_size<8) $ps_size=8;
					echo "<a href='topic.php?type=show%26code=".$rs['b_CODE']."' color='0x".rand(3,15)."f".rand(1,15)."f".rand(1,15)."f' style='$ps_size' alt='ALT' title='TITLE'>".$rs['b_NAZV']."</a>";
				}
			mysql_free_result($rs_2);
			?></tags>");
			so.write("flashcontent");
		</script>

		</td></TR></TABLE>
		<?php
	}
}
	?>

   		<TABLE cellSpacing=1 cellPadding=1 width="100%" border=0 class=table_leftmenu>
   			<!--//>
        <TR class=f10 height=14>
  				<td>
		      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element>
		      			<TR class=f10 height=14>
		      				<td width=25 align=center>
  								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
  							</TD>
		      				<td><font color="<?php echo $zcmas[50]?>">
		      					<b><?php echo $ul[51]?></b>
                  </td>
              </TABLE>
          </td>
        </tr>
         <tr>
            <td class=f7>
                  <?//php require_once('./module/'.$zmodule.'/bor.php')?>
            </td>
         </tr>
        </table>
        <!-->
       <tr align=center>
       <td>
       <?php showad(5);?>
       </td>
       </tr>
       <tr align=center>
       <td>
       <?php showad(6);?>
       </td>
       </tr>
       <tr>
       <td>
       <br>
       </td>
       </tr>

	<table cellSpacing=0 cellPadding=0 border=0>
		<td width="190px" height="1px" bgcolor="<?php echo $zcmas[4]?>"></td>
	</table>


</TD>

<TD width=1>&nbsp;</TD>


