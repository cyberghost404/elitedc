<?php

$imagefile ='imdb/ratio.gif';//���� � ������� ��������
$rat = round($_GET['ratio'],2);
//if($rat>0){
$font='imdb/tahoma.ttf';
$peoples = $_GET['peoples'];
$rat_c = (int) abs($rat);
$im = ImageCreateFromGIF($imagefile);
$tp=$_GET['type'];
if($tp=='imdb'){
  $pasrer = 'imdb/imdb.gif';
}else if($tp=='magneto'){
  $pasrer ='imdb/magneto.gif';
}else{
  $pasrer = 'imdb/kinopoisk.gif';
}
$ip = ImageCreateFromGIF($pasrer);
$s0 = ImageCreateFromGIF('imdb/0.gif');
$s1 = ImageCreateFromGIF('imdb/1.gif');
$s2 = ImageCreateFromGIF('imdb/2.gif');
$s3 = ImageCreateFromGIF('imdb/3.gif');
$s4 = ImageCreateFromGIF('imdb/4.gif');
if($tp=='imdb'){
  imagecopy($im, $ip, 0, 0, 0, 0, 52, 27);
  }else if ($tp=='magneto'){
  imagecopy($im, $ip, 0, 0, 0, 0, 58, 27);
  }else{
  imagecopy($im, $ip, 0, 0, 0, 0, 60, 27);
}

$black = imagecolorallocate($im, 0,0,0);
$grey = imagecolorallocate($im, 128,128,128);
$white = imagecolorallocate($im, 255, 255, 255);
//������� ����� ���������
if ($rat>0){
	for($i = 0; $i < $rat_c ; $i++)
	{
	   imagecopy($im, $s0, $i * 10, 27, 0, 0, 13, 13);
	}
	//������� "������������"
	$rat_d = $rat - $rat_c;
	//echo $rat_d;
	//echo  gettype ($rat_c) ;
	if($rat_d==0) {
	imagecopy($im, $s4, ($rat_c)*10, 27, 0, 0, 13, 13);
	}elseif($rat_d>=0.75) {
	imagecopy($im, $s1, ($rat_c)*10, 27, 0, 0, 13, 13);
	}elseif($rat_d>=0.5) {
	imagecopy($im, $s2, ($rat_c)*10, 27, 0, 0, 13, 13);
	}elseif($rat_d>=0.1) {
	imagecopy($im, $s3, ($rat_c)*10, 27, 0, 0, 13, 13);
	}elseif($rat_d<0.1){
	imagecopy($im, $s4, ($rat_c)*10, 27, 0, 0, 13, 13);
	}
}
//������� ������ ���������
if ($rat>0){
	for($i = $rat_c+1; $i < 10; $i++)
	{
	   imagecopy($im, $s4, ($i) * 10, 27, 0, 0, 13, 13);
	}
}else{
		for($i = 0; $i < 10; $i++)
	{
	   imagecopy($im, $s4, ($i) * 10, 27, 0, 0, 13, 13);
	}
}
//������� �������
//$font=imageloadfont("Tahoma");
if($tp=='imdb'){
 //imagestring($im, 5, 55, 0, $rat, $grey);
 imagettftextoutline($im,10,0,55,12,$grey,$white,$font,$rat,1);
}else if ($tp=='magneto'){
imagettftextoutline($im,10,0,60,12,$grey,$white,$font,$rat,1);
}else{
  //imagestring($im, 5, 56, 0, $rat, $grey) ;
  imagettftextoutline($im,10,0,56,12,$grey,$white,$font,$rat,1);
}
;
if($tp=='imdb'){
  //imagestring($im, 2, 55, 13, $peoples,$grey);
    imagettftextoutline($im,8,0,55,23,$grey,$white,$font,$peoples,1);
}else if ($tp=='magneto'){
  //imagestring($im, 1, 60, 16, $peoples,$grey);
  imagettftextoutline($im,8,0,60,23,$grey,$white,$font,$peoples,1);
 }else{
  //imagestring($im, 1, 62, 16, $peoples,$grey);
  imagettftextoutline($im,8,0,60,23,$grey,$white,$font,$peoples,1);
}

imagegif($im);
imagedestroy($im);
imagedestroy($ip);
for($i=0;$i<=4;$i++){
 eval('imagedestroy($s'.$i.');');
}
//}


function sized($size, $cx, $text, $fontfile)
	{
	$bbox = imagettfbbox($size, 0, $fontfile, $text); //calculate the pixel of the string
	$cx = $cx + abs($bbox[4] - $bbox[0])+2;
	return $cx;
	}
function imagettftextoutline($sig,$size,$angle,$x,$y,$col,$outlinecol,$fontfile,$text, $width){
	for($xc=$x-$width; $xc<=($x+$width); $xc++){
     	for ($yc=$y-$width; $yc<=($y+$width); $yc++){
			imagettftext($sig ,$size ,$angle,$xc ,$yc, $outlinecol ,$fontfile ,$text);
		}
	}
	imagettftext($sig,$size,$angle,$x,$y,$col,$fontfile,$text);
}
?>