<?php
//require_once('main/config/functlist.php' );
global $ps_menukat;
openconn1();

iswork();
verifyuser();
if (getconf("ISPERSENABLED","VALUEINT")==0){
	header("Location: index.php");exit;
}
//если тип parse и передано имя, то парсим, собсна...
if ($ps_type=="parse"){
if( $_GET['persona']!=""){
//вызываем поиск на кинопоиске с переданным именем
$persona=str_replace('|',' ', $_GET['persona']);
}
$ps_type="new";
}


if ($ps_type=="new" || $ps_type=="new2" || $ps_type=="newpre" || $ps_type=="delete" || $ps_type=="edit" || $ps_type=="delposter" || $ps_type=="addcross") dopverify("DO_PERS");
if ($ps_type=="moderyes" || $ps_type=="moderno" || $ps_type=="moderdop2" || $ps_type=="moderdop") dopverify("DO_MODER");
if ($ps_type=="addcross" || $ps_type=="moderdop") $ps_style="short";

//Показываем аякс - отображение схожей персоналии
//=========================================================================================
if ($ps_type=="new_pre"){
	$ps_test=requestdata('stest');
	$ps_test=iconv("utf-8", "cp1251", $_GET['stest']);
	if ($ps_test=='абв') $ps_search=iconv("utf-8", "cp1251", $_GET['search']);
	if (strlen($ps_search)>2){
		header("Content-type: text/html; Charset=Windows-1251");
		if (recordcount_new("tbl_persona where NAZV LIKE '%".$ps_search."%'")>0){
			//В базе уже есть персоналии
			echo "<br><b>".$zl['392']."</b>:";
			echo '<br><hr>';
			$ps_constr="select * from tbl_persona where NAZV LIKE '%".$ps_search."%' limit 10";
			$rs_2=mysql_query($ps_constr,$conn1);
				while (($rs=mysql_fetch_assoc($rs_2))!==false) {
					//Просмотреть персоналию
					//дата добавления
					?>
					&bull; <a title="<?php echo $zl['363']?>" href="persona.php?type=show&code=<?php echo $rs['CODE']?>"><?php echo $rs['NAZV']?></a> - <?php echo $zl['280']?>: <?php echo cdate2($rs['DATEADD'])?><br>
					<?php
				}
			mysql_free_result($rs_2);
			echo '<hr>';
		}
	}
	exit;
}

//Проверяем - есть ли такая персоналия вообще
//=========================================================================================
if ($ps_type=="edit" || $ps_type=="show"){
	if (recordcount_new("tbl_persona where CODE=".$ps_code)==0){
		header("Location: index.php");exit;
	}
}


//Удаляем собственную персону
//=========================================================================================
if ($ps_type=="delete"){
	$rs_2=mysql_query("select WHOADD from tbl_persona where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['WHOADD'];
	mysql_free_result($rs_2);
	if ($ps1==$ps_usercode || $zright['DO_MODER']==1){
		$ps_type="moderno";
		$ps_type2="delete";
	}else{
		header("Location: persona.php");exit;
	}
}



//Отправляем на доработку
//=========================================================================================
if ($ps_type=="moderdop2"){
	$rs_s2=mysql_query("update tbl_persona set ISMODER=0, ISDOPEDIT=1, WHODOPEDIT=".$ps_usercode.", WHYDOPEDIT='".$ps_type2."' where CODE=".$ps_code,$conn1);
	?>
	<script type="text/javascript" language="JavaScript">
			{
			window.opener.location="subkat.php?type=ismoderpersona";
			window.close()
			}
	</script>
	<?php
}


//=========================================================================================
if ($ps_type=="moderyes"){
	$rs_s2=mysql_query("update tbl_persona set ISMODER=1, WHOMODER=".$ps_usercode.", DATEMODER='".sqldatetime2(mktime())."' where CODE=".$ps_code,$conn1);
	header("Location: subkat.php?type=ismoderpersona");exit;
}


//=========================================================================================
if ($ps_type=="moderno"){
	//Удаляем постер
	$rs_2=mysql_query("select POSTER,WHOADD,WHOMODER from tbl_persona where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['POSTER'];
		$ps_whoadd=$rs['WHOADD'];
		$ps_whomoder=$rs['WHOMODER'];
	mysql_free_result($rs_2);
	if ($ps1!=""){
		if (file_exists($zserver.'main/persona/'.$ps1)==true){
			unlink($zserver.'main/persona/'.$ps1);
		}
	}
	//**********************************************
	//Удаляем статистику по скачиванию ссылок
	$pi_rat_persona=getconf("RAT_PERSONA","VALUESTR");
	//Уменьшаем у автора рейтинг
	$rs_s2=mysql_query("update tbl_user set PERSONA=(PERSONA-1),RATINGS=(RATINGS-".$pi_rat_persona.") where CODE=".$ps_whoadd,$conn1);
	//**********************************************

	//Удаляем связки
	$rs_s2=mysql_query("delete from tbl_cross2 where FIRSTCODE=".$ps_code,$conn1);
	//Удаляем саму персону
	$rs_s2=mysql_query("delete from tbl_persona where CODE=".$ps_code,$conn1);
	if ($ps_type2!="delete"){
		header("Location: subkat.php?type=ismoderpersona");
		exit;
	}else{
		header("Location: index.php");
		exit;
	}
}


//=========================================================================================
//Проверяем - если просмотр немодерированой персоны
if ($ps_type=="show" && $zright['DO_MODER']!=1){
	$rs_2=mysql_query("select * from tbl_persona where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$pi1=$rs['ISMODER'];
		if ($rs['WHOADD']==$ps_usercode) $pi1=1;
	mysql_free_result($rs_2);
	if ($pi1==0){
		header("Location: index.php");
		exit;
	}
}

//=========================================================================================
//Проверяем - если не имеешь права редактировать
if ($ps_type=="edit" && $zright['DO_MODER']!=1){
	$pi1=0;
	$rs_2=mysql_query("select * from tbl_persona where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['WHOADD']==$ps_usercode) $pi1=1;
	mysql_free_result($rs_2);
	if ($pi1==0){
		header("Location: index.php");
		exit;
	}
}

//Удаляем связку - доп.проверка
//=========================================================================================
if ($ps_type=="delcross"){
	$rs_2=mysql_query("select * from tbl_cross2 where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_persona=$rs['FIRSTCODE'];
		$rs2_2=mysql_query("select WHOADD from tbl_persona where CODE=".$rs['FIRSTCODE'],$conn1);
			$rs2=mysql_fetch_array($rs2_2);
			$ps1=$rs2['WHOADD'];
		mysql_free_result($rs2_2);
		$rs2_2=mysql_query("select WHOADD from tbl_base where CODE=".$rs['SECONDCODE'],$conn1);
			$rs2=mysql_fetch_array($rs3_2);
			$ps2=$rs2['WHOADD'];
		mysql_free_result($rs2_2);
	mysql_free_result($rs_2);
	if ($ps1==$ps_usercode || $ps2==$ps_usercode || $zright['DO_MODER']==1){
		$rs_s2=mysql_query("delete from tbl_cross2 where CODE=".$ps_code,$conn1);
		//Уменьшаем рейтинг у персоналии
		$rs_s2=mysql_query("update tbl_persona set LINKS=(LINKS-1) where CODE=".$ps_persona,$conn1);
		if ($ps_type2!=1){
			header("Location: persona.php?type=show&code=".requestdata('backcode'));exit;
		}else{
			header("Location: topic.php?type=show&code=".requestdata('backcode'));exit;
		}
	}else{
		header("Location: index.php");exit;
	}
}



//Делаем связку - доп.проверка
//=========================================================================================
if ($ps_type=="addcross"){
	$rs_2=mysql_query("select * from tbl_persona where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['WHOADD'];
	mysql_free_result($rs_2);
	if ($ps1!=$ps_usercode && $zright['DO_MODER']!=1){
		header("Location: index.php");exit;
	}
	if ($ps_step=="2" && $ps_search=="") $ps_step="";
}
//=========================================================================================


?>
<HTML>
<HEAD>
	<?php
	$ps1="";
	if ($ps_type=="new") $ps1=$zl['360'];//Добавление персоналии
	if ($ps_type=="edit") $ps1=$zl['361'];//Редактирование персоналии
	if ($ps_type=="addcross") $ps1=$zl['362'];//Связка персоналии
	if ($ps_type=="moderdop") $ps1=$zl['261'];//Возврат на доработку
	if ($ps_type=="show"){
		$rs_2=mysql_query("select NAZV from tbl_persona where CODE=".$ps_code,$conn1);
			$rs=mysql_fetch_array($rs_2);
			$ps1=$rs['NAZV'];
		mysql_free_result($rs_2);
	}
	if ($ps_type=="new"){
		?>
		<script language="JavaScript">
			function window_onload() {
				frmlogin.valuestr_1.focus();
			}
		</script>
		<?php
	}
	?>
	<TITLE><?php echo $ps1;?> - <?php echo getconf("PROJECTNAME","VALUESTR")?></TITLE>
	<?php site_header()?>
</HEAD>
<BODY leftMargin=0 topMargin=0 <?php if ($ps_type=="new"){echo 'onload="return window_onload()"';}?>>
<?php
if ($ps_style=="") require_once('inc_top.php');
?>
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	<TR valign=top>
		<?php
		if ($ps_style=="") require_once('inc_left.php');
		?>

		<TD class=f10>
    		<?php


			//==========================================================================================
			if ($ps_type=="addcross"){
				if ($ps_step=="3"){
					//Забиваем в базу
					$ps1=requestdata("secondcode");
					if ($ps1!=""){
						//Удаляем (если были) двойные ссылки
						$rs_s2=mysql_query("delete from tbl_cross2 where FIRSTCODE=".$ps_code." and SECONDCODE=".$ps1,$conn1);
						//Приписываем новую связку
						$rs_s2=mysql_query("insert into tbl_cross2 (FIRSTCODE,SECONDCODE) values (".$ps_code.",".$ps1.")",$conn1);
						//Добавляем к персоналии +1
						$rs_s2=mysql_query("update tbl_persona set LINKS=(LINKS+1) where CODE=".$ps_code,$conn1);
					}
					goback();
				}
				if ($ps_step=="2"){
					windowsize (740,600);
					?>
					<center>
					<br>
					<?php
					//Связка персоналии
					us_text2($zl['362']);
					//введите первые буквы раздачи, с которой хотите связать текущую персоналию
					?>
					<font size=1>(<?php echo $zl['381']?>)</font><br>
					<br>
					<form method="send" name="frmlogin" action="persona.php" border=0>
						<input type="hidden" name="type" value="addcross">
						<input type="hidden" name="step" value="2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<input class=input2 type="text" name="search" size="60" maxlength="200" value="<?php echo $ps_search?>" onFocus="id=className;" onBlur="id=''">
						<br>
						<br>
						<?php
						//Найти
						inputstyle($zl['267']);
						?>
						<br>
						<br>
					</form>
					<hr>
					<?php
					$pi3=recordcount_new("tbl_base where ISMODER=1 and NAZV like '%".$ps_search."%'");
					if ($pi3==0){
						//Ничего не найдено
						?>
						<br><br>
						<b><font color="<?php echo $zcmas[16]?>"><?php echo $zl['268']?>.</font></b>
						<?php
					}else{
						if ($pi3>21) $pi3=21;
						//Выберите из найденого
						?>
						<b><?php echo $zl['269']?>:</b>
						<form method="send" name="frmlogin" action="persona.php" border=0>
							<input type="hidden" name="type" value="addcross">
							<input type="hidden" name="step" value="3">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
		  					<select name="secondcode" size="<?php echo $pi3?>">
								<?php
								$pi1=0;
								$rs_2 = mysql_query("select * from tbl_base where ISMODER=1 and NAZV like '%".$ps_search."%' order by NAZV",$conn1);
									while (($rs=mysql_fetch_assoc($rs_2))!==false) {
										//Проверяем - нет ли уже связки
										if (recordcount_new("tbl_cross2 where FIRSTCODE=".$ps_code." and SECONDCODE=".$rs['CODE'])==0){
											$pi1=$pi1+1;
											$ps5=$rs['NAZV'];
											if (strlen($ps5)>60) $ps5=left_1($ps5,60).'...';
											?>
											<option value="<?php echo $rs['CODE']?>"><?php echo $ps5?></option>
											<?php
										}
									}
								mysql_free_result($rs_2);
								?>
		  					</select>
							<br>
							<br>
							<?php
							//Связать
							if ($pi1>0) inputstyle($zl['270']);
							?>
							<br>
							<br>
						</form>
						<?php
					}
				}
				if ($ps_step==""){
					windowsize (270,500);
					?>
					<center>
					<br>
					<?php
					//Связка персоналии
					us_text2($zl['362']);
					//введите первые буквы раздачи, с которой хотите связать текущую персоналию
					?>
					<font size=1>(<?php echo $zl['381']?>)</font><br>
					<br>
					<form method="send" name="frmlogin" action="persona.php" border=0>
						<input type="hidden" name="type" value="addcross">
						<input type="hidden" name="step" value="2">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<input class=input2 type="text" name="search" size="60" maxlength="200" value="" onFocus="id=className;" onBlur="id=''">
						<br>
						<br>
						<?php
						//Найти
						inputstyle($zl['267']);
						?>
						<br>
						<br>
					</form>
					<?php
				}
			}






			//==========================================================================================
			if ($ps_type=="moderdop"){
				windowsize (300,500);
				?>
				<center>
				<br>
				<?php
				//Возврат на доработку
				us_text2($zl['261']);
				?>
				<form method="post" name="frmlogin" action="persona.php" border=0>
					<b><?php echo $zl['264']?></b><br>
					<input type="hidden" name="type" value="<?php echo $ps_type?>2">
					<input type="hidden" name="code" value="<?php echo $ps_code?>">
					<INPUT TYPE="input" NAME="type2" size="50" maxlength=200 value=""><br>
					<br>
					<?php
					//Вернуть
					inputstyle($zl['265']);
					?>
					<br>
					<br>
				</form>
				<?php
			}





    		//===========================================================================================
    		if ($ps_type=="new" || $ps_type=="show" || $ps_type=="edit"){
    			if ($ps_type=="new"){
    				us_text($zl['360']);//Добавление персоналии
    				//Добавляем блок аякса - пред.поиск - есть ли такая персоналия
    				echo '<div id="persona_search" align=left><br></div>';
					//Грузим скрипт поиска
					?>
					<script>
						var xmlHttp;
						function showResultPersona(str){
							if (str.length==0){
								document.getElementById("persona_search").innerHTML="";
								document.getElementById("persona_search").style.border="0px";
								return;
							}
							xmlHttp=GetXmlHttpObject();
							if (xmlHttp==null){
								//alert ("Браузер не поддерживает HTTP-Request");
								return;
							}
							var url="persona.php?type=new_pre";
							//url=url+"?search="+encodeURIComponent(str);
							url=url+"&search="+str;
							url=url+"&stest=абв";
							url=url+"&randoms="+Math.random();
							xmlHttp.onreadystatechange=stateChanged ;
							xmlHttp.open("GET",url,true);
							xmlHttp.send(null);
						}
						function stateChanged(){
							if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
								{
								document.getElementById("persona_search").innerHTML=xmlHttp.responseText;
							}
						}
						function GetXmlHttpObject(){
							var xmlHttp=null;
							try{
								// Firefox, Opera 8.0+, Safari
								xmlHttp=new XMLHttpRequest();
							}catch (e){
								// Internet Explorer
								try{
									xmlHttp=new ActiveXObject("Microsoft.XMLHttp");
								}catch (e){
									try{
										xmlHttp=new ActiveXObject("MSXML2.XMLHttp");
									}catch (e){
										try{
											xmlHttp=new ActiveXObject("MSXML2.XMLHttp.3.0");
										}catch (e){
											try{
												xmlHttp=new ActiveXObject("MSXML2.XMLHttp.4.0");
											}catch (e){
												xmlHttp=new ActiveXObject("MSXML2.XMLHttp.5.0");
											}
										}
									}
								}
							}
							return xmlHttp;
						}
					</script>
    				<?php
    			}
    			if ($ps_type=="show" || $ps_type=="edit") {
    				$rs_2=mysql_query("select * from tbl_persona where CODE=".$ps_code,$conn1);
    				$rs=mysql_fetch_array($rs_2);
    				us_text($rs['NAZV']);
    				if ($rs['NAZVROD']!='') us_text2($rs['NAZVROD']);
    				echo '<font color="'.$zcmas[4].'" size=1>'.$zl['277'].': '.cdate($rs['DATEADD']).'</font><br>';//добавлено
    			}
    			//Если модерация - то показываем сходные персоналии
    			if ($ps_type=="show"){
    				if ($rs['ISMODER']==0){
    					//Найденные совпадения
    					echo '<br><b>'.$zl['278'].':</b><br><hr>';
    					$ps2=$rs['NAZV'];
    					$ps3=left_1($rs['NAZV'],5);
						$rs2_2 = mysql_query("select * from tbl_persona where ISMODER=1 and NAZV like '%".$ps3."%' order by NAZV",$conn1);
							while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
								//Просмотреть персоналию
								//кто добавил
								//Информация о пользователе
								//дата добавления
								?>
								&bull; <a href="persona.php?type=show&code=<?php echo $rs2['CODE']?>" title="<?php echo $zl['363']?>"><?php echo $rs2['NAZV']?></a>
								<font size=1>- <?php echo $zl['279']?>:
								<a href="user.php?type=show&code=<?php echo $rs2['WHOADD']?>" title="<?php echo $zl['12']?>"><?php echo getuserlogin($rs2['WHOADD'])?></a>
								- <?php echo $zl['280']?>: <?php echo cdate($rs2['DATEADD'])?></font>
								<br>
								<?php
							}
						mysql_free_result($rs2_2);
						echo '<hr>';
    				}
    			}
    			if (($ps_type=="new" && $ps_step=="") || $ps_type=="show" || ($ps_type=="edit" && $ps_step!="4")){
    				if ($ps_type=="new" || $ps_type=="edit"){
    					//Название
    					//Пожалуйста, заполните следующие поля
    					?>
    					<br>
						<script type="text/javascript" language="JavaScript">
							function check()
								{
								arr_field=new Array("nazv");
								arr_desc_field=new Array("<?php echo $zl['284']?>");
								error="";
								for(i=0;i<arr_field.length;i++){
									if(document.forms['frmlogin'].elements[arr_field[i]].value==''){
										//document.forms['frmlogin'].elements[arr_field[i]].focus();
										error=error+"-"+arr_desc_field[i]+"\n";
									}
								}
								if (error!=""){
							    	alert("<?php echo $zl['286']?>:\n"+error);
									return false;
								}
							}
						</script>
						<form method="post" name="frmlogin" enctype="multipart/form-data" action="upload.php" onsubmit="return check();">
		    			<?php
		    		}
		    		if ($ps_type=="show" || $ps_type=="edit"){
						$ps1=$rs['POSTER'];
						if ($ps1!=""){
							$size = getimagesize($zserver."main/persona/".$ps1);
							$pi_w = $size[0];
							$pi_h = $size[1];
							if ($pi_w>200){
								$pi3=$pi_w/200;
								$pi_w=200;
								$pi_h=round($pi_h/$pi3);
							}
							if ($pi_w<200){
								$pi3=200/$pi_w;
								$pi_w=200;
								$pi_h=round($pi_h*$pi3);
							}
							?>
							<br>
							<TABLE cellSpacing=5 cellPadding=0 width=95% border=0>
								<TR valign=top>
									<TD width=200>
									&nbsp;
										<?php
										if ($ps_type=="show"){
											//Кто добавил:
											?>
											<TABLE cellSpacing=5 cellPadding=0 width=200 border=0>
												<TR align=center>
													<TD class=f9 width=100%>
														<font size=3 color="#FFFFFF"><b><?php echo $zl['111']?></b></font><br>
														<?php
														$rs2_2=mysql_query("select * from tbl_user where CODE=".$rs['WHOADD'],$conn1);
															$rs2=mysql_fetch_array($rs2_2);
															$ps2=$rs2['POSTER'];
															if ($ps2!="" && mayavatar($rs['WHOADD'])==1){
																$ps_isr=getconf("ISREFLEX_AVA","VALUEINT");
																?>
																<img src="main/avatar/<?php echo $ps2?>" width=64 height=64 border=0 <?php if ($ps_isr==1) echo 'class="reflex itiltnone iopacity100"';?>>
																<br>
																<?php
															}
															//Информация о пользователе
															?>
															<a title="<?php echo $zl['12']?>" href='user.php?type=show&code=<?php echo $rs['WHOADD']?>'>
															<font size=3><b><?php echo $rs2['LOGIN'];?></b></font>
															</a>
															<br>
															<?php
															$ps_israt=1;
															echo getstar(floor($rs2['RATINGS']*0.1));
															$ps_israt=0;
														mysql_free_result($rs2_2);
														?>
													</TD>
												</TR>
											</TABLE>
											<?php
										}
										?>
									</TD>
									<TD class=f9 align=center>
										<img src="main/persona/<?php echo $ps1?>" width=<?php echo $pi_w?> height=<?php echo $pi_h?> border=0>
									</TD>
									<TD class=f9 align=center width=200>
									</TD>
								</TR>
							</TABLE>
							<br>
							<?php
						}
		    		}
		    		?>
						<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0>
							<TR valign=top>
								<TD class=f9>
									<?php
									if ($ps_type=="new" || $ps_type=="edit"){
										?>
										<input type="hidden" name="type" value="<?php echo $ps_type?>persona">
										<?php
										if ($ps_type=="edit"){
											?>
											<input type="hidden" name="code" value="<?php echo $ps_code?>">
											<?php
										}
									}
                  if ($ps_type=="new" && $persona!='') {
                  print "<script>
                  OpenDoc('module/".$zmodule."/kinopoisk_people.php?filmname=".$persona."')
                  </script>";
                  }
									?>
									<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
										<TR>
											<TD width=50% valign=top>
												<TABLE cellSpacing=5 cellPadding=0 width=100% border=0>
													<?php
													if ($ps_type=="new" || $ps_type=="edit"){
														//Название:
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<hr>
																<?php echo $zl['108']?>
															</TD>
															<TD>
																<br>
																<input id="valuestr_1" type="text" name="nazv" class=input2 size="54" maxlength="250" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['NAZV'];?><?php if($ps_type=="new" && $persona!='') echo $persona; ?>' onkeyup="showResultPersona(this.value)">
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new" || $ps_type=="edit"){
														//Название на родном языке
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['499']?>:<br>
																<hr>
															</TD>
                              <td>
                              <table cellSpacing=0 cellPadding=0 width=100% border=0>
                              <tr>
															<TD>
																<input type="text" name="nazvrod" class=input2 size="54" maxlength="250" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['NAZVROD'];?>'>
															</TD>
                              </tr>
                              <tr>
                              <td>
                              	<input type="button"  value="<?php echo $ul['15']; ?>" onclick="javascript:OpenDoc('module/<?php echo $zmodule?>/kinopoisk_people.php?filmname='+recode(document.frmlogin.nazv.value),<?php echo rndwindow()?>)" title="<?php echo $ul['15']; ?>" >
                              </td>
                              </tr>
                              </table>
                              </td>
														</TR>
														<?php
													}
													if (($ps_type=="new" || $ps_type=="edit") || ($ps_type=="show" && $rs['IMDB']!="")){
														//Ссылка на
														?>
														<TR class=f10>
															<TD align=right>
																<?php echo $zl['295']?> IMDB:
															</TD>
															<TD>
																<?php
																if ($ps_type=="new" || $ps_type=="edit"){
																	//если есть
																	?>
																	<input type="text" name="imdb" class=input2 size="42" maxlength="200" onFocus="id=className;" onBlur="id=''" value='<?php if ($ps_type=="edit") echo $rs['IMDB'];?>'>
																	<font size=1>(<?php echo $zl['364']?>)</font>
																	<?php
																}
																if ($ps_type=="show"){
																	//Перейти в
																	?>
																	<a target=_blank href="<?php echo $rs['IMDB'];?>" title="<?php echo $zl['297']?> IMDB">
																	<img src="main/color/scheme/<?php echo $ps_color;?>/element_imdb.png" border=0>
																	</a>
																	<?php
																}
																?>
															</TD>
														</TR>
														<?php
													}
													if ($ps_type=="new" || $ps_type=="edit"){
														//Постер:
														//Описание
														?>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['298']?>
															</TD>
															<TD>
																<input type="file" name="ps_file" class=input size="44"><br>
																<?php
																//Если разрешен URL - то пишем
																if (getconf("ISGETINET_POSTER","VALUEINT")==1){
																	echo $zl['582'];//или URL
																	?>
																	<input type="text" name="url_poster" class=input2 size="44" maxlength="500" onFocus="id=className;" onBlur="id=''" value=''><br>
																	<?php
																}
																$ps_maxsize=getconf("MAXSIZEPOSTER","VALUESTR");
																if ($ps_maxsize=='') $ps_maxsize=200;
																echo '<font size=1>'.$zl['276'].' '.$ps_maxsize.' '.$zl['503'].'</font>';//Макс. размер //КБ
																?>
															</TD>
														</TR>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['165']?>:
															</TD>
															<TD>
															</TD>
														</TR>
														<?php
													}
													?>
												</TABLE>
											</TD>
											<TD width=50% valign=top class=f9>
												<?php
												if (recordcount_new("tbl_cross2 where FIRSTCODE=".$ps_code)>0){
													//Персоналия связана с
													?>
													<B><?php echo $zl['382']?>:</b><br>
													<TABLE cellSpacing=5 cellPadding=0 width=100% border=0>
														<?php
														$pi2=0;
														$rs2_2 = mysql_query("select * from tbl_cross2 where FIRSTCODE=".$ps_code." order by CODE",$conn1);
															while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
																$pi2=$pi2+1;
																$ps1=$rs2['SECONDCODE'];
																$rs3_2=mysql_query("select NAZV,ISMODER,POSTER from tbl_base where CODE=".$ps1,$conn1);
																	$rs3=mysql_fetch_array($rs3_2);
																	if ($rs3['ISMODER']==1){
																		?>
																		<TR class=f9>
																			<TD align=center>
																				<?php
																				//Если есть постер - показываем маленькую иконку
																				$ps12=$rs3['POSTER'];
																				if ($ps12!=''){
																					$ps_gwidth=20;
																					echo smalleskiz($ps12);
																				}else{
																					echo '&bull;';
																				}
																				?>
																			</TD>
																			<TD align=left>
																				<a href="topic.php?type=show&code=<?php echo $ps1?>">
																				<?php echo $rs3['NAZV']?>
																				</a>
																				<?php
																				if ($zright['DO_MODER']==1 || $ps_usercode==$rs['WHOADD']){
																					//Удалить связку
																					//Действительно удалить связку?
																					?>
																					<a href="persona.php?type=delcross&code=<?php echo $rs2['CODE']?>&backcode=<?php echo $ps_code?>" title="<?php echo $zl['300']?>" OnClick="return confirm('<?php echo $zl['301']?>'); return true;">
																					<img src="main/color/scheme/<?php echo $ps_color;?>/element_remove.png" width=13 height=13 border=0>
																					</a>
																					<?php
																				}
																				?>
																			</TD>
																		</TR>
																		<?php
																	}
																mysql_free_result($rs3_2);
															}
														mysql_free_result($rs2_2);
														?>
													</table>
													<br>
													<?php
												}
												if (($zright['DO_MODER']==1 || $ps_usercode==$rs['WHOADD']) && $ps_type=="show"){
													//Добавить связку с раздачей
													?>
													<center>
													<font size=1>
													<a href="javascript:OpenDoc('persona.php?type=addcross&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)"><?php echo $zl['365']?></a>
													</font>
													</center>
													<?php
												}
												?>
												&nbsp;
											</TD>
										</TR>
									</TABLE>
									<?php
									if ($ps_type=="show"){
										//Описание
										?>
										<center>
										<br>
										<TABLE cellSpacing=5 cellPadding=0 class=table_int_int_table width=80% border=0>
											<TR valign=top class=f10>
												<TD>
													<center>
													<b><u><?php echo $zl['165']?>:</u></b><br>
													</center>
													<br>
													<?php echo str_replace(chr(13),"<br>",$rs['OPIS']);?><br>
													<br>
												</TD>
											</TR>
										</TABLE>
										</center>
										<?php
										//Не показываем модерацию для простых
										if ($ps_usercode==$rs['WHOADD'] || $zright['DO_MODER']==1){
											//Прочие поля - в DIV
											$ps_div="adddata";
											//Кто модерировал - скрыть
											//Кто модерировал - показать
											?>
											<br>
											<div id="<?php echo $ps_div?>_hide" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> onClick="javascript:hideel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_hide');javascript:showel('<?php echo $ps_div?>_show');" style="cursor: pointer;">
												&nbsp;&nbsp;&nbsp;
												:: <?php echo $zl['306']?>
											</div>
											<div id="<?php echo $ps_div?>_show" <?php if (requestcookie("mg_".$ps_div)==1) echo 'style="display:none"';?>  onClick="javascript:showel('mg_<?php echo $ps_div?>');javascript:hideel('<?php echo $ps_div?>_show');javascript:showel('<?php echo $ps_div?>_hide');" style="cursor: pointer;">
												&nbsp;&nbsp;&nbsp;
												:: <?php echo $zl['307']?>
											</div>
											<div id="mg_<?php echo $ps_div?>" <?php if (requestcookie("mg_".$ps_div)!=1) echo 'style="display:none"';?> >
												<TABLE cellSpacing=5 cellPadding=0 width=100% border=0>
													<TR valign=top class=f10>
														<TD align=right width=150>
															<hr>
															<?php
															//Дата добавления:
															echo $zl['110'];
															?>
														</TD>
														<TD>
															<hr>
															<?php echo cdate($rs['DATEADD']);?>
														</TD>
													</TR>
													<TR valign=top class=f10>
														<TD align=right>
															<?php
															//Кто добавил:
															echo $zl['111'];
															//Информация о пользователе
															?>
														</TD>
														<TD>
															<a title="<?php echo $zl['112']?>" href='user.php?type=show&code=<?php echo $rs['WHOADD']?>'>
															<?php echo getuserlogin($rs['WHOADD']);?>
															</a>
															<?php
															$ps_israt=1;
															echo getstar(floor(getuserratings($rs['WHOADD'])*0.1));
															$ps_israt=0;
															?>
														</TD>
													</TR>
													<?php
													if ($rs['WHOEDIT']>0){
														//Дата редактирования:
														//Кто редактировал:
														?>
														<TR valign=top class=f10>
															<TD align=right width=150>
																<?php echo $zl['308']?>
															</TD>
															<TD>
																<?php echo cdate($rs['DATEEDIT']);?>
															</TD>
														</TR>
														<TR valign=top class=f10>
															<TD align=right>
																<?php echo $zl['309']?>
															</TD>
															<TD>
																<a href='user.php?type=show&code=<?php echo $rs['WHOEDIT']?>'>
																<?php echo getuserlogin($rs['WHOEDIT']);?>
																</a>
																<?php
																$ps_israt=1;
																echo getstar(floor(getuserratings($rs['WHOEDIT'])*0.1));
																$ps_israt=0;
																?>
															</TD>
														</TR>
														<?php
													}
													//Дата модерации:
													?>
													<TR valign=top class=f10>
														<TD align=right width=150>
															<?php echo $zl['310']?>
														</TD>
														<TD>
															<?php
															if ($rs['ISMODER']==0){
																if ($rs['ISDOPEDIT']==0){
																	echo $zl['311'];//находится на модерации
																	if ($rs['WHODOPEDIT']!=""){
																		echo '<br>'.$zl['312'].'.';//Была на доработке
																		echo ' '.$zl['313'].': '.$rs['WHYDOPEDIT'].'<br>';//Причина доработки
																			//кто отправил
																			//Информация о пользователе
																		echo $zl['314'].': <a href="user.php?type=show&code='.$rs['WHODOPEDIT'].'" title="'.$zl['12'].'">'.getuserlogin($rs['WHODOPEDIT']).'</a>';
																	}
																}else{
																	echo $zl['315'];//находится на доработке
																	echo '<br>';
																	echo $zl['316'].': '.$rs['WHYDOPEDIT'].'<br>';//причина возврата
																	//кто вернул
																	//Информация о пользователе
																	echo $zl['317'].': <a href="user.php?type=show&code='.$rs['WHODOPEDIT'].'" title="'.$zl['12'].'">'.getuserlogin($rs['WHODOPEDIT']).'</a>';
																}
															}else{
																echo cdate($rs['DATEMODER']);
															}
															?>
														</TD>
													</TR>
													<TR valign=top class=f10>
														<TD align=right >
															Модератор:
														</TD>
														<TD>
															<?php
															if ($rs['ISMODER']==1){
																?>
																<a href='user.php?type=show&code=<?php echo $rs['WHOMODER']?>'>
																<?php echo getuserlogin($rs['WHOMODER']);?>
																</a>
																<?php
																$ps_israt=1;
																echo getstar(floor(getuserratings($rs['WHOMODER'])*0.1));
																$ps_israt=0;
															}
															?>
														</TD>
													</TR>
												</TABLE>
											</div>
											<?php
										}
									}
									if ($ps_type=="new" || $ps_type=="edit"){
										?>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<textarea class=TEXTAREA1 name="opis" cols="107" rows="20"><?php
										if ($ps_type=="edit") echo $rs['OPIS'];?></textarea><br>
										<?php
									}
									?>
					    		</TD>
					    	</TR>
					    </TABLE>
					    <br>
						<center>
	    				<?php
	    				if ($ps_type=="new") inputstyle($zl['337']);//Добавить
	    				if ($ps_type=="edit") inputstyle($zl['70']);//Изменить
						if ($ps_type=="show"){
							?>
							<center>
							<TABLE cellSpacing=5 cellPadding=0 class=table_int_int_table width=550 border=0>
								<TR valign=top class=f10>
									<?php
									if ($zright['DO_MODER']==1 && $rs['ISMODER']==0){
										//Подтвердить персоналию
										//Подтвердить
										?>
										<TD align=center>
											<a href="persona.php?type=moderyes&code=<?php echo $ps_code?>" title="<?php echo $zl['366']?>">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_accept.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['339']?></b>
											</a>
										</TD>
										<td width=50>
										</td>
										<?php
									}
									if ($zright['DO_MODER']==1){
										//Отправить на доработку
										//На доработку
										?>
										<TD align=center>
											<a href="javascript:OpenDoc('persona.php?type=moderdop&code=<?php echo $ps_code?>',<?php echo rndwindow()?>)" title="<?php echo $zl['340']?>">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_goback.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['341']?></b>
											</a>
										</TD>
										<?php
									}
									if ($zright['DO_MODER']==1 && $rs['ISMODER']==0){
										//Редактировать персоналию
										//Редактировать
										?>
										<td width=50>
										</td>
										<TD align=center>
											<a href="persona.php?type=edit&code=<?php echo $ps_code?>" title="<?php echo $zl['367']?>">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_edit2.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['343']?></b>
											</a>
										</TD>
										<td width=50>
										</td>
										<TD align=center>
											<?php
											//Удалить персоналию
											//Действительно удалить персоналию?
											//Удалить
											?>
											<a href="persona.php?type=moderno&code=<?php echo $ps_code?>" title="<?php echo $zl['368']?>" OnClick="return confirm('<?php echo $zl['369']?>'); return true;">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_remove.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['346']?></b>
											</a>
										</TD>
										<?php
									}
									if ($rs['WHOADD']==$ps_usercode || ($zright['DO_MODER']==1 && $rs['ISMODER']==1)){
										//Редактировать персоналию
										//Редактировать
										?>
										<TD align=center>
											<a href="persona.php?type=edit&code=<?php echo $ps_code?>" title="<?php echo $zl['367']?>">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_edit2.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['343']?></b>
											</a>
										</TD>
										<TD align=center>
											<?php
											//Удалить персоналию
											//Действительно удалить персоналию?
											//Удалить
											?>
											<a href="persona.php?type=moderno&code=<?php echo $ps_code?>" title="<?php echo $zl['368']?>" OnClick="return confirm('<?php echo $zl['369']?>'); return true;">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_remove.png" border=0 width=32 height=32><br>
											<b><?php echo $zl['346']?></b>
											</a>
										</TD>
										<?php
									}
									?>
								</TR>
							</TABLE>
							</center>
							<?php
						}
	    				?>
	    				</center>
    				</form>
	    			<?php
    			}
    			if ($ps_step=="3"){
    				//Спасибо!
    				?>
    				<center>
    				<br>
					<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=500 border=0>
						<TR valign=top>
							<TD class=f10b align=center>
								<br>
								<?php
								//Спасибо!
								echo $zl['347'];
								?><br>
								<?php
								if ($zright['DO_VERADD']!=1){
									echo $zl['370'].'.';//Персоналия отправлена на модерацию
								}else{
									echo $zl['371'].'.<br><br>';//Персоналия добавлена
									//Просмотреть персоналию
									?>
									<a href="persona.php?type=show&code=<?php echo $ps_code?>"><?php echo $zl['363']?></a>
									<?php
								}
								//Добавить еще персоналию
								?>
								<br><br>
								<a href="persona.php?type=new"><?php echo $zl['372']?></a><br>
								<br>
				    		</TD>
				    	</TR>
				    </TABLE>
				    </center>
	    			<?php
    			}
    			if ($ps_step=="4"){
    				//Спасибо!
    				?>
					<br>
    				<center>
					<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=500 border=0>
						<TR valign=top>
							<TD class=f10b align=center>
								<br>
								<?php echo $zl['347']?><br>
								<?php
								if ($zright['DO_VERADD']!=1){
									echo $zl['373'];//Изменения отправлены на модерацию. До момента модерации персоналия будет недоступна.
								}else{
									echo $zl['374'].'.<br><br>';//Персоналия изменена
									//Просмотреть персоналию
									?>
									<a href="persona.php?type=show&code=<?php echo $ps_code?>"><?php echo $zl['363']?></a>
									<?php
								}
								?>
								<br><br>
				    		</TD>
				    	</TR>
				    </TABLE>
				    </center>
	    			<?php
    			}
    			?>
    			<br>
    			<?php
			}





			?>
    	</TD>
		<TD width=20>&nbsp;

		</TD>
	</TR>
</TABLE>
<?php
if ($ps_style=="") require_once('inc_down.php');
mysql_close($conn1);
?>
</body>
</html>
