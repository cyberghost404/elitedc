<?php

/*
Project: Kinokpk.com releaser
This file is part of Kinokpk.com releaser.
Kinokpk.com releaser is based on TBDev,
originally by RedBeard of TorrentBits, extensively modified by
Gartenzwerg and Yuna Scatari.
Kinokpk.com releaser is free software;
you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
Kinokpk.com is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with Kinokpk.com releaser; if not, write to the
Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
MA  02111-1307  USA
Do not remove above lines!
*/
$mydir=getcwd();
chdir("..");
chdir("..");
require_once(getcwd().'/main/config/functlist.php' );
chdir($mydir);
require_once('inc_style.php' );
//global $ps_menukat;
iswork();
//verifyuser();

function search($source,$text)
{
$result = false;

$searchfilms = "#<a class=\"all\" href=\"/level/1/film/(.*?)a>#si";
$searchfilms2 = "#<font color=\"\#999999\">(.*?)</font>#si";

  while (preg_match_all ($searchfilms, $source, $matches))
  {
    preg_match_all($searchfilms2, $source, $matches2);
    foreach ($matches as $key => $temparray)
    foreach ($temparray as $key2 => $tempresult){
    $result[$key2] = $tempresult;
    $result[$key2] = preg_replace("#(.*?)/sr/1/\">(.*?)</#is", "<a href=\"?id=\\1\">\\2</a>", $result[$key2])."   ".$matches2[$key][$key2];
    }
 return $result;
  }
}

//������� �������� � ������� ���������� ��������� ��������
function little_poster($link,$ps_filename){
$ps_ext=lcase(right_1($link,3));
$ps_folder="temp/";
//�������� ��� �����
  	if (file_exists($ps_folder.$ps_filename)!=true) {

			ini_set("memory_limit", "2M");
			set_time_limit(0);
			$fn = basename($link);
			$size = 0;
			chdir("temp/");
      //��������� � ��������� ����-�������� �������
			$fr = fopen($link, "r");
			$fw = fopen($ps_filename, "w");
			if ($fr){
			    while (!feof ($fr)){
			        $buffer = fgets($fr, 4096);
			        fwrite($fw, $buffer);
			        $size = $size + strlen($buffer);
			    }
				fclose ($fr);
				fclose ($fw);
			}
      }
      return $ps_filename ;
}
//
//function get_poster($id)
//{
//	$host="www.kinopoisk.ru" ;
//	$request="GET /level/17/film/$id/ HTTP/1.1\r\n";
//	$request.="Host: www.kinopoisk.ru\r\n";
//	$request.="User-Agent: ".$_SERVER['HTTP_USER_AGENT']."\r\n";
//	$request.="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n";
//	$request.="Accept-Language: ru,en-us;q=0.7,en;q=0.3\r\n";
//	$request.="Accept-Encoding: deflate\r\n";
//	$request.="Accept-Charset: windows-1251,utf-8;q=0.7,*;q=0.7\r\n";
//	$request.="Keep-Alive: 300\r\n";
//	$request.="Connection: close\r\n";
//	$request.="\r\n";
//	$fp = fsockopen ($host, 80, &$errno, &$errstr, 30);
//	if (!$fp){ return print "�� ���� ����������� � $host. Error: $errno, $errstr";}
//	fwrite ($fp,$request);
//	$body = "";
//	while ($line = fgets ($fp, 1024)){ $body .= $line; }
//	$pars = "/Location:\s(.*)\s/";
//	preg_match_all($pars, $body, $matches, PREG_PATTERN_ORDER);
//	if (isset($matches[1][0])) $link = substr($matches[1][0], 1, strlen($matches[1][0])-2); else $link = "";
//	if ($link != ""){
//		echo "��������� ������� �� ������ ".$link."<br />";
//		$request="GET /$link HTTP/1.1\r\n";
//		$request.="Host: www.kinopoisk.ru\r\n";
//		$request.="User-Agent: ".$_SERVER['HTTP_USER_AGENT']."\r\n";
//		$request.="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n";
//		$request.="Accept-Language: ru,en-us;q=0.7,en;q=0.3\r\n";
//		$request.="Accept-Encoding: deflate\r\n";
//		$request.="Accept-Charset: windows-1251,utf-8;q=0.7,*;q=0.7\r\n";
//		$request.="Keep-Alive: 300\r\n";
//		$request.="Connection: close\r\n";
//		$request.="\r\n";
//		$fp = fsockopen ($host, 80, &$errno, &$errstr, 30);
//		if (!$fp){ return print "�� ���� ����������� � $host. Error: $errno, $errstr";}
//		fwrite ($fp,$request);
//		$body = "";
//		while ($line = fgets ($fp, 1024)){ $body .= $line; }
//	}
//	preg_match_all("/href=\"\/picture\/([0-9]{1,10})\/\"><img src='\/images\/poster/", $body, $matches, PREG_PATTERN_ORDER);
//
//	return "http://kinopoisk.ru/images/poster/".$matches[1][0].".jpg";
//}

    function get_content($text, $option)
    {

       global $id;

       if ($option == 'rusname') {
          $search = "#<meta name=\"keywords\" content=\"(.*?)\(#si";
       }
       elseif ($option == 'origname') {
          $search = "#<meta name=\"keywords\" content=\".*?\((.*?)\)#si";
       }
       elseif ($option == 'country') {
          $search = "#������</td><td(:?.*?)?>(.*?)</td>#si";
       }
       elseif ($option == 'year') {
          $search = "#���</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'director') {
          $search = "#��������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'slogan') {
          $search = "#������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'scenario') {
          $search = "#��������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'producer') {
          $search = "#��������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'operator') {
          $search = "#��������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'budget') {
          $search = "#������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'manyusa') {
          $search = "#����� � ���</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'manyworld') {
          $search = "#����� � ����</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'manyrf') {
          $search = "#����� � ������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
       elseif ($option == 'premieraworld') {
          $search = '#�������� \(���\)</td><td(:?.*?)?>(.*?)</td>#si';
          $parse = 1;
       }
       elseif ($option == 'premierarf') {
          $search = '#�������� \(��\)</td><td(:?.*?)?>(.*?)</td>#si';
          $parse = 0;
       }
       elseif ($option == 'time') {
          $search = '#�����</td><td(:?.*?)?>(.*?)</td>#si';
          $parse = 1;
       }
       elseif ($option == 'mpaa') {
          $search = "#<img.*?/mpaa/(.*?).gif#si";
       }
       elseif ($option == 'imdb') {
          $search = "#>IMDB: (.*?)</div>#si";
       }
       elseif ($option == 'descr') {
          $search = "#_reachbanner_\">(.*?)</#si";
       }
       elseif ($option == 'kinopoisk') {
          $search = "#repeat-x; font-weight: normal !important; text-decoration: none\">(.*?)<span style=\"font:100#si";
       }
       elseif ($option == 'kinopoisktotal') {
          $search = "#<span style=\"font:100 14px tahoma, verdana\">&nbsp;&nbsp;(.*?)</span>#si";
       }
       elseif ($option == 'actors') {
          $search = '#� ������� �����:(.*?)<tr><td><br><br><br></td></tr>#si';
       }
	elseif ($option == 'actors1') {
          $search = '#� ������� �����:(.*?)</table>#si';
       }
       elseif ($option == 'poster') {
          $search = '#align=left><img src="/images/film/(.*?)" width="120" height="170"#si';
       }
       elseif ($option == 'dublers') {
          $search = '#���� �����������(.*?)</table>#si';
       }
       elseif ($option == 'genre') {
          $search = "#����</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
   	elseif ($option == 'user') {
          $search = '#<span class="login"><a href="/level/78/">��� ���������</a><b>&bull;</b><a href="/level/(.*?)/user/(.*?)/">(.*?)</a></span>#si';
          $parse = 1;
       }

       $result = false;
       $parse = false;

       if (!$parse) {$parse = 0;}
       while (preg_match_all ($search, $text, $matches)) {
          foreach ($matches as $tempresult)
          $result = $tempresult[$parse];
          $result = str_replace('...', '', $result);
          if ($parse == 1) {
             $result = preg_replace("#<a href=\"(.*?)>(.*?)</a>#is", "\\2", $result);
          }
       return $result;
       }
    }
    function getbigposter($text){
          $search = '#\" src=\'(.*?)\' #';
          preg_match_all ($search, $text, $matches,PREG_SET_ORDER);
          foreach($matches as $tempresult){
          $result=$tempresult[1];
          //echo $result;
          }
          return $result;
      }

    //������� ��������� � ���������� ����-�������� �� �������
    function getimglist($text){
         $search='#<a.*href="/picture/(.*?)/"><img.*src="/images/poster/(.*?)\" width=#';
          $i=0;
          echo '<tr><td align=center>
          �������� �� ����������� ����� ��� �������� ��������������� ������� �� ������
          <br>
          <table width=360><tr>';
          //echo $text;
    			preg_match_all ($search, $text, $matches,PREG_SET_ORDER);
          foreach ($matches as $tempresult){
          $result1=$tempresult[1];
          $result=$tempresult[2];
          //�������� �������� � ���������
           $link="http://www.kinopoisk.ru/images/poster/".$result;
           $res=little_poster($link, $result);
           if( $i%5==0 && $i>1 )  echo "</tr><tr>" ;
           echo '<td>';
           echo "<a href='kinopoisk.php?pictureid=".$result1."'><img src='temp/".$res."' width=120 height=177 style='border:5px solid #ccc' vspace=3 alt='�������� �������'></a>";
           echo '</td>';
          $i++;
          }
       echo "</tr></table></td></tr>";
}
?>


<html>
<head>
<title><?php echo $ul['53']; ?></title>
<meta http-equiv=content-type content="text/html; charset=windows-1251">
</head>
<TABLE align=center border="0" cellspacing="1" cellpadding="3"<TBODY><TR><TD align="center" style="border-right-color: #FFFFFF"><A href="http://www.kinopoisk.ru/"><IMG src="imdb/kp_logo.gif" alt="www.kinopoisk.ru"></A></TD></TR></TBODY></TABLE>
<table class=table_kat_element  align=center cellSpacing=0 cellPadding=0 border=0 width=100%>
<TR class=f10 height=16>
<td align=center width=100%>
<?php echo $ul['53']?>
</td>
</tr>
<TR class=f10>
<td align=center>
<table class=table_int_table align=center cellSpacing=0 cellPadding=0 border=0 width=100% height=100%>


<?php

if ((!isset($_GET['id']) && !isset($_GET['filmid']) && !isset($_GET['pictureid'])) && (!isset($_GET['filmname']) || $_GET['filmname']=='' )){
print "<tr><td align=center>".$ul['54'].":</td></tr><tr><td align=center><form method='get'><input  class=input2 type='text' name='filmname' size='40'> <input type='submit' value='".$ul['55']."' /> </form></td></tr>";
windowsize (250,400);
}
    include "Snoopy.class.php";
    $page = new Snoopy;


if (isset($_GET['filmname']) && $_GET['filmname']!='' ) {
windowsize (400,600);
  $film = RawUrlEncode($_GET['filmname']);
  $filmsafe = htmlspecialchars($_GET['filmname']);
$page->fetch("http://www.kinopoisk.ru/index.php?kp_query={$film}&x=0&y=0");
$source = $page->results;
if (!$source) die('Nothing found!');

   print("<tr><td align=\"center\"><b>".$ul[56].": \"$filmsafe\" $ul[57]</b></td></tr>");

  $searched = search($source,$film);
  foreach ($searched as $searchedrow) {
    print("<tr><td>".$searchedrow."</td></tr>");
  }
}
elseif (isset($_GET['id']) && $_GET['id'] != '') {
windowsize (600,800);
  if (!is_numeric($_GET['id'])) die('Wrong ID');
  $id = $_GET['id'];

  $page->fetch("http://www.kinopoisk.ru/level/1/film/$id/");
$source = $page->results;

if (!$source) die('Nothing found!');

function clear($text){
  $text = preg_replace("#\t|\r|\x0B|\n#si","",$text);
 // $text = preg_replace("#\n(.*?)\n#si","\n",$text);
  $text = preg_replace("#\&\#133;|\&\#151;#si","",strip_tags(trim(html_entity_decode($text,ENT_QUOTES))));
  return $text;
}

       function format_actors($text){
          preg_match_all("#<a.*?>(.*?)</a>#si", $text, $actors);
          $actor_string='';
          $stop = count($actors[1]) - 1;
          for ($i = 0; $i < $stop; $i++) {
             $actor_string .= ( ( $actor_string != '' ) ? ', ' : '' ) . $actors[1][$i];
          }
          return $actor_string;
       }

       function format_dublers($text){
          preg_match_all("#<a.*?>(.*?)</a>#si", $text, $dublers);
          $dubler_string='';
          $stop = count($dublers[1]);
          for ($i = 0; $i < $stop; $i++) {
             $dubler_string .= ( ( $dubler_string != '' ) ? ', ' : '' ) . $dublers[1][$i];
          }
          return $dubler_string;
       }



$rusname = clear(get_content($source, 'rusname'));
$origname = clear(get_content($source, 'origname'));
$country = clear(get_content($source, 'country'));
$year = clear(get_content($source, 'year'));
$director = clear(get_content($source, 'director'));
$genre = mb_convert_case(clear(get_content($source, 'genre')), MB_CASE_TITLE, $mysql_charset);
$genre = clear(get_content($source, 'genre'));
//����� ����� ��������� � ���� ������������.
$genres=explode(', ',$genre);
$max=sizeof($genres) ;
$gen0=0;
$gen1=0;
$gen2=0;
$gen3=0;
$gen4=0;
$ii=0;
if($max>5) $max=5;
openconn1();
for ($i=0;$i<$max;$i++) {
	//������ �������������� ������
	//print $genres[$i].'<br>';
	$sql='select code from tbl_subkat where katcode=1 and nazv="'.trim($genres[$i]).'"';
	$rs3_2 = mysql_query($sql,$conn1);
	$rs3=mysql_fetch_assoc($rs3_2);
	if ($rs3['code']>0){
		//print $rs3['code'].'<br>';
		$cmd="\$gen".$ii."=".$rs3['code'].";";
		//print $cmd;
		eval($cmd);
		$ii++;
	}
	//print ($gen.$i);
	//print ("</br>");
}
$scenario = clear(get_content($source, 'scenario'));
$producer = clear(get_content($source, 'producer'));
$operator = clear(get_content($source, 'operator'));
$budget = clear(get_content($source, 'budget'));
$premieraworld = clear(get_content($source, 'premieraworld'));
$premierarf = clear(get_content($source, 'premierarf'));
$mpaarating = clear(get_content($source, 'mpaa'));
$mpaapic = $mpaarating;
$moneyworld=clear(get_content($source, 'manyworld'));
$imdbrating = clear(get_content($source, 'imdb'));
$time = clear(get_content($source, 'time'));
$descr =clear(get_content($source, 'descr')).'<br><br><br><a href=http://kinopoisk.ru target=_blank>����� � kinopoisk.ru</a>';
if (get_content($source, 'dublers')==''){
$actors = format_actors(get_content($source, 'actors1'));
}
else
{
$actors = format_actors(get_content($source, 'actors'));
}
$kinopoiskrating ="[url=http://www.kinopoisk.ru/level/1/film/$id/][img]http://www.kinopoisk.ru/rating/$id.gif[/img][/url]";
$kinopoiskratinglink ="http://www.kinopoisk.ru/level/1/film/$id/";
$kinopoisk=clear(get_content($source, 'kinopoisk'));
$URLposter="http://www.kinopoisk.ru/images/film/$id".".jpg";
$user=clear(get_content($source, 'user'));
//$poster = get_poster($id);
switch ($mpaarating){
  case "G": $mpaarating = "G - $ul[58]"; break;
    case "PG": $mpaarating ="PG - $ul[59]"; break;
      case "PG-13": $mpaarating = "PG-13 - $ul[60]"; break;
        case "R": $mpaarating = "R - $ul[61]"; break;
  case "NC-17": $mpaarating = "NC-17 - $ul[62]"; break;
}
$slash=" / ";
print ('<script type="text/javascript" language="javascript">
function fillform(isposter){
window.opener.document.frmlogin.elements["nazv"].value = "'.$rusname.$slash.$origname.'";
//window.opener.document.frmlogin.elements["original_name"].value = "'.$origname.'";
window.opener.document.frmlogin.elements["release"].value = "'.$year.'";
window.opener.document.frmlogin.elements["dopf1"].value = "'.$director.'";
window.opener.document.frmlogin.elements["dopf4"].value = "'.$actors.'";
window.opener.document.frmlogin.elements["country"].value = "'.$country.'";
//window.opener.document.frmlogin.elements["playtime"].value = "'.$time.'";
window.opener.document.frmlogin.elements["dopf3"].value = "'.$producer.'";
window.opener.document.frmlogin.elements["dopf2"].value = "'.$scenario.'";
// window.opener.document.frmlogin.elements["budjet"].value = "'.$budget.'";
//window.opener.document.frmlogin.elements["premier"].value = "'.$premieraworld.'";
// window.opener.document.frmlogin.elements["genre"].value = "'.$genre.'";
//  window.opener.document.frmlogin.elements["mpparating"].value = "'.$mpaarating.'";
window.opener.document.frmlogin.elements["imdb"].value =  "'.$kinopoiskratinglink .'";
window.opener.document.frmlogin.elements["url_poster"].value="'.$URLposter.'";
window.opener.document.frmlogin.elements["dopf5"].value = "'.$kinopoisk.'";
window.opener.document.frmlogin.elements["subkat1"].value="'.$gen0.'";
window.opener.document.frmlogin.elements["subkat2"].value="'.$gen1.'";
window.opener.document.frmlogin.elements["subkat3"].value="'.$gen2.'";
window.opener.document.frmlogin.elements["subkat4"].value="'.$gen3.'";
window.opener.document.frmlogin.elements["subkat5"].value="'.$gen4.'";
if (window.opener.document.frmlogin.elements["hider"].value=="'.$ul[17].'") {
window.opener.document.frmlogin.elements["opis"].value = "[b]'.$ul[24].': [/b] \n[b]'.$ul[25].': [/b] \n[b]'.$ul[26].': [/b] \n[b]'.$ul[63].': [/b]'.$genre.'\n[b]'.$ul[28].': [/b] \n[b]'.$ul[64].': [/b]'.$premieraworld.' \n[b]'.$ul[65].': [/b]'.$premierarf.' \n[b]'.$ul[67].': [/b]'.$mpaarating.' \n[b]'.$ul[27].': [/b]'.$time.' \n\n\n[b]'.$ul[30].': [/b]\n'.$descr.'";
}else{
window.opener.tinyMCE.get("tinyarea").setContent( "</br><strong>'.$ul[24].': </strong></br><strong>'.$ul[25].': </strong></br><strong>'.$ul[26].': </strong></br><strong>'.$ul[63].': </strong>'.$genre.' </br><strong>'.$ul[28].': </strong></br><strong>'.$ul[64].': </strong>'.$premieraworld.' </br><strong>'.$ul[65].': </strong>'.$premierarf.' <br><strong>'.$ul[67].': </strong>'.$mpaarating.' <br><strong>'.$ul[27].': </strong>'.$time.' <br><br><br><strong>'.$ul[30].': </strong><br>'.$descr.'");
}
if (isposter==0)  {
window.close();
}else{
self.location.href="kinopoisk.php?filmid='.$id.'";
}
  }
</script>');
print ("<TR><td>");
print ("<table width=\"100%\" >
<tr><td width=\"15%\">".$ul[68].":</td><td width=\"84%\">$rusname</td></tr>
<tr><td width=\"15%\">".$ul['69'].":</td><td width=\"84%\">$origname</td></tr>
<tr><td width=\"15%\">".$ul['70'].":</td><td width=\"84%\">$actors</td></tr>
<tr><td width=\"15%\">".$ul['71'].":</td><td width=\"84%\">$country</td></tr>
<tr><td width=\"15%\">".$ul['72'].":</td><td width=\"84%\">$year</td></tr>
<tr><td width=\"15%\">".$ul['73'].":</td><td width=\"84%\">$director</td></tr>
<tr><td width=\"15%\">".$ul['74'].":</td><td width=\"84%\">$producer</td></tr>
<tr><td width=\"15%\">".$ul['75'].":</td><td width=\"84%\">$descr</td></tr>");
print ('<tr>
<td align="center" colspan="2">
<input type="button"  value="'.$ul['76'].'" onclick="javascript:window.close()">&nbsp;
<input type="button"  value="'.$ul['77'].'" onclick="javascript:fillform(0);">
<input type="button"  value="'.$ul['78'].'" onclick="javascript:fillform(1);">
</td></tr>
</td>
</tr>
');

?>
<tr>
<td align="center" colspan="2">
<input type="button" value="<?php echo $ul['79'] ?>" OnClick='self.location.href="kinopoisk.php"'>
</td>
</tr>

<?php
}elseif(isset($_GET['filmid']) && $_GET['filmid']!=''){
$id=$_GET['filmid'];
//��� �� ���� ������� ��������
//windowsize (600,800);
$page->fetch("http://www.kinopoisk.ru/level/17/film/$id/");
$source = $page->results;
if (!$source) die('Nothing found!');
//������ �� ������ ������� ��������
getimglist($source) ;
}elseif(isset($_GET['pictureid']) && $_GET['pictureid']!=''){
//��� � ��� ���� ��������� ������, �������� �������� ������ �� ����
$poster=$_GET['pictureid'];
$page->fetch("http://www.kinopoisk.ru/picture/$poster/");
$source = $page->results;
if (!$source) die('Nothing found!');
//������ �� ������ ������� ����� �� ������
$link=getbigposter($source);
windowsize (300,600);
if ($link!=''){
echo "<tr><td align=center>";
echo "<a href='".$link."'>".$link."</a>";
echo "</td></tr>";
echo '<tr><td align=center>
<input type="button"  value="'.$ul['76'].'" onclick="javascript:window.close()">&nbsp;
<input type="button"  value="'.$ul['80'].'" onclick="javascript:fillposter();">
<script type="text/javascript" language="javascript">
function fillposter(){
window.opener.document.frmlogin.elements["url_poster"].value="'.$link.'";
window.close();
}
</script>
';
}else{
echo "<tr><td align=center>";
echo $ul['81'];
echo "</td></tr>";
}

}
?>

</td>
</tr>
</table>
</table>
<?php
//if ($user!="") print "user: ".$user
?>
</html>