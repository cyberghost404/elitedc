<?php


if (isset($address)){
  $mydir='module/atlant_is/';
  $txcode = preg_replace("#(.*)\/(.*)\.png#i", "$2", $address);
}else{
  $txcode = preg_replace("#(.*)\/(.*)\.png#i", "$2", $_SERVER['REQUEST_URI']);
  $mydir=getcwd();
  chdir("..");
  chdir("..");
}
$txcode = trim(substr(trim($txcode), 0, 10));
if (! is_numeric($txcode)) { die("Invalid user_id or hacking attempt."); }


//���������� ������, ��� ����������� ������� �� funclist.php ������-�� ������ �����. �� ������ (Atlant_is)
require_once(getcwd().'/main/config/config.php');
function openconn1 ()
	{
	global $zsqlserver, $zsqluser, $zsqlpass,$zsqldb,$conn1;
	$conn1 = mysql_connect($zsqlserver,$zsqluser,$zsqlpass);
	$rs=mysql_query("set names cp1251",$conn1);
	mysql_select_db($zsqldb ,$conn1) or die('MAGNETO - error connect to conn1: '.mysql_error());
	return;
	}

openconn1();

global $txcode, $tx, $font, $fontsize, $cx, $cy, $img1;


$rs_2=mysql_query("select RATINGS, DOWNHIM, ALTLINKS, LINKS, DOWNUS, VOTES from tbl_user where CODE=".$txcode,$conn1);
$rs=mysql_fetch_array($rs_2);
mysql_free_result($rs_2);
chdir($mydir);
$im = imagecreatefrompng("ub/ub.png"); //png picture
$font = 'ub/ub.ttf'; //font file

$color_bl = imagecolorallocate($im, 0, 0, 0);
$color_w = imagecolorallocate($im, 255, 255, 255);
$color_r = imagecolorallocate($im, 255, 0, 0);
$color_g = imagecolorallocate($im, 0, 255, 0);
$color_b = imagecolorallocate($im, 0, 0, 255);
$color_gr = imagecolorallocate($im, 110, 110, 110);

// ������� ������� ������, �� ����
$fontsize = 12; //font size
$cx=4;	//��������� X
$cy=14;
$tx = "Magnetida";
$len=strlen($tx);
$color=$color_gr;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$cx=0;
$tx = $rs['RATINGS']; if ($tx=='' || $tx==0) $tx=0;
$color=$color_gr;
$cx=350-(sized($fontsize,$cx,$tx, $font))-4;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);

// ������, ������
$fontsize = 8; //font size
$cx=$len*10;
$ctx=$cx;
$cy=13;
$tx = "U:";
$color=$color_g;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$tx = $rs['LINKS']; if ($tx=='' || $tx==0) $tx=0;
$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

//$tx = "/ P:";
//$color=$color_g;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = recordcount_new("tbl_persona where ISMODER=1 and ISDOPEDIT=0 and WHOADD=".$txcode); if ($tx=='' || $tx==0) $tx=0;
//$color=$color_w;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

$tx = "+";
$color=$color_g;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$tx = $rs['ALTLINKS'];  if ($tx=='' || $tx==0) $tx=0;
$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);

//$tx = " PPL:";
//$color=$color_g;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = $rs['DOWNUS']; if ($tx=='' || $tx==0) $tx=0;
//$color=$color_w;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = " VTS:";
//$color=$color_g;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = $rs['VOTES']; if ($tx=='' || $tx==0) $tx=0;
//$color=$color_w;
//imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);


// �������
$cx=$ctx+92;
//$cy+=8;
$tx = "D:";
$color=$color_r;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
$tx = $rs['DOWNHIM']; if ($tx=='' || $tx==0) $tx=0;
$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);


$cx=$ctx+142;
$tx = "RATIO:";
$color=$color_gr;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);
//$tx = $rs['LINKS'] / $rs['DOWNHIM'];
$tx = number_format( ( $rs['LINKS'] + $rs['ALTLINKS'] ) / $rs['DOWNHIM'], 2, '.', '');

$color=$color_w;
imagettftextoutline($im,$fontsize,0,$cx,$cy,$color,$color_bl,$font,$tx,1);$cx=sized($fontsize,$cx,$tx, $font);


header('Content-type: image/png');
imagepng($im);
imagedestroy($im);


function sized($size, $cx, $text, $fontfile)
	{
	$bbox = imagettfbbox($size, 0, $fontfile, $text); //calculate the pixel of the string
	$cx = $cx + abs($bbox[4] - $bbox[0])+2;
	return $cx;
	}
function imagettftextoutline($sig,$size,$angle,$x,$y,$col,$outlinecol,$fontfile,$text, $width){
	for($xc=$x-$width; $xc<=($x+$width); $xc++){
     	for ($yc=$y-$width; $yc<=($y+$width); $yc++){
			imagettftext($sig ,$size ,$angle,$xc ,$yc, $outlinecol ,$fontfile ,$text);
		}
	}
	imagettftext($sig,$size,$angle,$x,$y,$col,$fontfile,$text);
}



?>