<TR class=f10 height=16>
	<td>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
			<TR class=f10 height=16>
				<td width=25 align=center>
					<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon_search.png" width=16 height=16>
				</TD>
				<td><font color="<?php echo $zcmas[50]?>">
					<b><?php echo $zl['66']?></b>
				</font></TD>
			</TR>
		</TABLE>
	</TD>
</TR>