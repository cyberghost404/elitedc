<?php
    //������ �������� ��������� ������ � bash.org.ru
    require_once ('./module/'.$zmodule.'/snoopy.class.php');
   $page = new Snoopy;
   $page->read_timeout=10;
   $page->host="www.bash.org.ru";
   $page->fetch("http://www.bash.org.ru/random");
$source = $page->results;
if($source!=''){
 echo getquote($source);
} else{
echo 'There are some problems...';
}

    function getquote($text){
          $search = '#<div>(.*?)</div>#';
          preg_match_all ($search, $text, $matches,PREG_SET_ORDER);
          foreach($matches as $tempresult){
          $result=$matches[0][0];
          return $result;
          }

      }
?>