<?php
/*
Project: Kinokpk.com releaser
This file is part of Kinokpk.com releaser.
Kinokpk.com releaser is based on TBDev,
originally by RedBeard of TorrentBits, extensively modified by
Gartenzwerg and Yuna Scatari.
Kinokpk.com releaser is free software;
you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
Kinokpk.com is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with Kinokpk.com releaser; if not, write to the
Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,
MA  02111-1307  USA
Do not remove above lines!
*/
$mydir=getcwd();
chdir("..");
chdir("..");
require_once(getcwd().'/main/config/functlist.php' );
chdir($mydir);
require_once('inc_style.php' );
//global $ps_menukat;
iswork();
//verifyuser();
function search($source,$text)
{
$result = false;
$searchfilms = "#<a class=\"all\" href=\"/level/4/people/(.*?)a>#si";
$searchfilms2 = "#<font color=\"\#999999\">(.*?)</font>#si";
  while (preg_match_all ($searchfilms, $source, $matches))
  {
    preg_match_all($searchfilms2, $source, $matches2);
    foreach ($matches as $key => $temparray)
    foreach ($temparray as $key2 => $tempresult){
    $result[$key2] = $tempresult;
    $result[$key2] = preg_replace("#(.*?)/sr/1/\">(.*?)</#is", "<a href=\"?id=\\1\">\\2</a>", $result[$key2])."   ".$matches2[$key][$key2];
    }
 return $result;
  }
}
    function get_content($text, $option)
    {
       global $id;
       if ($option == 'rusname') {
          $search = "#<meta name=\"keywords\" content=\"(.*?)\(#si";
       }
       elseif ($option == 'origname') {
          $search = "#<meta name=\"keywords\" content=\".*?\((.*?)\)#si";
       }
       elseif ($option == 'career') {
          $search = "#�������</td><td(:?.*?)?>(.*?)</td>#si";
		   $parse = 1;
       }
       elseif ($option == 'growth') {
          $search = "#����</td><td(:?.*?)?>(.*?)</td>#si";
		   $parse = 1;
       }
	   elseif ($option == 'genre') {
          $search = "#�����</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
	   elseif ($option == 'year') {
          $search = "#���� ��������</td><td(:?.*?)?>(.*?)&bull;#si";
          $parse = 1;
       }
	   elseif ($option == 'birthplace') {
          $search = "#����� ��������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
	   elseif ($option == 'films') {
          $search = "#����� �������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
	   elseif ($option == 'family') {
          $search = "#�������</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
	   elseif ($option == 'film_one') {
          $search = "#������ �����</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
	   elseif ($option == 'film_last') {
          $search = "#��������� �����</td><td(:?.*?)?>(.*?)</td>#si";
          $parse = 1;
       }
	   elseif ($option == 'best') {
          $search = '#������ ������:(.*?)</table>#si';
       }
	   elseif ($option == 'about') {
          $search = '#<ul class="trivia">(.*?)</ul>#si';
       }
	   elseif ($option == 'allfilms') {
         $search = '#��� �������(.*?)<script type="text/javascript">#si';
       }
       $result = false;
       $parse = false;
       if (!$parse) {$parse = 0;}
       while (preg_match_all ($search, $text, $matches)) {
          foreach ($matches as $tempresult)
          $result = $tempresult[$parse];
          $result = str_replace(', ...', '', $result);
          //$result = str_replace('"', "", $result);
          //$result = str_replace("'", "", $result);
          if ($parse == 1) {
             $result = preg_replace("#<a href=\"(.*?)>(.*?)</a>#is", "\\2", $result);
          }
       return $result;
       }
    }
?>
<html>
<head>
<title><?php echo $ul['53']?></title>
<meta http-equiv=content-type content="text/html; charset=windows-1251">
</head>
<TABLE align=center border="0" cellspacing="1" cellpadding="3"<TBODY><TR><TD align="center" style="border-right-color: #FFFFFF"><A href="http://www.kinopoisk.ru/"><IMG src="imdb/kp_logo.gif" alt="www.kinopoisk.ru"></A></TD></TR></TBODY></TABLE>
<table class=table_kat_element  align=center cellSpacing=0 cellPadding=0 border=0 width=100%>
<TR class=f10 height=16>
<td align=center width=100%>
<?php echo $ul['53']?>
</td>
</tr>
<TR class=f10>
<td>
<table class=table_int_table align=center cellSpacing=0 cellPadding=0 border=0 width=100% height=100%>
<?php
if (!isset($_GET['id']) && (!isset($_GET['filmname']) || $_GET['filmname']=='' )){
print "<tr><td align=center>".$ul['82'].":</td></tr><tr><td align=center><form method='get'><input  class=input2 type='text' name='filmname' size='40'> <input type='submit' value='����������' /> </form></td></tr>";
windowsize (250,400);
}
    include "Snoopy.class.php";
    $page = new Snoopy;
if (isset($_GET['filmname']) && $_GET['filmname']!='' ) {
windowsize (400,600);
  $film = RawUrlEncode($_GET['filmname']);
  $filmsafe = htmlspecialchars($_GET['filmname']);
$page->fetch("http://www.kinopoisk.ru/index.php?kp_query={$film}&x=0&y=0");
$source = $page->results;
if (!$source) die('Nothing found!');
   print("<tr><td align=\"center\"><b>".$ul['56']." \"$filmsafe\"</b></td></tr>");
  $searched = search($source,$film);
  foreach ($searched as $searchedrow) {
    print("<tr><td>".$searchedrow."</td></tr>");
  }
}
elseif (isset($_GET['id']) && $_GET['id'] != '') {
windowsize (600,800);
  if (!is_numeric($_GET['id'])) die('Wrong ID');
  $id = $_GET['id'];
  $page->fetch("http://www.kinopoisk.ru/level/4/people/$id/view_info/ok/#trivia");
$source = $page->results;
if (!$source) die('Nothing found!');
function clear($text){
  $text = preg_replace("#\t|\r|\x0B|\n#si","",$text);
 // $text = preg_replace("#\n(.*?)\n#si","\n",$text);
  $text = preg_replace("#\&\#133;|\&\#151;#si","",strip_tags(trim(html_entity_decode($text,ENT_QUOTES))));
  return $text;
}
 function format_best($text){
          preg_match_all("#<a.*?>(.*?)</a>#si", $text, $best);
          $best_string='';
          $stop = count($best[1]);
          for ($i = 0; $i < $stop; $i++) {
             $best_string .= ( ( $best_string != '' ) ? ', ' : '' ) . $best[1][$i];
          }
		  return $best_string;
          }
function format_about($text){
$text = preg_replace("#&\#151;#si","&mdash;",$text);
$text = preg_replace("#&nbsp;#si"," ",$text);
preg_match_all("#<li.*?>(.*?)</li>#si", $text, $about);
$about_string='';
          $stop = count($about[1]);
          for ($i = 0; $i < $stop; $i++) {
             $about_string .= ( ( $about_string != '&bull; ' ) ? ' \n&bull; ' : '' ) . $about[1][$i];
          }
return $about_string;
  }
function format_allfilms($text){
$text = preg_replace("#&nbsp;#si"," ",$text);
preg_match_all("#<a class=\"all\".*?>(.*?)</a>.*?<span style=\"color:\#999\">(.*?)</span>#si", $text, $allfilms);
$allfilms_string='';
          $stop = count($allfilms[1]);
          for ($i = 0; $i < $stop; $i++) {
             $allfilms_string .= ( ( $allfilms_string != '\n' ) ? '\n'.$allfilms[2][$i].'...' : '' ) . $allfilms[1][$i];
          }
		  return $allfilms_string;
          }

$career = clear(get_content($source, 'career'));
$growth = clear(get_content($source, 'growth'));
$rusname = clear(get_content($source, 'rusname'));
$origname = clear(get_content($source, 'origname'));
$genre = mb_convert_case(clear(get_content($source, 'genre')), MB_CASE_TITLE, $mysql_charset);
$genre = clear(get_content($source, 'genre'));
$year = clear(get_content($source, 'year'));
$birthplace = mb_convert_case(clear(get_content($source, 'birthplace')), MB_CASE_TITLE, $mysql_charset);
$birthplace = clear(get_content($source, 'birthplace'));
$films = clear(get_content($source, 'films'));
$family = clear(get_content($source, 'family'));
$film_one = clear(get_content($source, 'film_one'));
$film_last = clear(get_content($source, 'film_last'));
$allfilms = str_replace('"','',substr(format_allfilms(get_content($source, 'allfilms')), 0));
$best = substr(format_best(get_content($source, 'best')), 0);
$about = substr(format_about(get_content($source, 'about')), 0);
$URLposter="http://www.kinopoisk.ru/images/actor/$id".".jpg";
$slash=" / ";
print ('<script type="text/javascript" language="javascript">
function fillform(){
window.opener.document.frmlogin.elements["nazv"].value = "'.$rusname.'";
window.opener.document.frmlogin.elements["nazvrod"].value = "'.$origname.'";
window.opener.document.frmlogin.elements["url_poster"].value = "'.$URLposter.'";');
$ps_istiny=getconf("ISTINY_TOPIC","VALUEINT");
print ('window.opener.document.frmlogin.elements["opis"].value = "'.$rusname.$slash.$origname.'\n'.$ul['83'].': '.$growth.'\n'.$ul['84'].': '.$career.'\n'.$ul['85'].': '.$year.'\n'.$ul['86'].': '.$birthplace.'\n'.$ul['87'].': '.$genre.'\n'.$ul['88'].': '.$films.'\n'.$ul['89'].': '.$family.'\n'.$ul['90'].': '.$film_one.' �.\n'.$ul['91'].': '.$film_last.' �.\n'.$ul['92'].': '.$best.'\n\n\n'.$ul['93'].': '.$about.'\n\n\n'.$ul['94'].': '.$allfilms.'\n\n\n\n ����� � kinopoisk.ru";');
print ('window.close();
  }
</script>');
print ("<TR><td>");
print ("<table width=\"100%\" >
<tr><td width=\"20%\">".$ul['95'].":</td><td width=\"80%\">$rusname</td></tr>
<tr><td width=\"20%\">".$ul['96'].":</td><td width=\"80%\">$origname</td></tr>
<tr><td width=\"20%\">".$ul['84'].":</td><td width=\"80%\">$career</td></tr>
<tr><td width=\"20\">".$ul['85'].":</td><td width=\"80%\">$year</td></tr>
<tr><td width=\"20%\">".$ul['88'].":</td><td width=\"80%\">$films</td></tr>
<tr><td width=\"20%\">".$ul['92'].":</td><td width=\"80%\">$best</td></tr>
<tr><td width=\"20%\">".$ul['93'].":</td><td width=\"80%\">$about</td></tr>
<tr><td width=\"20%\">".$ul['94'].":</td><td width=\"80%\">$allfilms</td></tr>");
print ('<tr>
<td align="center" colspan="2">
<input type="button"  value="'.$ul['76'].'" onclick="javascript:window.close()">&nbsp;
<input type="button"  value="'.$ul['77'].'" onclick="javascript:fillform();">
</td></tr>
</td>
</tr>
');
}
?>
<tr>
<td align="center" colspan="2">
<input type="button" value="<?php echo $ul['79'] ?>" OnClick='self.location.href="kinopoisk_people.php"'>
</td>
</tr>
</td>
</tr>
</table>
</table>
</html>