<?php
$zmodule_name='Atlantida';
$zmodule_avtor='Atlant_is';
$zmodule_ver='1.0';
$zmodule_date='01.01.2010';
$zmodule_url='http://atlantida.homenet/magneto/';
$zmodule_info='��� by Atlant_is ������� Magneto v 2.0';
?>