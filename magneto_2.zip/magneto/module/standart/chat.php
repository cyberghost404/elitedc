<?php
global $ps_menukat;
openconn1();

verifyuser();
if (getconf("ISCHAT","VALUEINT")!=1){
	header("Location: index.php");exit;	
}

//================================================================================
if ($ps_type=="addmsg"){
	dopverify2(1);
	if (maycomment($ps_usercode)==1){
		$ps1=requestdata("opis");
		if ($ps1!=''){
			$rs_s2=mysql_query("insert into tbl_chat (WHOADD,DATEADD,OPIS) values (".$ps_usercode.",'".sqldatetime2(mktime())."','".$ps1."')",$conn1);
		}
	}
	if ($ps_type2!="restore") exit;
	$ps_ref=$_SERVER['HTTP_REFERER'];
	?>
	<script type="text/javascript" language="JavaScript">
			{    
			window.parent.location="<?php echo $ps_ref?>";
			//window.history.go(-1);
			}
	</script>
	<?php
}

//================================================================================
if ($ps_type=="delmsg"){
	dopverify("DO_MODER");
	$rs_s2=mysql_query("delete from tbl_chat where CODE=".$ps_code,$conn1);
	?>
	<script type="text/javascript" language="JavaScript">
			{    
			window.history.go(-1);
			}
	</script>
	<?php
}

//================================================================================
if ($ps_type=="clearchat"){
	dopverify("DO_MODER");
	$rs_s2=mysql_query("delete from tbl_chat",$conn1);
	?>
	<script type="text/javascript" language="JavaScript">
			{    
			window.history.go(-1);
			}
	</script>
	<?php
}
?>
<HTML>
<HEAD>
	<?php site_header()?>
</HEAD>
<BODY leftMargin=0 topMargin=0>
<?php
if ($ps_type==""){
	?>
<script>
	var xmlHttp;
	function showResult(str){
		if (str.length==0){ 
			document.getElementById("magneto_chat").innerHTML="";
			document.getElementById("magneto_chat").style.border="0px";
			return;
		}
		xmlHttp=GetXmlHttpObject();
		if (xmlHttp==null){
			//alert ("������� �� ������������ HTTP-Request");
			return;
		} 
		var url="chat.php?type=2";
		//url=url+"?search="+encodeURIComponent(str);
		//url=url+"?search="+str;
		url=url+"&randoms="+Math.random();
		xmlHttp.onreadystatechange=stateChanged ;
		xmlHttp.open("GET",url,true);
		xmlHttp.send(null);
	}
	function stateChanged(){ 
		if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
			{ 
			document.getElementById("magneto_chat").innerHTML=xmlHttp.responseText;
		} 
	}

	function GetXmlHttpObject(){
		var xmlHttp=null;
		try{
			// Firefox, Opera 8.0+, Safari
			xmlHttp=new XMLHttpRequest();
		}catch (e){
			// Internet Explorer
			try{
				xmlHttp=new ActiveXObject("Microsoft.XMLHttp");
			}catch (e){
				try{
					xmlHttp=new ActiveXObject("MSXML2.XMLHttp");
				}catch (e){
					try{
						xmlHttp=new ActiveXObject("MSXML2.XMLHttp.3.0");
					}catch (e){
						try{
							xmlHttp=new ActiveXObject("MSXML2.XMLHttp.4.0");
						}catch (e){
							xmlHttp=new ActiveXObject("MSXML2.XMLHttp.5.0");
						}
					}
				}
			}
		}
		return xmlHttp;
	}
</script> 		
<script type="text/javascript">
	function chat_reload() {
		showResult(1);
		<?php
		//�������� ����� ����������
		$ps_globalchatupd=getconf("CHATUPD","VALUESTR");
		if ($ps_globalchatupd=='') $ps_globalchatupd="5";
		if ($ps_usercode>0){
			$rs_2=mysql_query("select CHATUPD from tbl_user where CODE=".$ps_usercode,$conn1);
				$rs=mysql_fetch_array($rs_2);
				$ps_userchatupd=$rs['CHATUPD'];
				if ($ps_userchatupd=='') $ps_userchatupd="10";
			mysql_free_result($rs_2);
			$ps_globalchatupd=$ps_userchatupd;
		}
		$ps_globalchatupd=$ps_globalchatupd*1000;
		?>
		setTimeout(chat_reload, <?php echo $ps_globalchatupd?>);
	}
	window.onload = function(){
		chat_reload();
	}
</script>	 
<div id="magneto_chat" align=left></div>	
	<?php
}

if ($ps_type=="2"){
	$ps1=getconf("CPINSHAT","VALUESTR");
	mysql_query("SET CHARACTER SET ".$ps1);
	?>
	<TABLE cellSpacing=3 cellPadding=0 width=100% border=0>
		<?php
		//������� ������ ���������
		$pi_msg=20;//������� ��������� � ��� ������
		$pi_last=0;
		$rs_2 = mysql_query("select * from tbl_chat order by DATEADD desc limit ".$pi_msg,$conn1);
			while (($rs=mysql_fetch_assoc($rs_2))!==false) {
				$pi_last=$rs['CODE'];
				?>
				<TR class=f7 valign=top>
					<TD>
						<?php 
						echo cdate4($rs['DATEADD']);
						?>
						<font size=2><b><a target=_parent href="user.php?type=show&code=<?php echo $rs['WHOADD']?>"><?php echo getuserlogin($rs['WHOADD']);?></a>:</b> 
						<?php
						$ps1=$rs['OPIS'];
						if (instr(1,$ps1," ")>25) $ps1=left_1($ps1,25).' '.mid($ps1,26,strlen($ps1));
						echo $ps1;
						//��������� ����� ������� ���������
						if ($zright['DO_MODER']==1){
							?>
							<a href="chat.php?type=delmsg&code=<?php echo $rs['CODE']?>"><img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=10 height=10 border=0></a>
							<?php
						}
						?>
						</font>
						<center>
						<TABLE cellSpacing=0 cellPadding=0 width=90% height=5 border=0>
							<tr height=4>
								<td>
								</td>
							</tr>
							<tr>
								<td bgcolor="<?php echo $zcmas[30]?>" width=100%>
								</td>
							</tr>
						</table>
						</center>
			    	</TD>
				</TR>
				<?php
			}
		mysql_free_result($rs_2);	
		//������� ��� ������ ������ ����
		if ($pi_last>0){
			$rs_s2=mysql_query("delete from tbl_chat where CODE<".$pi_last,$conn1);
		}
		?>
	</TABLE>
	<?php
}
?>
</body>
</html>
<?php 
mysql_close($conn1);
?>	
