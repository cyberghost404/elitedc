<?php
$ps_work=getconf("ISWORK","VALUEINT");
if ($ps_lock==1) $ps_work=0;
if ($ps_work==1){
	?>
	<table cellspacing=0 cellpadding=0 width=100% height=2 border=0 bgcolor="<?php echo $zcmas[1]?>" align=center>
		<td></td>
	</table>
	<table cellspacing=0 cellpadding=0 width=100% height=1 border=0 bgcolor="<?php echo $zcmas[30]?>" align=center>
		<td></td>
	</table>	
	<table cellspacing=0 cellpadding=0 width=100% height=2 border=0 bgcolor="<?php echo $zcmas[1]?>" align=center>
		<td></td>
	</table>
	<?php
}?>
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 valign=top>
	<tr height=100>
		<td <?php if ($ps_work==1) echo 'width=330';?> align=center class=f10 valign=middle>
			<?php
			//��������� �������� � ����������
			$rs_2=mysql_query("select OPIS from tbl_page where NAZV='�������: ��������'",$conn1);
				$rs=mysql_fetch_array($rs_2);
				echo $rs['OPIS'];
			mysql_free_result($rs_2);		
			?>			
		</td>
		<?php 
		if ($ps_work==1){
			?>
			<td>
	      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	      			<TR>
						<td valign=top align=center>
				      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat>
				      			<TR class=f10 height=16>
				      				<td>
							      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat_element height=100%>
							      			<TR class=f10 height=100%>
							      				<td width=25 align=center >
				      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
				      							</TD>
							      				<td>
													<?php
													//������ ������������
													echo '<b>'.$zl['11'].'</b>';
													?>
				      							</TD>
				      						</TR>
				      					</TABLE>
				      				</TD>
				      			</TR>
				      			<TR class=f10>
				      				<td>
				      					<TABLE cellSpacing=1 cellPadding=0 width=100% border=0>
					      					<?php
					      					$pi1=0;
											$rs_2 = mysql_query("select CODE,RATINGS,LOGIN,POSTER from tbl_user order by RATINGS DESC limit 10",$conn1);
												while (($rs=mysql_fetch_assoc($rs_2))!==false) {
													$pi1=$pi1+1;
													?>
													<tr class=f10>
														<td width=20>
															<?php echo '&nbsp;'.$pi1.'.';?>
														</td>
														<td align=center width=20>
															<?php 
															$ps_israt=1;
															echo getstar(floor($rs['RATINGS']*0.1));
															$ps_israt=0;
															?>
														</td>
														<?php
														//������� � ������ ������ �������������
														if (getconf("ISAVAINDOWN","VALUEINT")==1){
															?>
															<td width=20>
																<?php 
																$ps_pict=$rs['POSTER'];
																if ($ps_pict!=''){
																	?>
																	<img src="main/avatar/<?php echo $ps_pict?>" width=16 height=16>
																	<?php
																}
																?>
															</td>
															<?php
														}
														?>
														<td>
															<?php
															echo '<a title="'.$zl['12'].'" href="user.php?type=show&code='.$rs['CODE'].'">'.$rs['LOGIN'].'</a>';//���������� � ������������
															?>
														</td>
														<td class=f7>
															<?php
															echo '('.$rs['RATINGS'].')';
															?>
														</td>
													</tr>
													<?php
												}
											mysql_free_result($rs_2);
											?>
										</TABLE>
				      				</TD>
				      			</TR>
				      		</TABLE>
				      		<?php
				      		//������ ����������
				      		if (getconf("ISTOPMODER","VALUEINT")==1){
				      			?>
								<br>
					      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat>
					      			<TR class=f10 height=16>
					      				<td>
								      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat_element height=100%>
								      			<TR class=f10 height=100%>
								      				<td width=25 align=center >
					      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
					      							</TD>
								      				<td>
														<?php
														//������ ����������
														echo '<b>'.$zl['13'].'</b>';
														?>								    
					      							</TD>
					      						</TR>
					      					</TABLE>
					      				</TD>
					      			</TR>
					      			<TR class=f10>
					      				<td>
					      					<TABLE cellSpacing=1 cellPadding=0 width=100% border=0>
						      					<?php
						      					$pi1=0;
												$rs_2 = mysql_query("select CODE,MODERS,LOGIN,POSTER from tbl_user where STATUS>2 order by MODERS DESC limit 5",$conn1);
													while (($rs=mysql_fetch_assoc($rs_2))!==false) {
														$pi1=$pi1+1;
														?>
														<tr class=f10>
															<td width=20>
																<?php echo '&nbsp;'.$pi1.'.';?>
															</td>
															<?php
															//������� � ������ ������
															if (getconf("ISAVAINDOWN","VALUEINT")==1){
																?>
																<td width=20>
																	<?php 
																	$ps_pict=$rs['POSTER'];
																	if ($ps_pict!=''){
																		?>
																		<img src="main/avatar/<?php echo $ps_pict?>" width=16 height=16>
																		<?php
																	}
																	?>
																</td>
																<?php
															}
															?>															
															<td>
																<?php
																echo '<a title="'.$zl['12'].'" href="user.php?type=show&code='.$rs['CODE'].'">'.$rs['LOGIN'].'</a>';//���������� � ������������
																?>
															</td>
															<td class=f7>
																<?php
																$ps1=$rs['MODERS'];
																if ($ps1=='') $ps1=0;
																echo '('.$ps1.')';
																?>
															</td>
														</tr>
														<?php														
													}
												mysql_free_result($rs_2);
												?>					      			
											</table>
					      				</TD>
					      			</TR>
					      		</TABLE>
					      		<?php
					      	}
					      	?>
						</td>
						<td width=20>&nbsp;
							
						</td>
						<td valign=top>
				      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat>
				      			<TR class=f10 height=16>
				      				<td>
							      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_down_kat_element height=100%>
							      			<TR class=f10 height=100%>
							      				<td width=25 align=center>
				      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
				      							</TD>
							      				<td>
													<?php 
													//����������
													echo '<b>'.$zl['14'];
													$pd2=dateadd("d",-getconf("POPULARDAY","VALUESTR"),mktime());
													if ($ps_popular==""){
								      					$ps_constr="select tbl_base.NAZV,tbl_link.BASECODE,tbl_link.LINKOPIS,tbl_link.DOWN from tbl_link,tbl_base where tbl_link.DATEADD>'".sqldatetime2($pd2)."' and tbl_base.ISMODER=1 and tbl_link.ISMODER=1 and tbl_link.DOWN>0 and (tbl_link.BASECODE=tbl_base.CODE)  order by tbl_link.DOWN desc limit 10";
								      					echo '- '.$zl['15'];//��� �������
													}
													if ($ps_popular=="subkat"){
								      					$ps_constr="select tbl_base.NAZV,tbl_link.BASECODE,tbl_link.LINKOPIS,tbl_link.DOWN from tbl_link,tbl_base where tbl_link.DATEADD>'".sqldatetime2($pd2)."' and tbl_base.ISMODER=1 and tbl_link.ISMODER=1 and tbl_link.DOWN>0 and (tbl_link.BASECODE=tbl_base.CODE and (tbl_base.SUBKAT1=".$ps_type2." or tbl_base.SUBKAT2=".$ps_type2." or tbl_base.SUBKAT3=".$ps_type2."))  order by tbl_link.DOWN desc limit 10";
								      					echo '- '.$ps_subkatname;
													}
													if ($ps_popular=="kat"){
								      					$ps_constr="select tbl_base.NAZV,tbl_link.BASECODE,tbl_link.LINKOPIS,tbl_link.DOWN from tbl_link,tbl_base where tbl_link.DATEADD>'".sqldatetime2($pd2)."' and tbl_base.ISMODER=1 and tbl_link.ISMODER=1 and tbl_link.DOWN>0 and (tbl_link.BASECODE=tbl_base.CODE and tbl_base.KAT=".$ps_type2.")  order by tbl_link.DOWN desc limit 10";
								      					echo '- '.$ps_katname;
													}
													?>
													</b>
				      							</TD>
				      						</TR>
				      					</TABLE>
				      				</TD>
				      			</TR>
				      			<TR class=f10>
				      				<td>
				      					<?php
				      					$pi1=0;
				      					if (recordcount($ps_constr)>0){
											$rs_2 = mysql_query($ps_constr,$conn1);
												while (($rs=mysql_fetch_assoc($rs_2))!==false) {
													$pi1=$pi1+1;
													echo '&nbsp;'.$pi1.'. ';
													echo '<a title="'.$zl['16'].'" href="topic.php?type=show&code='.$rs['BASECODE'].'">'.$rs['NAZV'].'</a>';//������� �� �������
													if ($rs['LINKOPIS']!="") echo '<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font size=1>'.$rs['LINKOPIS'].'</font>';
													echo ' <font size=1>('.$rs['DOWN'].')</font>';
													echo '<br>';											
												}
											mysql_free_result($rs_2);
										}
				      					?>
				      				</TD>
				      			</TR>
				      		</TABLE>
						</td>
	      			</tr>
	      		</table>
			</td>
			<TD width=20>&nbsp;
			</TD>	      									
			<?php
		}
		?>
	</tr>
</TABLE>
<?php
//������������ ������
if ($ps_work==1){
	if (getconf("ISONLINE","VALUEINT")==1){
		?>
		<br>
		<center>
		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
			<TR class=f10>
	  			<?php
				$pd1=dateadd("n",-getconf("ONLINETIME","VALUESTR"),mktime());
				$pi1=recordcount_new("tbl_user where LASTVISIT>'".sqldatetime2($pd1)."'");  		
				?>
				<TD width=20>&nbsp;
				</TD>	      									
				<td valign=top align=center>
		      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat>
		      			<TR class=f10 height=16>
		      				<td>
					      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
					      			<TR class=f10 height=16>
					      				<td width=25 align=center>
		      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
		      							</TD>
					      				<td>
					      					<b><a class=link1 href="user.php?type2=online"><?php echo $zl['17']?></a></b>
					      					<?php
											//������������ ������
					      					if ($pi1>0) echo ' <i>('.$pi1.')</i>';
					      					?>
		      							</TD>
		      						</TR>
		      					</TABLE>
		      				</TD>
		      			</TR>
						<TR>
		      				<td class=f10>
								<TABLE cellSpacing=5 cellPadding=0 width=100% border=0>
					      			<TR class=f10 height=16>
					      				<td>
					      					<?php
					      					$pb_ischat=getconf("ISCHAT","VALUEINT");
					      					//�������������:
					      					echo '<b>'.$zl['18'].'</b>';
					      					$pi1=recordcount_new("tbl_user where STATUS>2 and LASTVISIT>'".sqldatetime2($pd1)."'");
					      					if ($pi1==0){
					      						echo ' '.$zl['19'];//������ ���
					      					}else{
					      						$pi2=0;
												$rs2_2=mysql_query("select CODE, LOGIN, ISCHAT from tbl_user where LASTVISIT>'".sqldatetime2($pd1)."' and STATUS>2",$conn1);
													while (($rs=mysql_fetch_assoc($rs2_2))!==false) {
														$pi2=$pi2+1;
														?>
														<a href="user.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $zl['12']?>"><?php echo $rs['LOGIN']?></a><?php //���������� � ������������
														if ($pb_ischat==1){
															if ($rs['ISCHAT']==1){
																//� ������������ ��� �������
																?>
																<img src="main/color/scheme/<?php echo $ps_color;?>/element_chat_on.png" width=12 height=12 border=0 title="<?php echo $zl['444']?>">
																<?php
															}
														}
														if ($pi2<>$pi1) echo ', ';
													}
												mysql_free_result($rs2_2);
											}
					      					?>
					      				</td>
					      			</tr>
					      			<TR class=f10 height=16>
					      				<td>
					      					<?php
					      					//������������:
					      					echo '<b>'.$zl['20'].'</b>';
					      					$pi1=recordcount_new("tbl_user where STATUS<3 and LASTVISIT>'".sqldatetime2($pd1)."'");
					      					if ($pi1==0){
					      						echo ' '.$zl['19'];//������ ���
					      					}else{
					      						$pi2=0;
												$rs2_2=mysql_query("select CODE, LOGIN,ISCHAT from tbl_user where LASTVISIT>'".sqldatetime2($pd1)."' and STATUS<3 order by LOGIN",$conn1);
													while (($rs=mysql_fetch_assoc($rs2_2))!==false) {
														$pi2=$pi2+1;
														?>
														<a href="user.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $zl['12']?>"><?php echo $rs['LOGIN']?></a><?php //���������� � ������������
														if ($pb_ischat==1){
															if ($rs['ISCHAT']==1){
																//� ������������ ��� �������
																?>
																<img src="main/color/scheme/<?php echo $ps_color;?>/element_chat_on.png" width=12 height=12 border=0 title="<?php echo $zl['444']?>">
																<?php
															}
														}
														if ($pi2<>$pi1) echo ', ';
													}
												mysql_free_result($rs2_2);
											}
					      					?>
					      				</td>
					      			</tr>
					      		</table>
		      				</TD>
		      			</TR>					      									
		      		</TABLE>
		      	</td>
				<TD width=20>&nbsp;
				</TD>	      									
			</TR>
			<TR class=f10 height=20>
				<td>
				</td>
			</tr>							      				
		</table>
		</center>
		<?php
	}
}
?>
<table cellspacing=0 cellpadding=0 width=100% height=2 border=0 bgcolor="<?php echo $zcmas[1]?>" align=center>
	<td></td>
</table>
<table cellspacing=0 cellpadding=0 width=100% height=1 border=0 bgcolor="<?php echo $zcmas[30]?>" align=center>
	<td></td>
</table>
<table cellspacing=5 cellpadding=0 width=100% border=0 align=center>
	<td class=f8 width=200>
		<?php
		/*
		=====================================================================================================================
		��������� ������, ������ ��� ������� ���������. ��������� ��������� ��� ���������, � ����� ������ ������������ �����.
		��������� ����� �� ���� �������.
		=====================================================================================================================
		*/
		//����������������
		//������
		?>
		<?php echo $zl['21']?>: <b><a target="_blank" href="http://www.userside.org.ua">"UserSide"</a></b><br>
		<?php
		//������ ��������� � ����������� �� �����
		$ps_diz='Drimer';
		$ps_dizlink='mailto:drimer.home@gmail.com';
		if ($ps_color=="blue"){
			$ps_diz='Drimer';
			$ps_dizlink='mailto:drimer.home@gmail.com';
		}
		if ($ps_color=="mac_os"){
			$ps_diz='CYBERON';
			$ps_dizlink='mailto:cybernetic@programist.ru';
		}
		if ($ps_color=="atlantida"){
			$ps_diz='Atlant_is';
			$ps_dizlink='mailto:atlant_is@mail.ru';
		}
		if ($ps_color=="homenet"){
			$ps_diz='Atlant_is';
			$ps_dizlink='mailto:atlant_is@mail.ru';
		}
		?>
		<?php echo $zl['22']?>: <a target="_blank" href="<?php echo $ps_dizlink?>"><b><?php echo $ps_diz?></b></a> � <b><a target="_blank" href="http://www.userside.org.ua">"UserSide"</a></b><br>
	</td>
	<td class=f8b align=center>
		<?php
		//�������
		echo $zl['23'].' "Magneto" v.'.$zver;
		?>
		<br>
		&copy;2008-2010 - <a target="_blank" href="http://www.userside.org.ua/magneto/">http://www.userside.org.ua/magneto/</a><br>
		<br>
	</td>
	<td class=f8 width=200>
		<b><font size=1><?php echo $zmodule_name.' v.'.$zmodule_ver.' - '.$zmodule_date;?></font><br></b>
		<?php 
		//����� ������
		echo $zl['673']?>: <b><a target="_blank" href="<?php echo $zmodule_url;?>"><?php echo $zmodule_avtor;?></a></b><br>
		<?php
		$end_time = microtime();
		$end_array = explode(" ",$end_time);
		$end_time = $end_array[1] + $end_array[0];
		$work_time = $end_time - $start_time;
		//�������� ��������������
		//�.
		?>
		<font color="<?php echo $zcmas['1']; ?>"><?php echo $zl['24']?>: <?php echo(round($work_time*10)*0.1)?> <?php echo $zl['25']?></font>
	</td>
</table>
