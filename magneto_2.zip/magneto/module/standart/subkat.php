<?php
require_once('inc_katfunct.php' );
openconn1();

verifyuser();
iswork();

//��������� ������ � ������������
if (getconf("ISPERSENABLED","VALUEINT")==0){
	if ($ps_type=="ismoderpersona" || $ps_type=="onmoderpersona" || $ps_type=="mypersona" || $ps_type=="lastpersona" || $ps_type=="setlastnewspersona"){
		header("Location: index.php");exit;	
	}
}

if ($ps_type=="addmodernote" || $ps_type=="delmodernote" || $ps_type=="ismoderpersona" || $ps_type=="ismoder" || $ps_type=="modernote" || $ps_type=="modernote2" || $ps_type=="ismoderaltlink" || $ps_type=="changealtopis" || $ps_type=="changealtopis2" || $ps_type=="changealtpos" || $ps_type=="changealtpos2" || $ps_type=="altlinkaprove" || $ps_type=="altlinkdel") dopverify("DO_MODER");
if ($ps_type=="changealtopis" || $ps_type=="changealtpos") $ps_style="short";
if ($ps_type=="onmoder" || $ps_type=="mylink") dopverify("DO_ADD");
if ($ps_type=="onmoderpersona" || $ps_type=="mypersona") dopverify("DO_PERS");
if ($ps_type=="lastnews" || $ps_type=="lastposter" || $ps_type=="lastpersona" || $ps_type=="setlastnews" || $ps_type=="setlastnewscomment" || $ps_type=="setlastnewsposter" || $ps_type=="setlastnewspersona" || $ps_type=="lastcomment" || $ps_type=="fav" || $ps_type=="favread" || $ps_type=="favdel") dopverify2(1);

if ($ps_type=="altlinkdel"){
	if (getconf("ISADDALTLINKS","VALUEINT")==0){
		header("Location: index.php");exit;	
	}	
	$rs_2=mysql_query("select WHOADD from tbl_link where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_whoadd=$rs['WHOADD'];
	mysql_free_result($rs_2);
	//��������� �������
	$pi_rat=getconf("RAT_ALTLINKS","VALUESTR");
	$rs_s2=mysql_query("update tbl_user set ALTLINKS=(ALTLINKS-1),RATINGS=(RATINGS-".$pi_rat.") where CODE=".$ps_whoadd,$conn1);
	//������� ������
	$rs_s2=mysql_query("delete from tbl_link where CODE=".$ps_code,$conn1);
	header("Location: subkat.php?type=ismoderaltlink");
}

if ($ps_type=="altlinkaprove"){
	if (getconf("ISADDALTLINKS","VALUEINT")==0){
		header("Location: index.php");exit;	
	}	
	$rs_s2=mysql_query("update tbl_link set ISMODER=1 where CODE=".$ps_code,$conn1);
	$rs_2=mysql_query("select BASECODE from tbl_link where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_code=$rs['BASECODE'];
	mysql_free_result($rs_2);
	//����������� ������ �������
	$ps_razmer=0;
	$rs_2=mysql_query("select LINK from tbl_link where BASECODE=".$ps_code,$conn1);
		while (($rs=mysql_fetch_assoc($rs_2))!==false) {
			$ps_razmer2=0;
			$ps4=$rs['LINK'];
			if (instr(1,$ps4,"&xl=")!=0){
				$ps_razmer2=mid($ps4,instr(1,$ps4,"&xl=")+4,strlen($ps4));
			}
			if (strlen($ps_razmer2)>1){
				$ps_razmer2=left_1($ps_razmer2,instr(1,$ps_razmer2,"&")-1);
				$ps_razmer2=round($ps_razmer2/1024/1024);
			}
			$ps_razmer=$ps_razmer+$ps_razmer2;
		}
	mysql_free_result($rs_2);			
	//��������� ������ � �������
	//������, ��� ������� ���������
	$ps_constr="update tbl_base set RAZMER=".$ps_razmer.",DATEMODER='".sqldatetime2(mktime())."' where CODE=".$ps_code;
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: subkat.php?type=ismoderaltlink");
}

if ($ps_type=="changealtopis2"){
	if (getconf("ISADDALTLINKS","VALUEINT")==0){
		header("Location: index.php");exit;	
	}	
	$ps_opis=requestdata2("link_opis");
	$rs_s2=mysql_query("update tbl_link set LINKOPIS='".$ps_opis."' where ISMODER=0 and CODE=".$ps_code,$conn1);
	goback();
}

if ($ps_type=="changealtpos2"){
	$ps_opis=requestdata2("link_pos");
	if ($ps_opis=='') $ps_opis=1;
	if ($ps_opis<0) $ps_opis=1;
	if ($ps_opis>99999) $ps_opis=1;
	$rs_s2=mysql_query("update tbl_link set LINKPOS=".$ps_opis." where ISMODER=0 and CODE=".$ps_code,$conn1);
	goback();
}

//���� ����� � ���� �������� - ��������
if ($ps_type=="find"){
	$ps_minlen=getconf("MINTOSEARCH","VALUESTR");
	if ($ps_minlen=='') $ps_minlen=3;
	if (strlen($ps_search)<$ps_minlen) $ps_type="findlow";
}

if ($ps_type=="modernote"){
	//��������� � ����� - ����� ���������� ���������
	$rs_2=mysql_query("select CODE from tbl_modernote order by DATEADD desc limit 1",$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['CODE'];
	mysql_free_result($rs_2);
	setcookie("mg_modernote",$ps1, time()+86400*60);
}

//��������� � ������� �����������
//=========================================================================================
if ($ps_type=="addmodernote"){
	$ps_opis=requestdata("comment");
	$ps_constr="insert into tbl_modernote (WHOADD,DATEADD,OPIS) values (".$ps_usercode.",NOW(),'".$ps_opis."')";
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: subkat.php?type=modernote");exit;
}


//������� �� �������� ����������
//=========================================================================================
if ($ps_type=="delmodernote"){
	$ps1=0;
	$rs_2=mysql_query("select * from tbl_modernote where CODE=".$ps_code,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if (($zright['DO_MODER']==1 && isadekvat($rs2['WHOADD'])==1)|| $rs2['WHOADD']==$ps_usercode) $ps1=1;
	mysql_free_result($rs_2);
	if ($ps1!=1){
		header("Location: index.php");exit;
	}
	$rs_s2=mysql_query("delete from tbl_modernote where CODE=".$ps_code,$conn1);
	header("Location: subkat.php?type=modernote");exit;
}

//������� �� ����������
//=========================================================================================
if ($ps_type=="favdel"){
	$ps_constr="delete from tbl_fav where BASECODE=".$ps_code." and USERCODE=".$ps_usercode;
	$rs_s2=mysql_query($ps_constr,$conn1);
	header("Location: subkat.php?type=fav");exit;
}

if ($ps_type=="lastcomment") {
	if ($ps_comment==0){
		header("Location: index.php");
		exit;
	}
}
if (getconf("ISNEWS","VALUEINT")==0 && $ps_type=="shownews"){
	header("Location: index.php");exit;
}

if (getconf("ISADDALTLINKS","VALUEINT")==0 && $ps_type=="ismoderaltlink"){
	header("Location: index.php");exit;
}

if ($ps_type2!="") {
	$ps_subkatname=getsubkatname($ps_type2);
	$rs_2=mysql_query("select KATCODE from tbl_subkat where CODE=".$ps_type2,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps_kat=$rs['KATCODE'];
		$ps_katname=getkatname($rs['KATCODE']);
	mysql_free_result($rs_2);
}


if ($ps_type=="favread"){
	$rs_s2=mysql_query("update tbl_fav set DATELAST='".sqldatetime2(mktime())."' where USERCODE=".$ps_usercode,$conn1);
	header("Location: subkat.php?type=fav");exit;
}


if ($ps_type=="setlastnewspersona") {
	$pd1=mktime();
	if ($ps_type2<$pd1) $pd1=$ps_type2;
	$rs_s2=mysql_query("update tbl_user set LASTNEWSPERSONA='".sqldatetime2($ps_type2)."' where CODE=".$ps_usercode,$conn1);
	header("Location: subkat.php?type=lastpersona");
	exit;
}

if ($ps_type=="setlastnewsposter") {
	$pd1=mktime();
	if ($ps_type2<$pd1) $pd1=$ps_type2;
	$rs_s2=mysql_query("update tbl_user set LASTNEWSPOSTER='".sqldatetime2($ps_type2)."' where CODE=".$ps_usercode,$conn1);
	header("Location: subkat.php?type=lastposter");
	exit;
}

if ($ps_type=="setlastnewscomment") {
	$pd1=mktime();
	if ($ps_type2<$pd1) $pd1=$ps_type2;	
	$rs_s2=mysql_query("update tbl_user set LASTNEWSCOMMENT='".sqldatetime2($ps_type2)."' where CODE=".$ps_usercode,$conn1);
	header("Location: subkat.php?type=lastcomment");
	exit;
}

if ($ps_type=="setlastnews") {
	$pd1=mktime();
	if ($ps_type2<$pd1) $pd1=$ps_type2;	
	$rs_s2=mysql_query("update tbl_user set LASTNEWS='".sqldatetime2($ps_type2)."' where CODE=".$ps_usercode,$conn1);
	header("Location: subkat.php?type=lastnews");
	exit;
}

function showsubkat(){
	global $rs_2,$zcmas,$ps_type,$ps_israt,$pi1,$ps_color,$zl,$conn1;
	while (($rs=mysql_fetch_assoc($rs_2))!==false) {
		$pi1=$pi1+1;
		?>
		<TR class=f8>
			<TD width=40 align=center bgcolor="<?php echo $zcmas[5]?>">
				<?php echo $pi1?>.
			</TD>
			<TD width=100 align=center bgcolor="<?php echo $zcmas[5]?>">
				<?php
				$ps1=$rs['POSTER'];
				if ($ps1!=""){
					//����������� �������
					?>
					<a title="<?php echo $zl['160']?>" href="topic.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $rs['NAZV']?>">
					<?php echo smalleskiz($ps1);?>
					</a>
					<?php
				}
				//���� ��� �������������� ������� - �� ���������� �������
				if ($ps_type=="lastnews"){
					if ($rs['DATEEDIT']==$rs['DATEMODER']){
						//��� ������� ���������������
						?>
						<center>
						<img src="main/color/scheme/<?php echo $ps_color;?>/element_repeat.png" width=16 height=16 alt="<?php echo $zl['161']?>">
						</center>
						<?php
					}
				}
				//����������� �������
				?>
			</TD>
			<TD valign=top width=250 bgcolor="<?php echo $zcmas[5]?>">
				<a title="<?php echo $zl['160']?>" href="topic.php?type=show&code=<?php echo $rs['CODE']?>" alt="<?php echo $rs['NAZV']?>"><font size=3><b><?php echo $rs['NAZV'];?></b></font></a><br>
				<?php
				if ($ps_type!="showsubkat"){
					//���������
					//������� � ���������
					echo $zl['162'].': <b><a class=link1 title="'.$zl['163'].'" href="kat.php?type=showkat&type2='.$rs['KAT'].'">'.getkatname($rs['KAT']).'</a></b><br>';
				}
				//������������:
				echo $zl['109'].' <b>';
				$ps1=$rs['SUBKAT1'];
				if ($ps1>0){
					$ps2=getsubkatname($ps1);
					//������� � ������������
					?>
					<a class=link1 title="<?php echo $zl['164']?>" href="subkat.php?type=showsubkat&type2=<?php echo $ps1?>"><?php echo $ps2?></a>&nbsp;
					<?php
				}
				$ps1=$rs['SUBKAT2'];
				if ($ps1>0){
					$ps2=getsubkatname($ps1);
					//������� � ������������
					?>
					<a class=link1 title="<?php echo $zl['164']?>" href="subkat.php?type=showsubkat&type2=<?php echo $ps1?>"><?php echo $ps2?></a>&nbsp;
					<?php
				}
				$ps1=$rs['SUBKAT3'];
				if ($ps1>0){
					$ps2=getsubkatname($ps1);
					//������� � ������������
					?>
					<a class=link1 title="<?php echo $zl['164']?>" href="subkat.php?type=showsubkat&type2=<?php echo $ps1?>"><?php echo $ps2?></a>&nbsp;
					<?php
				}
				//���� ����������:
				echo '</b><br>';
				echo $zl['110'].' '.cdate($rs['DATEADD']).'<br>';
				//��� �������:
				//���������� � ������������
				echo $zl['111'].' <a title="'.$zl['12'].'" href="user.php?type=show&code='.$rs['WHOADD'].'">';
				if ($ps_type=="ismoder"){
					echo '<b><font size=3>'.getuserlogin($rs['WHOADD']).'</font></b>';
				}else{
					echo getuserlogin($rs['WHOADD']);
				}
				echo '</a> ';
				$ps_israt=1;
				echo getstar(floor(getuserratings($rs['WHOADD'])*0.1));
				$ps_israt=0;
				//������:				
				//��
				echo '<br>';
				echo $zl['113'].' '.$rs['RAZMER'].' '.$zl['114'].'<br>';
				//�������:
				echo $zl['115'].' '.$rs['VOTES'].'<br>';
				//����������� �������
				//���������...
				?>
				<br>
				<a title="<?php echo $zl['160']?>" href="topic.php?type=show&code=<?php echo $rs['CODE']?>" alt="<?php echo $rs['NAZV']?>"><b><?php echo $zl['652']?></b></a>
			</TD>
			<TD valign=top bgcolor="<?php echo $zcmas[5]?>">
				<?php
				//��������
				echo '<b><u>'.$zl['165'].':</u></b><br>';
				$ps1=$rs['OPIS'];
				$ps1=commentdo($ps1);
				$ps1=str_replace(chr(13),"<br>",$ps1);
				if (strlen($ps1)>300) $ps1=left_1($ps1,300)."...";
				echo $ps1.'<br><br>';
				if (getconf("ISPERSENABLED","VALUEINT")==1){
					//������� ����������, ���� ����
					$rs2_2 = mysql_query("select * from tbl_cross2 where SECONDCODE=".$rs['CODE'],$conn1);
						while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
							$rs3_2=mysql_query("select * from tbl_persona where CODE=".$rs2['FIRSTCODE'],$conn1);
								$rs3=mysql_fetch_array($rs3_2);
								//���� ���� ������ - ���������� ��������� ������
								$ps12=$rs3['POSTER'];
								if ($ps12!=''){
									$size = getimagesize($zserver."main/persona/".$ps12);
									$pi_w = $size[0];
									$pi_h = $size[1];					
									if ($pi_h>50){
										$pi3=$pi_h/50;
										$pi_h=50;
										$pi_w=round($pi_w/$pi3);
									}
									if ($pi_h<50){
										$pi3=50/$pi_h;
										$pi_h=50;
										$pi_w=round($pi_w*$pi3);
									}
									?>
									<a href="persona.php?type=show&code=<?php echo $rs3['CODE']?>" title="<?php echo $rs3['NAZV']?>">
									<img src="main/persona/<?php echo $ps12?>" width=<?php echo $pi_w?> height=<?php echo $pi_h?> border=0></a>
									&nbsp;&nbsp;
									<?php
								}
							mysql_free_result($rs3_2);						
						}
					mysql_free_result($rs2_2);
				}
				?>
			</TD>
		</TR>
		<?php
	}
	return;
}

//======================================================================================
function showsubkat_news(){
	global $rs_2,$zcmas,$ps_type,$ps_israt,$ps_color,$pi1;
	while (($rs=mysql_fetch_assoc($rs_2))!==false) {
		$pi1=$pi1+1;
		?>
		<TR class=f8>
			<TD width=40 align=center bgcolor="<?php echo $zcmas[5]?>">
				<?php echo $pi1?>.
			</TD>
			<TD valign=top bgcolor="<?php echo $zcmas[5]?>">
				<?php
				viewinfo_news($rs['CODE']);
				?>
			</TD>
		</TR>
		<?php
	}
	return;
}


//============================================================================================================================================
function cmp($a, $b) {
	global $pi10,$ps_desc;
	if ($ps_desc==1){
		//return ($b[$pi10] > $a[$pi10]) ? -1 : 1;
		return strcmp($b[$pi10], $a[$pi10]);
	}else{
		//return ($a[$pi10] > $b[$pi10]) ? -1 : 1;
		return strcmp($a[$pi10], $b[$pi10]);
	}
}
?>
<HTML>
<HEAD>
	<?php
	$ps1="";
	if ($ps_type=="fav") $ps1=$zl['492'];//������� ��� �����������
	if ($ps_type=="changealtpos") $ps1=$zl['466'];//�������� �������
	if ($ps_type=="changealtopis") $ps1=$zl['465'];//�������� ��������
	if ($ps_type=="ismoderaltlink") $ps1=$zl['461'];//��������� ������
	if ($ps_type=="showsubkat") $ps1=$ps_subkatname;
	if ($ps_type=="ismoderpersona") $ps1=$zl['380'];//��������� ����������
	if ($ps_type=="ismoder") $ps1=$zl['48'];//��������� ������
	if ($ps_type=="onmoder") $ps1=$zl['54'];//�� ���������
	if ($ps_type=="onmoderpersona") $ps1=$zl['54'];//�� ���������
	if ($ps_type=="onmoderedit") $ps1=$zl['166'];//��������� ������
	if ($ps_type=="onmodereditperona") $ps1=$zl['379'];//��������� ����������
	if ($ps_type=="find" || $ps_type=="findlow") $ps1=$zl['66'];//�����
	if ($ps_type=="mylink") $ps1=$zl['51'];//��� �������
	if ($ps_type=="mypersona") $ps1=$zl['376'];//��� ����������
	if ($ps_type=="lastnews") $ps1=$zl['167'];//����� �������
	if ($ps_type=="lastcomment") $ps1=$zl['168'];//����� �����������
	if ($ps_type=="lastposter") $ps1=$zl['60'];//����� ���������
	if ($ps_type=="lastpersona") $ps1=$zl['388'];//����� ����������
	if ($ps_type=="shownews") $ps1=$zl['44'];//������� �������
	if ($ps_type=="persona") $ps1=$zl['358'];//����������
	if ($ps_type=="modernote") $ps1=$zl['432'];//������� �����������
	?>
	<TITLE><?php echo $ps1;?> - <?php echo getconf("PROJECTNAME","VALUESTR")?></TITLE>
	<?php site_header()?>
</HEAD>
<script  language="JavaScript">
	function autoReload(){ 	
        document.frmadd.submit()
	}
	function autoReload1(){ 	
        document.frmadd1.submit()
	}
</script>		
<BODY leftMargin=0 topMargin=0>
<?php 
if ($ps_style=="") require_once('inc_top.php');
?>
<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
	<TR valign=top>
		<?php 
		if ($ps_style=="") require_once('inc_left.php');
		?>

		<TD class=f10>
    		<?php





    		//===========================================================================================
    		if ($ps_type=="fav"){
    			//������� ��� �����������
				us_text($zl['492']);
				echo '<br>';
				$ps_constr="tbl_fav where USERCODE=".$ps_usercode;
				$pi_count=recordcount_new($ps_constr);
				$pi_count_upd=recordcount("select tbl_fav.BASECODE from tbl_fav,tbl_base where tbl_fav.USERCODE=".$ps_usercode." and tbl_fav.BASECODE=tbl_base.CODE and tbl_fav.DATELAST<=tbl_base.DATEMODER");
				if ($pi_count>0){
					if ($pi_count_upd>0){
						//� �����������
						echo '<b>'.$zl['493'].':</b><br>';
		    			?>
						<TABLE cellSpacing=3 class=table_int_table cellPadding=0 width=700 border=0>
							<TR valign=top>
								<TD class=f10 width=100%>
									<?php
									//������� ����������
									$ps_constr2="select tbl_fav.BASECODE as f_BASECODE, tbl_base.NAZV as b_NAZV, tbl_base.CODE as b_CODE, tbl_fav.DATELAST as f_DATELAST, tbl_base.DATEMODER as b_DATEMODER from tbl_fav,tbl_base where tbl_fav.USERCODE=".$ps_usercode." and tbl_fav.BASECODE=tbl_base.CODE and tbl_fav.DATELAST<=tbl_base.DATEMODER order by tbl_base.NAZV";
									$pi1=0;
									$rs_2 = mysql_query($ps_constr2,$conn1);
										while (($rs=mysql_fetch_assoc($rs_2))!==false) {
											$pi1=$pi1+1;
											?>
											<TABLE cellSpacing=0 cellPadding=0 border=0 width=100%>
												<TR>
													<TD width=100%>
														<TABLE cellSpacing=1 cellPadding=3 border=0 width=100%>
															<TR class=f8 valign=top height=20>
																<TD width=40 align=center bgcolor="<?php echo $zcmas[5]?>">
																	<?php echo $pi1;?>.
																</TD>
																<TD bgcolor="<?php echo $zcmas[5]?>">
																	<?php
																	//������� �� �������
																	?>
																	<a href="topic.php?type=show&code=<?php echo $rs['b_CODE']?>" title="<?php echo $zl['16']?>"><?php echo $rs['b_NAZV']?></a>
																</TD>
																<TD bgcolor="<?php echo $zcmas[5]?>" width=120 align=center>
																	<?php
																	echo cdate($rs['b_DATEMODER']);
																	?>
																</TD>
															</TR>
														</TABLE>
													</TD>
												</TR>
											</TABLE>
											<?php
										}									
									mysql_free_result($rs_2);		
					    			?>
								</TD>
							</TR>
						</TABLE>
						<?php
						//�������� ��� �������������
						?>
						<a href="subkat.php?type=favread" title="<?php echo $zl['169']?>"><?php echo $zl['169']?></a><br>
						<br>
						<?php
					}
					$pi_count_notupd=recordcount("select tbl_fav.BASECODE from tbl_fav,tbl_base where tbl_fav.USERCODE=".$ps_usercode." and tbl_fav.BASECODE=tbl_base.CODE and tbl_fav.DATELAST>=tbl_base.DATEMODER");
					if ($pi_count_notupd>0){
						//��� ���������
						echo '<b>'.$zl['494'].':</b><br>';
		    			?>
						<TABLE cellSpacing=3 class=table_int_table cellPadding=0 width=700 border=0>
							<TR valign=top>
								<TD class=f10 width=100%>
									<?php
									//������� ����������
									$ps_constr2="select tbl_fav.BASECODE as f_BASECODE, tbl_base.NAZV as b_NAZV, tbl_base.CODE as b_CODE, tbl_fav.DATELAST as f_DATELAST, tbl_base.DATEMODER as b_DATEMODER from tbl_fav,tbl_base where tbl_fav.USERCODE=".$ps_usercode." and tbl_fav.BASECODE=tbl_base.CODE and tbl_fav.DATELAST>tbl_base.DATEMODER order by tbl_base.NAZV";
									$pi1=0;
									$rs_2 = mysql_query($ps_constr2,$conn1);
										while (($rs=mysql_fetch_assoc($rs_2))!==false) {
											$pi1=$pi1+1;
											?>
											<TABLE cellSpacing=0 cellPadding=0 border=0 width=100%>
												<TR>
													<TD width=100%>
														<TABLE cellSpacing=1 cellPadding=3 border=0 width=100%>
															<TR class=f8 valign=top height=20>
																<TD width=40 align=center bgcolor="<?php echo $zcmas[5]?>">
																	<?php echo $pi1;?>.
																</TD>
																<TD bgcolor="<?php echo $zcmas[5]?>">
																	<?php
																	//������� �� �������
																	?>
																	<a href="topic.php?type=show&code=<?php echo $rs['b_CODE']?>" title="<?php echo $zl['16']?>"><?php echo $rs['b_NAZV']?></a>
																</TD>
																<TD bgcolor="<?php echo $zcmas[5]?>" width=120 align=center>
																	<?php
																	echo cdate($rs['f_DATELAST']);
																	?>
																</TD>
																<TD bgcolor="<?php echo $zcmas[5]?>" width=30 align=center>
																	<?php
																	//������ �� ����������
																	//������������� ����� ����������
																	?>
																	<a href="subkat.php?type=favdel&code=<?php echo $rs['b_CODE']?>" title="<?php echo $zl['489']?>" OnClick="return confirm('<?php echo $zl['495']?>?'); return true;">
																	<img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=16 height=16 border=0>
																	</a>
																</TD>
															</TR>
														</TABLE>
													</TD>
												</TR>
											</TABLE>
											<?php
										}									
									mysql_free_result($rs_2);		
					    			?>
								</TD>
							</TR>
						</TABLE>
						<br>
						<?php
					}
    			}else{
    				//������ ������ ���
    				echo '<br><b>'.$zl['178'].'</b>';    				
    			}
			}




			//==========================================================================================
			if ($ps_type=="changealtpos"){
				windowsize (250,650);
				?>
				<center>
				<br>
				<?php
				//�������� �������
				us_text2($zl['466']);
				$rs_2=mysql_query("select LINKPOS from tbl_link where CODE=".$ps_code,$conn1);
					$rs=mysql_fetch_array($rs_2);
					$ps_linkopis=$rs['LINKPOS'];
				mysql_free_result($rs_2);				
				//�������
				?>
				<form method="post" name="frmlogin" action="subkat.php" border=0>
					<input type="hidden" name="type" value="<?php echo $ps_type?>2">
					<input type="hidden" name="code" value="<?php echo $ps_code?>">
					<?php echo $zl['156']?>: 
					<input type="text" name="link_pos" class=input2 size="10" maxlength="5" onFocus="id=className;" onBlur="id=''" value="<?php echo $ps_linkopis?>"><br>
					<br>
					<?php
					//��������
					inputstyle($zl['70']);
					?>
					<br>
					<br>
				</form>	
				<?php
			}







			//==========================================================================================
			if ($ps_type=="changealtopis"){
				windowsize (250,650);
				?>
				<center>
				<br>
				<?php
				//�������� ��������
				us_text2($zl['465']);
				$rs_2=mysql_query("select LINKOPIS from tbl_link where CODE=".$ps_code,$conn1);
					$rs=mysql_fetch_array($rs_2);
					$ps_linkopis=$rs['LINKOPIS'];
				mysql_free_result($rs_2);				
				//��������
				?>
				<form method="post" name="frmlogin" action="subkat.php" border=0>
					<input type="hidden" name="type" value="<?php echo $ps_type?>2">
					<input type="hidden" name="code" value="<?php echo $ps_code?>">
					<?php echo $zl['165']?>: 
					<input type="text" name="link_opis" class=input2 size="80" maxlength="200" onFocus="id=className;" onBlur="id=''" value="<?php echo $ps_linkopis?>"><br>
					<br>
					<?php
					//��������
					inputstyle($zl['70']);
					?>
					<br>
					<br>
				</form>	
				<?php
			}



    		//===========================================================================================
    		if ($ps_type=="findlow"){
    			//�����
				us_text($zl['66']);
				//������� �������� ������
				us_text2($zl['451']);
				//����������� ����� �������:
    			?>
    			<br>
    			<br>
    			<center>
    			<b>
    			<?php echo $zl['452'].': '.$ps_minlen?>
    			</b>
				<FORM name="frmfind" METHOD="send" ACTION="subkat.php">
	      			<input type="hidden" name="type" value="find">
	      			<input class=input3 type="text" name="search" size="25" maxlength="25" value="<?php echo $ps_search?>" onFocus="id=className;" onblur="id=''">
	      			<input type="submit" class=inputb3 value="<?php echo $zl['66']?>" onMouseOver="id=className" onMouseOut="id=''">
				</FORM>    			
    			</center>
    			<?php
			}








    		//===========================================================================================
    		if ($ps_type=="modernote"){
    			//������� �����������
				us_text($zl['432']);
				echo '<br>';
				$ps_constr="tbl_modernote";
				$ps_perpage=getconf("COMMENTPERPAGE","VALUESTR");//�� ������� �� ��������
				$pi_count=recordcount_new($ps_constr);
				$pi3=ceil($pi_count/$ps_perpage);
				if ($ps_page>$pi3) $ps_page=$pi3;
				$pi4=($ps_page-1)*$ps_perpage;
				if ($pi_count>$ps_perpage){
					//��������:
					?>
					<form method="send" name="frmadd" action="subkat.php">
						<input type="hidden" name="type" value="<?php echo $ps_type?>">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
							<?php
							for ($pi1=1; $pi1<=$pi3;$pi1++)
								{						
								?>
								<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
								<?php
							}
							?>
						</select>
						&nbsp;<?php 
						//�������
						inputstyle($zl['171']);
						?>
					</form>
					<?php
				}				
				//������� ����������
				$pi1=$pi4;
				$ps_constr2="tbl_modernote";
				if (recordcount_new($ps_constr2)>0){
					$ps_constr2="select * from tbl_modernote order by DATEADD desc limit ".$pi4.",".$ps_perpage;
					$rs2_2 = mysql_query($ps_constr2,$conn1);
						while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
							?>
							<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0 bgcolor="<?php echo $zcmas[2]?>">
								<TR valign=top>
									<TD class=f9 width=150 align=center>
										<font size=1><u><?php echo cdate($rs2['DATEADD'])?></u></font><br>
										<?php
										$rs3_2=mysql_query("select * from tbl_user where CODE=".$rs2['WHOADD'],$conn1);
											$rs3=mysql_fetch_array($rs3_2);
											if ($rs3['ISBAN']==1){
												//������������ ������������
												?>
												<img src="main/color/scheme/<?php echo $ps_color;?>/element_lock.png" width=16 height=16 alt="<?php echo $zl['172']?>">
												<?php
											}
											//���������� � ������������
											?>
											<a href="user.php?type=show&code=<?php echo $rs2['WHOADD']?>" title="<?php echo $zl['12']?>">
											<?php echo $rs3['LOGIN'];?>
											</a><br>
											<?php
											//������� ������������
											echo '<font size=1>'.getstatusname($rs3['STATUS']).'</font><br>';
										mysql_free_result($rs3_2);
										?>
									</TD>
									<td class=f9>
										<?php
										$ps_opis=$rs2['OPIS']; 
										$ps_opis=str_replace(chr(13),"<br>",$ps_opis);
										//������������ ����� �����������
										$ps_comment=commentdo($ps_opis);
										echo $ps_comment;
										?><br>
										&nbsp;
										<br>
									</td>
									<td width=20>
										<?php
										if ((isadekvat($rs2['WHOADD'])==1)|| $rs2['WHOADD']==$ps_usercode){
											//������� ���������
											//������������� ������� ���������
											?>
											<a href="subkat.php?type=delmodernote&code=<?php echo $rs2['CODE']?>&type2=<?php echo $ps_code?>&page=<?php echo $ps_page?>" title="<?php echo $zl['532']?>" OnClick="return confirm('<?php echo $zl['533']?>?'); return true;">
											<img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" width=16 height=16 border=0>
											</a>
											<?php
										}
										?>
									</td>
								</TR>										
							</TABLE>			
							<?php
						}									
					mysql_free_result($rs2_2);					
				}
    			?>
	    		<br>								
				<?php
				if ($pi_count>$ps_perpage){
					//��������:
					?>
					<form method="send" name="frmadd1" action="subkat.php">
						<input type="hidden" name="type" value="<?php echo $ps_type?>">
						<input type="hidden" name="code" value="<?php echo $ps_code?>">
						<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
							<?php
							for ($pi1=1; $pi1<=$pi3;$pi1++)
								{						
								?>
								<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
								<?php
							}
							?>
						</select>
						&nbsp;<?php
						//�������
						inputstyle($zl['171']);
						?>
					</form>
					<?php
				}									
				//�������� ���������
				?>
				<a name="addcomment"></a>
				<TABLE cellSpacing=5 class=table_int_table cellPadding=0 width=100% border=0 bgcolor="<?php echo $zcmas[2]?>">
					<TR valign=top>
						<TD class=f9b align=center width=100% valign="middle">
							<form method="post" name="frmcomment" action="subkat.php">
								<input type="hidden" name="type" value="addmodernote">
								<font size=3><?php echo $zl['611']?></font><br>
								<br>
								<?php
								//������ �����
								//������
								//������
								//�������������� �����
								//�������� �����������
								?>
								<TABLE cellSpacing=0 cellPadding=0 width=660 border=0>
									<TR valign=top>
										<TD width=240>
											<TABLE cellSpacing=0 cellPadding=0 border=0>
												<TR valign=top>
													<TD width=100% class=f9b align=center>
														<input type="button" value=" � " title="<?php echo $zl['470']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[b]','[/b]');">
														<input type="button" value=" � " title="<?php echo $zl['471']?>" class=inputb1 style="font-style: italic;" onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[i]','[/i]');">
														<input type="button" value=" � " title="<?php echo $zl['472']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[u]','[/u]');">
														&nbsp;
														<input type="button" value="HR" title="<?php echo $zl['473']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('','[hr]');">
														<input type="button" value="URL" title="<?php echo $zl['474']?>" class=inputb1 onMouseOver="id=className" onMouseOut="id=''" onclick="tag_it('[url]','[/url]');">
													</TD>
												</TR>
											</TABLE>
										</TD>
										<TD>
											<TABLE class=table_int_table cellSpacing=0 cellPadding=0 width=100 border=0>
												<TR valign=top>
													<TD width=100% class=f9b align=center>
														<div id="smiles_hide" onClick="javascript:showel('mg_smiles');javascript:hideel('smiles_hide');javascript:showel('smiles_show');" style="cursor: pointer;">
															<?php
															//������
															echo $zl['475'];
															?>
														</div>
														<div id="smiles_show" style="display:none" onClick="javascript:hideel('mg_smiles');javascript:hideel('smiles_show');javascript:showel('smiles_hide');" style="cursor: pointer;">
															<?php
															//������
															echo $zl['475'];
															?>
														</div>																	
													</TD>
												</TR>
											</TABLE>		
										</TD>
									</TR>
								</TABLE>
								<div id="mg_smiles" style="display:none">
									<TABLE class=table_int_table cellSpacing=0 cellPadding=0 width=660 border=0>
										<TR valign=top>
											<TD>
												<?php
												//������� ��� ������ �� �����
												foreach (glob($zserver."main/color/scheme/".$ps_color."/smiles/*.gif") as $filename) {
													$pi1=$pi1+1;
													$ps1=left_1($filename,(strlen($filename)-4));
													for ($pi2=1; $pi2<=strlen($ps1);$pi2++){
														if (mid($ps1,$pi2,1)=="/"){
															$ps3=mid($ps1,$pi2+1,strlen($ps1));
														}
													}
													$ps_smilename=trim($ps3);
													$ps_smilefile=$ps_smilename.".gif";
													?>
													<a>
													<img src="main/color/scheme/<?php echo $ps_color?>/smiles/<?php echo $ps_smilefile?>" onclick="tag_it('','[<?php echo $ps_smilename?>]');" alt="[<?php echo $ps_smilename?>]">
													</a>
													<?php
												}																
												?>
											</TD>
										</TR>
									</TABLE>
									<br>
								</div>																				
								<textarea class=TEXTAREA1 name="comment" cols="107" rows="10"><?php if (requestdata("comment")!="") echo requestdata("comment");?></textarea><br>
								<br>
								<?php
								//���������
								inputstyle($zl['333']);
								?>
								<br><br>
							</form>
						</TD>
						<td>
						</td>
					</TR>
				</TABLE>
    			<br>
    			<?php
			}





    		//===========================================================================================
    		if ($ps_type=="ismoderaltlink"){
    			//��������� ������
				us_text($zl['461']);
				$ps_constr="select tbl_link.CODE from tbl_link,tbl_base where tbl_link.ISMODER=0 and tbl_link.BASECODE=tbl_base.CODE and tbl_base.ISMODER=1";
				$pi_count=recordcount($ps_constr);
				if ($pi_count>0){
	    			echo '<br>';
					$ps_perpage=getconf("PERPAGE","VALUESTR");//�� ������� �� ��������
					$ps_perpage=$ps_perpage*2;
					$pi3=ceil($pi_count/$ps_perpage);
					if ($ps_page>$pi3) $ps_page=$pi3;
					$pi4=($ps_page-1)*$ps_perpage;
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}					
	    			?>
					<TABLE cellSpacing=3 class=table_int_table cellPadding=0 width=95% border=0>
						<TR valign=top>
							<TD class=f10 width=50%>
								<?php
								//������� ����������
								$ps_constr2="select tbl_base.NAZV as b_NAZV, tbl_base.CODE as b_CODE, tbl_link.CODE as l_CODE, tbl_link.LINK as l_LINK, tbl_link.LINKOPIS as l_LINKOPIS, tbl_link.LINKPOS as l_LINKPOS, tbl_link.WHOADD as l_WHOADD from tbl_link,tbl_base where tbl_link.ISMODER=0 and tbl_link.BASECODE=tbl_base.CODE and tbl_base.ISMODER=1 order by tbl_link.DATEADD limit ".$pi4.",".$ps_perpage;
								$pi1=0;								
								$rs_2 = mysql_query($ps_constr2,$conn1);
									while (($rs=mysql_fetch_assoc($rs_2))!==false) {
										$pi1=$pi1+1;
										?>
										<TABLE cellSpacing=0 cellPadding=0 border=0 width=100%>
											<TR>
												<TD width=100%>
													<TABLE cellSpacing=0 cellPadding=0 border=0 width=100%>
														<TR class=f8 valign=top height=20>
															<TD width=40 align=center bgcolor="<?php echo $zcmas[5]?>">
																<?php echo $pi1;?>.
															</TD>
															<TD bgcolor="<?php echo $zcmas[5]?>" width=350>
																<?php
																//������� �� �������
																?>
																<a href="topic.php?type=show&code=<?php echo $rs['b_CODE']?>" title="<?php echo $zl['16']?>"><?php echo $rs['b_NAZV']?></a>
															</TD>
															<TD bgcolor="<?php echo $zcmas[5]?>">
																<?php
																//��� �������:
																//���������� � ������������
																echo $zl['111'];
																echo ' <a title="'.$zl['12'].'" href="user.php?type=show&code='.$rs['l_WHOADD'].'">'.getuserlogin($rs['l_WHOADD']).'</a>';
																?>
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
											<TR>
												<TD width=100%>
													<TABLE cellSpacing=0 cellPadding=0 border=0 width=100%>
														<TR class=f8 valign=top height=80>
															<TD width=40 align=center bgcolor="<?php echo $zcmas[5]?>">
																<?php
																//�����������
																?>
																<br>
																<a href="subkat.php?type=altlinkaprove&code=<?php echo $rs['l_CODE']?>" title="<?php echo $zl['339']?>">
																<img src="main/color/scheme/<?php echo $ps_color;?>/element_accept.png" border=0 width=16 height=16>
																</a><br>
																<?php
																//���������
																//������������� ������� ������
																?>
																<br>
																<a href="subkat.php?type=altlinkdel&code=<?php echo $rs['l_CODE']?>" title="<?php echo $zl['467']?>" OnClick="return confirm('<?php echo $zl['468']?>?'); return true;">
																<img src="main/color/scheme/<?php echo $ps_color;?>/element_close.png" border=0 width=16 height=16>
																</a>
															</TD>
															<TD bgcolor="<?php echo $zcmas[5]?>">
																<a href="javascript:OpenDoc('subkat.php?type=changealtpos&code=<?php echo $rs['l_CODE']?>',<?php echo rndwindow()?>)" title="<?php echo $zl['70']?>" class=link1>
																<?php
																echo $zl['156'];//��������
																//��������
																?></a>:
																<a href="javascript:OpenDoc('subkat.php?type=changealtpos&code=<?php echo $rs['l_CODE']?>',<?php echo rndwindow()?>)" title="<?php echo $zl['70']?>"><?php echo $rs['l_LINKPOS']?></a><br>
																<a href="javascript:OpenDoc('subkat.php?type=changealtopis&code=<?php echo $rs['l_CODE']?>',<?php echo rndwindow()?>)" title="<?php echo $zl['70']?>" class=link1>
																<?php
																echo $zl['165'];//��������
																//��������
																?></a>:
																<a href="javascript:OpenDoc('subkat.php?type=changealtopis&code=<?php echo $rs['l_CODE']?>',<?php echo rndwindow()?>)" title="<?php echo $zl['70']?>">
																<?php echo $rs['l_LINKOPIS']?></a><br>
																<a href="<?php echo $rs['l_LINK']?>"><?php echo $rs['l_LINK']?></a><br>
																<font size=1>
																<div id="<?php echo $rs['l_CODE']?>_hide" onClick="javascript:showel('mg_alllink_<?php echo $rs['l_CODE']?>');javascript:hideel('<?php echo $rs['l_CODE']?>_hide');javascript:showel('<?php echo $rs['l_CODE']?>_show');" style="cursor: pointer;">
																	<?php
																	//�������� ������������ ������
																	echo ':: '.$zl['463'].' ::';
																	?>
																</div>
																<div id="<?php echo $rs['l_CODE']?>_show" style="display:none" onClick="javascript:hideel('mg_alllink_<?php echo $rs['l_CODE']?>');javascript:hideel('<?php echo $rs['l_CODE']?>_show');javascript:showel('<?php echo $rs['l_CODE']?>_hide');" style="cursor: pointer;">
																	<?php
																	//������ ������������ ������
																	echo ':: '.$zl['464'].' ::';
																	?>
																</div>																	
																</font>
																<div id="mg_alllink_<?php echo $rs['l_CODE']?>" style="display:none">
																	<TABLE cellSpacing=0 cellPadding=0 border=1>
																		<TR class=f8 valign=top height=60>
																			<TD>
																				<?php
																				$rs2_2 = mysql_query("select * from tbl_link where ISMODER=1 and BASECODE=".$rs['b_CODE'],$conn1);
																					while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
																						$ps_linkopis=$rs2['LINKOPIS'];
																						echo $zl['156'].': '.$rs2['LINKPOS'];//�������
																						if ($ps_linkopis!='') echo ' - ';
																						echo $rs2['LINKOPIS'].'<br>';
																						echo '<a href="'.$rs2['LINK'].'">'.$rs2['LINK'].'</a><br>';
																						?>
																						<?php
																					}
																				mysql_free_result($rs2_2);																		
																				?>
																			</TD>
																		</TR>
																	</TABLE>
																</div>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
											<TR height=2>
												<TD>
												</TD>
											</TR>
										</TABLE>
										<?php
									}									
								mysql_free_result($rs_2);		
				    			?>
							</TD>
						</TR>
					</TABLE>
					<br>
					<?php
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd1" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					//������� ������
					?>
					<b>:: <a href="#ontop"><?php echo $zl['420']?></b></a><br>
					<br>
					<?php
    			}else{
    				//������ ������ ���
    				echo '<br><b>'.$zl['178'].'</b>';    				
    			}
			}










    		//===========================================================================================
    		if ($ps_type=="persona" || $ps_type=="mypersona" || $ps_type=="onmoderpersona" || $ps_type=="onmodereditpersona" || $ps_type=="ismoderpersona" || $ps_type=="lastpersona"){
    			//����������
    			if ($ps_type!="lastpersona") us_text($zl['358']);
				//���� ��� ������ ����������� ���������� - �� ���������� ���������� ���������
				if ($ps_type=="persona"){
					if (recordcount_new("tbl_persona where ISMODER=1")>0){
						$pmas1=array();
						$pi1=0;
						$rs_2 = mysql_query("select NAZV,NAZVROD from tbl_persona where ISMODER=1",$conn1);
							while (($rs=mysql_fetch_assoc($rs_2))!==false) {
								$ps1=$rs['NAZV'];
								if (strlen($ps1)>0){
									$ps1=ucase(left_1($ps1,1));
									$pi1=$pi1+1;
									$pmas1[$pi1][1]=$ps1;
								}
								$ps1=$rs['NAZVROD'];
								if (strlen($ps1)>0){
									$ps1=ucase(left_1($ps1,1));
									$pi1=$pi1+1;
									$pmas1[$pi1][1]=$ps1;
								}
							}
						mysql_free_result($rs_2);
						//���������
						$pi10=1;
						usort($pmas1,"cmp");
						//������� ����������
						$pb1=0;
						for ($pi1=0; $pi1<=(count($pmas1)-1);$pi1++){
							if ($pmas1[$pi1][1]!=$pmas1[$pi1+1][1]){
								if ($pmas1[$pi1][1]=='�' || $pmas1[$pi1][1]=='�' || $pmas1[$pi1][1]=='�'){
									if ($pb1==0){
										echo '<br>';
										$pb1=1;
									}
								}
								?>
								<a href="subkat.php?type=persona&type2=<?php echo $pmas1[$pi1][1]?>"><?php echo $pmas1[$pi1][1]?></a>&nbsp;&nbsp;
								<?php
							}
						}
						echo '<br>';
					}
				}
				
				if ($ps_type=="mypersona") us_text2($zl['376']);//��� ����������
				if ($ps_type=="ismoderpersona") us_text2($zl['380']);//��������� ����������
				if ($ps_type=="onmoderpersona") us_text2($zl['377']);//���������� �� ���������
				if ($ps_type=="onmodereditpersona") us_text2($zl['378']);//���������� �� ���������
				if ($ps_type=="lastpersona") us_text($zl['388']);//����� ����������

				if ($ps_type=="mypersona") $ps_constr="tbl_persona where ISMODER=1 and WHOADD=".$ps_usercode;
				if ($ps_type=="persona"){
					if ($ps_type2==""){
						if ($pmas1[1][1]!='') $ps_type2=$pmas1[1][1];
					}
					$ps_constr="tbl_persona where ISMODER=1";
					if ($ps_type2!='') $ps_constr=$ps_constr." and (NAZV like '".$ps_type2."%' or NAZVROD like '".$ps_type2."%')";
				}
				if ($ps_type=="onmoderpersona") $ps_constr="tbl_persona where ISMODER=0 and ISDOPEDIT=0 and WHOADD=".$ps_usercode;
				if ($ps_type=="onmodereditpersona") $ps_constr="tbl_persona where ISMODER=0 and ISDOPEDIT=1 and WHOADD=".$ps_usercode;
				if ($ps_type=="ismoderpersona") $ps_constr="tbl_persona where ISMODER=0 and ISDOPEDIT=0";
				if ($ps_type=="lastpersona"){
					$rs_2=mysql_query("select LASTNEWSPERSONA from tbl_user where CODE=".$ps_usercode,$conn1);
						$rs=mysql_fetch_array($rs_2);
						$pd4=$rs['LASTNEWSPERSONA'];
					mysql_free_result($rs_2);					
					$ps_constr="tbl_persona tbl_persona where ISMODER=1 and DATEMODER>'".$pd4."'";
				}
				$pi_count=recordcount_new($ps_constr);
				if ($pi_count>0){
					$pi_midle=round($pi_count*0.5);
					$pi1=0;
					if ($ps_type=="lastpersona"){
						//�������� ��� �������������
	    				?>
	    				<b>:: <a href="subkat.php?type=setlastnewspersona&type2=<?php echo mktime()?>"><?php echo $zl['169']?></b></a><br>
	    				<?php
	    			}
	    			echo '<br>';
					$ps_perpage=getconf("PERPAGE","VALUESTR");//�� ������� �� ��������
					$ps_perpage=$ps_perpage*2;
					$pi3=ceil($pi_count/$ps_perpage);
					if ($ps_page>$pi3) $ps_page=$pi3;
					$pi4=($ps_page-1)*$ps_perpage;
					if ($pi_midle>round($ps_perpage*0.5)) $pi_midle=round($ps_perpage*0.5);
					//$ps_constr2="select * from tbl_poster where DATEADD>'".$pd1."' order by DATEADD limit ".$pi4.",".$ps_perpage;
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}					
	    			?>
					<TABLE cellSpacing=3 class=table_int_table cellPadding=0 width=95% border=0>
						<TR valign=top>
							<TD class=f10 width=50%>
								<?php
								//������� ����������
								if ($ps_type=="mypersona") $ps_constr2="select * from tbl_persona where ISMODER=1 and WHOADD=".$ps_usercode." order by NAZV limit ".$pi4.",".$ps_perpage;
								if ($ps_type=="persona"){
									$ps_constr2="select * from tbl_persona where ISMODER=1";
									if ($ps_type2!='') $ps_constr2=$ps_constr2." and (NAZV like '".$ps_type2."%' or NAZVROD like '".$ps_type2."%')";
									$ps_constr2=$ps_constr2." order by NAZV limit ".$pi4.",".$ps_perpage;
								}
								if ($ps_type=="onmoderpersona") $ps_constr2="select * from tbl_persona where ISMODER=0 and ISDOPEDIT=0 and WHOADD=".$ps_usercode." order by NAZV limit ".$pi4.",".$ps_perpage;
								if ($ps_type=="onmodereditpersona") $ps_constr2="select * from tbl_persona where ISMODER=0 and ISDOPEDIT=1 and WHOADD=".$ps_usercode." order by NAZV limit ".$pi4.",".$ps_perpage;
								if ($ps_type=="ismoderpersona") $ps_constr2="select * from tbl_persona where ISMODER=0 and ISDOPEDIT=0 order by NAZV limit ".$pi4.",".$ps_perpage;
								if ($ps_type=="lastpersona"){
									$rs_2=mysql_query("select LASTNEWSPERSONA from tbl_user where CODE=".$ps_usercode,$conn1);
										$rs=mysql_fetch_array($rs_2);
										$pd4=$rs['LASTNEWSPERSONA'];
									mysql_free_result($rs_2);					
									$ps_constr2="select * from tbl_persona tbl_persona where ISMODER=1 and DATEMODER>'".$pd4."' order by NAZV limit ".$pi4.",".$ps_perpage;
								}
								$pi1=0;								
								$pb_first=0;
								$ps_isphotopers=getconf("ISPHOTOPERS","VALUEINT");
								$rs_2 = mysql_query($ps_constr2,$conn1);
									while (($rs=mysql_fetch_assoc($rs_2))!==false) {
										$pi1=$pi1+1;
										//����������� ����������
										$ps1=$rs['LINKS'];
										?>
										<TABLE cellSpacing=0 cellPadding=0 border=0>
											<TR>
												<TD width=25 align=center>
													<?php
													//���� ���� ������ - ���������� ��������� ������
													$ps12=$rs['POSTER'];
													//���� ���������� � ����� ����� - �� ������ ������� ��������
													$ps_first=left_1($rs['NAZV'],1);
													if ($ps_type2!='') $ps_first=ucase($ps_type2);
													if ($ps_type=="persona" && $pb_first!=0){
														$ps_first='';
													}
													$pb_first=1;
													if (ucase($ps_first)!=$ps_first2){
														//��������� �������� - ����� ������ ����
														if ($ps_type=="persona") $pi_midle=$pi_midle-1;
														?>
														</TD>
														<TD class=f10>
															<font color="<?php echo $zcmas[20]?>" size=6><?php echo $ps_first?></font>
														</TD>
														</TR>
														<TR>
														<TD width=25 align=center>
														<?php
														$ps_first2=ucase($ps_first);
													}
													if ($ps12!='' && $ps_isphotopers==1){
														//��� ��������� ������ ��������, � �� �������� ������
														$size = getimagesize($zserver."main/persona/".$ps12);
														$pi_w = $size[0];
														$pi_h = $size[1];					
														if ($pi_w>20){
															$pi3=$pi_w/20;
															$pi_w=20;
															$pi_h=round($pi_h/$pi3);
														}
														if ($pi_w<20){
															$pi3=20/$pi_w;
															$pi_w=20;
															$pi_h=round($pi_h*$pi3);
														}
														?>
														<a href="persona.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $rs['NAZV']?>">
														<img src="main/persona/<?php echo $ps12?>" width=<?php echo $pi_w?> height=<?php echo $pi_h?> border=0></a>
														<?php
													}else{
														echo '&bull;';
													}
													?>
												</TD>
												<TD class=f10>
													<a class="link2" href="persona.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $zl['363']?>">
													<?php 
													$pb1=0;
													if ($rs['NAZVROD']!=""){
														if (lcase($ps_type2)==lcase(left_1($rs['NAZVROD'],1))){
															echo $rs['NAZVROD'].'/';
															$pb1=1;
														}
													}
													echo $rs['NAZV'];
													if ($rs['NAZVROD']!='' && $pb1==0) echo '/'.$rs['NAZVROD'];
													?>
													</a>
													<?php
													if ($ps1!="0" && $ps1!="") echo ' ('.$ps1.')';
													?>
												</TD>
											</TR>
										</TABLE>
										<?php
										if ($pi1==$pi_midle){
											?>
											</TD>
											<TD class=f10 width=50%>
											<?php
										}
									}									
								mysql_free_result($rs_2);		
				    			?>
							</TD>
						</TR>
					</TABLE>
					<br>
					<?php
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd1" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}									
					//������� ������
					?>
					<b>:: <a href="#ontop"><?php echo $zl['420']?></b></a><br>
					<br>
					<?php
    			}else{
    				//������ ������ ���
    				echo '<br><b>'.$zl['178'].'</b>';    				
    			}
			}







    		//===========================================================================================
    		if ($ps_type=="lastposter"){
    			//����� ���������
				us_text($zl['60']);
				$rs_2=mysql_query("select LASTNEWSPOSTER from tbl_user where CODE=".$ps_usercode,$conn1);
					$rs=mysql_fetch_array($rs_2);
					$pd1=$rs['LASTNEWSPOSTER'];
				mysql_free_result($rs_2);
				$ps_constr="tbl_poster where ISMODER=1 and DATEADD>'".$pd1."'";
				$pi_count=recordcount_new($ps_constr);
				if ($pi_count>0){
					//�������� ��� �������������
    				?>
    				<b>:: <a href="subkat.php?type=setlastnewsposter&type2=<?php echo mktime()?>"><?php echo $zl['169']?></b></a><br>
    				<br>
    				<?php
					$ps_perpage=getconf("COMMENTPERPAGE","VALUESTR");//�� ������� �� ��������
					$ps_perpage=$ps_perpage*3;
					$pi3=ceil($pi_count/$ps_perpage);
					if ($ps_page>$pi3) $ps_page=$pi3;
					$pi4=($ps_page-1)*$ps_perpage;
					$ps_constr2="select * from tbl_poster where ISMODER=1 and DATEADD>'".$pd1."' order by DATEADD limit ".$pi4.",".$ps_perpage;
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					//������� ����������
					$pi1=$pi4;
					$ps_isr=getconf("ISREFLEX_AVA","VALUEINT");
					$rs2_2 = mysql_query($ps_constr2,$conn1);
						while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
							?>
							<TABLE cellSpacing=3 class=table_int_table cellPadding=0 width=95% border=0>
								<TR valign=top>
									<TD class=f9 width=150>
										<font size=1><u><?php echo cdate($rs2['DATEADD'])?></u></font><br>
										<?php
										$rs3_2=mysql_query("select * from tbl_user where CODE=".$rs2['WHOADD'],$conn1);
											$rs3=mysql_fetch_array($rs3_2);
											if ($rs3['ISBAN']==1){
												//������������ ������������
												?>
												<img src="main/color/scheme/<?php echo $ps_color;?>/element_lock.png" width=16 height=16 alt="<?php echo $zl['172']?>">
												<?php
											}
											//���������� � ������������
											?>
											<a href="user.php?type=show&code=<?php echo $rs2['WHOADD']?>" title="<?php echo $zl['12']?>">
											<?php echo $rs3['LOGIN'];?>
											</a><br>
											<?php
											if ($rs3['POSTER']!="" && mayavatar($rs2['WHOADD'])==1){
												?>
												<img src="main/avatar/<?php echo $rs3['POSTER']?>" <?php if ($ps_isr==1) echo 'class="reflex itiltnone iopacity100"';?> width=64 height=64 border=0>
												<br>														
												<?php
											}
										mysql_free_result($rs3_2);
										?>
									</TD>
									<td class=f9>
										<?php
										$rs_2=mysql_query("select * from tbl_base where CODE=".$rs2['BASECODE'],$conn1);
											$rs=mysql_fetch_array($rs_2);
											echo '<font size=1><u>';
											//�������
											//������� �� �������
											echo $zl['173'].'</u>: <a title="'.$zl['16'].'" href="topic.php?type=show&code='.$rs2['BASECODE'].'">'.$rs['NAZV'].'</a>';
											//�������
											echo ' - '.$zl['174'].': <b>'.$rs['VOTES'].'</b>';
											//���������
											//�������� ���������
											echo ' - '.$zl['175'].': <a title="'.$zl['176'].'" href="kat.php?type=showkat&type2='.$rs['KAT'].'">'.getkatname($rs['KAT']).'</a>';
											echo '</font><br><br>';
										mysql_free_result($rs_2);
										$ps1=$rs2['POSTER'];
										if ($ps1!=""){
											$size = getimagesize($zserver."main/poster/".$ps1);
											$pi_w = $size[0];
											$pi_h = $size[1];					
											$pi_co=240;
											if ($pi_h>$pi_co){
												$pi6=$pi_h/$pi_co;
												$pi_h=$pi_co;
												$pi_w=round($pi_w/$pi6);
											}
											if ($pi_h<$pi_co){
												$pi6=$pi_co/$pi_h;
												$pi_h=$pi_co;
												$pi_w=round($pi_w*$pi6);
											}
											//�������� ��������
											?>
											<a rel="thumbnail" href="main/poster/<?php echo $ps1?>" title="<?php echo $zl['177']?>">
											<img src="main/poster/<?php echo $ps1?>" width="<?php echo $pi_w?>" height="<?php echo $pi_h?>" border=0> 
											</a>
											<?php
										}
										?>
									</td>
								</TR>										
							</TABLE>			
							<?php
						}									
					mysql_free_result($rs2_2);					
	    			?>
		    		<br>								
					<?php
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd1" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					//������� ������
					?>
					<b>:: <a href="#ontop"><?php echo $zl['420']?></b></a><br>
					<br>
					<?php
    			}else{
    				//������ ������ ���
    				echo '<br><b>'.$zl['178'].'</b>';
    			}
			}








    		//===========================================================================================
    		if ($ps_type=="lastcomment"){
    			//����� �����������
				us_text($zl['168']);
				$rs_2=mysql_query("select LASTNEWSCOMMENT from tbl_user where CODE=".$ps_usercode,$conn1);
					$rs=mysql_fetch_array($rs_2);
					$pd1=$rs['LASTNEWSCOMMENT'];
				mysql_free_result($rs_2);
				$ps_constr="tbl_comment where ISMODER=1 and DATEADD>'".$pd1."'";
				$pi_count=recordcount_new($ps_constr);
				if ($pi_count>0){
					//�������� ��� �������������
    				?>
    				<b>:: <a href="subkat.php?type=setlastnewscomment&type2=<?php echo mktime()?>"><?php echo $zl['169']?></b></a><br>
    				<br>
    				<?php
					$ps_perpage=getconf("COMMENTPERPAGE","VALUESTR");;//�� ������� �� ��������
					$ps_perpage=$ps_perpage*3;
					$pi3=ceil($pi_count/$ps_perpage);
					if ($ps_page>$pi3) $ps_page=$pi3;
					$pi4=($ps_page-1)*$ps_perpage;
					$ps_constr2="select * from tbl_comment where ISMODER=1 and DATEADD>'".$pd1."' order by DATEADD limit ".$pi4.",".$ps_perpage;
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					//������� ����������
					$pi1=$pi4;
					$pi_c=0;
					$ps_isr=getconf("ISREFLEX_AVA","VALUEINT");
					$rs2_2 = mysql_query($ps_constr2,$conn1);
						while (($rs2=mysql_fetch_assoc($rs2_2))!==false) {
							$pi_c++;
							if (fmod($pi_c,2)==0){
								$ps_backc='table_int_table2';
							}else{
								$ps_backc='table_int_table';
							}							
							?>
							<TABLE cellSpacing=3 class=<?php echo $ps_backc?> cellPadding=0 width=95% border=0>
								<TR valign=top>
									<TD class=f9 width=150 align=center>
										<font size=1><u><?php echo cdate($rs2['DATEADD'])?></u></font><br>
										<?php
										$rs3_2=mysql_query("select * from tbl_user where CODE=".$rs2['WHOADD'],$conn1);
											$rs3=mysql_fetch_array($rs3_2);
											if ($rs3['ISBAN']==1){
												//������������ ������������
												?>
												<img src="main/color/scheme/<?php echo $ps_color;?>/element_lock.png" width=16 height=16 alt="<?php echo $zl['172']?>">
												<?php
											}
											//���������� � ������������
											?>
											<a href="user.php?type=show&code=<?php echo $rs2['WHOADD']?>" title="<?php echo $zl['12']?>">
											<?php echo $rs3['LOGIN'];?>
											</a><br>
											<?php
											if ($rs3['POSTER']!="" && mayavatar($rs2['WHOADD'])==1){
												?>
												<img src="main/avatar/<?php echo $rs3['POSTER']?>" width=64 height=64 border=0 <?php if ($ps_isr==1) echo 'class="reflex itiltnone iopacity100"';?>>
												<br>														
												<?php
											}
											//������� ������������
											echo '<font size=1>'.getstatusname($rs3['STATUS']).'</font><br>';
											//�������
											echo '<font size=1>'.$zl['255'].': '.$rs3['RATINGS'].'</font><br>';
											$ps_israt=1;
											echo getstar(floor($rs3['RATINGS']*0.1)).' ';
											$ps_israt=0;											
										mysql_free_result($rs3_2);
										?>
									</TD>
									<td class=f9>
										<?php
										$rs_2=mysql_query("select * from tbl_base where CODE=".$rs2['BASECODE'],$conn1);
											$rs=mysql_fetch_array($rs_2);
											echo '<font size=1><u>';
											//�������
											//������� �� �������
											echo $zl['173'].'</u>: <a title="'.$zl['16'].'" href="topic.php?type=show&code='.$rs2['BASECODE'].'">'.$rs['NAZV'].'</a>';
											//�������
											echo ' - '.$zl['174'].': <b>'.$rs['VOTES'].'</b>';
											//���������
											//�������� ���������
											echo ' - '.$zl['175'].': <a title="'.$zl['176'].'" href="kat.php?type=showkat&type2='.$rs['KAT'].'">'.getkatname($rs['KAT']).'</a>';
											echo '</font><br><br>';
										mysql_free_result($rs_2);
										$ps_opis=$rs2['OPIS']; 
										$ps_opis=str_replace(chr(13),"<br>",$ps_opis);
										//������������ ����� �����������
										$ps_comment=commentdo($ps_opis);
										echo $ps_comment;										
										?><br>
										&nbsp;
										<br>
									</td>
									<td width=20>
										<?php
										if (($zright['DO_MODER']==1 && isadekvat($rs2['WHOADD'])==1) || $rs2['WHOADD']==$ps_usercode){
											//������� �����������
											//������������� ������� �����������?
											?>
											<a href="topic.php?type=delcomment&code=<?php echo $rs2['CODE']?>&type2=not&page=<?php echo $ps_page?>" title="<?php echo $zl['179']?>" OnClick="return confirm('<?php echo $zl['180']?>'); return true;">
											<img src="main/color/scheme/<?php echo $ps_color; ?>/element_close.png" width=16 height=16 border=0>
											</a>
											<?php
										}
										?>
									</td>
								</TR>										
							</TABLE>			
							<?php
						}									
					mysql_free_result($rs2_2);					
	    			?>
		    		<br>								
					<?php
					if ($pi_count>$ps_perpage){
						//��������:
						?>
						<form method="send" name="frmadd1" action="subkat.php">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="code" value="<?php echo $ps_code?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					//������� ������
					?>
					<b>:: <a href="#ontop"><?php echo $zl['420']?></b></a><br>
					<br>
					<?php
    			}else{
    				//������ ������ ���
    				echo '<br><b>'.$zl['178'].'</b>';
    			}
			}





    		//===========================================================================================
    		if ($ps_type=="showsubkat" || $ps_type=="ismoder" || $ps_type=="find" || $ps_type=="onmoder" || $ps_type=="onmoderedit" || $ps_type=="mylink" || $ps_type=="lastnews" || $ps_type=="shownews"){
    			if ($ps_type=="showsubkat"){
					//���� ������
		      		if (getconf("ISFINDTOP_2","VALUEINT")==1){
		      			?>
						<script>
							var xmlHttp;
							function showResultMagneto2(str){
								if (str.length==0){ 
									document.getElementById("magneto_search_top").innerHTML="";
									document.getElementById("magneto_search_top").style.display="none";
									return;
								}
								xmlHttp=GetXmlHttpObject();
								if (xmlHttp==null){
									//alert ("������� �� ������������ HTTP-Request");
									return;
								} 
								var url="index.php?type=new_pre";
								//url=url+"?search="+encodeURIComponent(str);
								url=url+"&search="+str;
								url=url+"&stest=���";
								url=url+"&randoms="+Math.random();
								xmlHttp.onreadystatechange=stateChangedMagneto2;
								xmlHttp.open("GET",url,true);
								xmlHttp.send(null);
							}
							function stateChangedMagneto2(){ 
								if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
									{ 
									document.getElementById("magneto_search_top").innerHTML=xmlHttp.responseText;
									document.getElementById("magneto_search_top").style.display="";
								} 
							}
						</script> 			
			      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
							<FORM name="frmfind" METHOD="send" ACTION="subkat.php">
				      			<TR class=f10>
					      			<?php
					      			//�����
					      			//� ���
			      					?>
				      				<td valign=top align=center>
							      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat>
							      			<TR class=f10 height=16>
							      				<td>
										      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
										      			<TR class=f10 height=16>
										      				<td width=25 align=center>
							      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
							      							</TD>
										      				<td>
										      					<b><?php echo $zl['66']?></b>
							      							</TD>
							      						</TR>
							      					</TABLE>
							      				</TD>
							      			</TR>
											<TR height=30>
							      				<td class=f10 align=center>
									      			<input type="hidden" name="type" value="find">
													&nbsp;<b><?php echo $zl['594']?></b>
									      			<input class=input type="text" name="search" size="70" maxlength="25" value="<?php echo $ps_search?>" onFocus="id=className;" onblur="id=''" onkeyup="showResultMagneto2(this.value); return true;">
													<input type="checkbox" name="fullsearch" value="1" title="<?php echo $zl['496']?>">      	
									    			<font size=1><?php echo lcase($zl['496'])?></font>
									      			&nbsp;&nbsp;&nbsp;
									    			<input type="submit" class=inputb3 value="<?php echo $zl['267']?>" onMouseOver="id=className" onMouseOut="id=''"><br>
													<div id="magneto_search_top" align=left></div>
							      				</TD>
							      			</TR>					      									
							      		</TABLE>
							      	</td>
								</TR>
							</FORM>					      					
			      		</table>
			      		<br>
		    			<?php
		    		}       			
    				us_text($ps_katname);
    				us_text2($ps_subkatname);
    				$ps_constr="tbl_base where ISMODER=1 and (SUBKAT1=".$ps_type2." OR SUBKAT2=".$ps_type2." OR SUBKAT3=".$ps_type2.")";
    			}
    			if ($ps_type=="ismoder"){
    				//��������� ������
    				us_text($zl['48']);
    				$ps_constr="tbl_base where ISMODER=0 and ISDOPEDIT<>1";
    			}
    			if ($ps_type=="find"){
					//���� ������
		      		if (getconf("ISFINDTOP_2","VALUEINT")==1){
		      			?>
						<script>
							var xmlHttp;
							function showResultMagneto2(str){
								if (str.length==0){ 
									document.getElementById("magneto_search_top").innerHTML="";
									document.getElementById("magneto_search_top").style.display="none";
									return;
								}
								xmlHttp=GetXmlHttpObject();
								if (xmlHttp==null){
									//alert ("������� �� ������������ HTTP-Request");
									return;
								} 
								var url="index.php?type=new_pre";
								//url=url+"?search="+encodeURIComponent(str);
								url=url+"&search="+str;
								url=url+"&stest=���";
								url=url+"&randoms="+Math.random();
								xmlHttp.onreadystatechange=stateChangedMagneto2;
								xmlHttp.open("GET",url,true);
								xmlHttp.send(null);
							}
							function stateChangedMagneto2(){ 
								if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
									{ 
									document.getElementById("magneto_search_top").innerHTML=xmlHttp.responseText;
									document.getElementById("magneto_search_top").style.display="";
								} 
							}
						</script> 			
			      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
							<FORM name="frmfind" METHOD="send" ACTION="subkat.php">
				      			<TR class=f10>
					      			<?php
					      			//�����
					      			//� ���
			      					?>
				      				<td valign=top align=center>
							      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat>
							      			<TR class=f10 height=16>
							      				<td>
										      		<TABLE cellSpacing=0 cellPadding=0 width=100% border=0 class=table_kat_element height=100%>
										      			<TR class=f10 height=16>
										      				<td width=25 align=center>
							      								<img src="main/color/scheme/<?php echo $ps_color;?>/element_kat_icon.png" width=16 height=16>
							      							</TD>
										      				<td>
										      					<b><?php echo $zl['66']?></b>
							      							</TD>
							      						</TR>
							      					</TABLE>
							      				</TD>
							      			</TR>
											<TR height=30>
							      				<td class=f10 align=center>
									      			<input type="hidden" name="type" value="find">
													&nbsp;<b><?php echo $zl['594']?></b>
									      			<input class=input type="text" name="search" size="70" maxlength="25" value="<?php echo $ps_search?>" onFocus="id=className;" onblur="id=''" onkeyup="showResultMagneto2(this.value); return true;">
													<input type="checkbox" name="fullsearch" value="1" title="<?php echo $zl['496']?>">      	
									    			<font size=1><?php echo lcase($zl['496'])?></font>
									      			&nbsp;&nbsp;&nbsp;
									    			<input type="submit" class=inputb3 value="<?php echo $zl['267']?>" onMouseOver="id=className" onMouseOut="id=''"><br>
													<div id="magneto_search_top" align=left></div>
							      				</TD>
							      			</TR>					      									
							      		</TABLE>
							      	</td>
								</TR>
							</FORM>					      					
			      		</table>
			      		<br>
		    			<?php
		    		}       			
    				//�����
    				us_text($zl['66']);
    				$ps_search2=$ps_search;
    				if (requestdata("fullsearch")==1){
    					$ps_constr="tbl_base where ISMODER=1 and (NAZV like '%".$ps_search2."%' or OPIS like '%".$ps_search2."%' or DOPF1 like '%".$ps_search2."%'  or DOPF2 like '%".$ps_search2."%'  or DOPF3 like '%".$ps_search2."%'  or DOPF4 like '%".$ps_search2."%'  or DOPF5 like '%".$ps_search2."%')";
    				}else{
    					$ps_constr="tbl_base where ISMODER=1 and (NAZV like '%".$ps_search."%')";
    				}
    				//� �������� �������
    				us_text2($zl['497'].": ".recordcount_new($ps_constr));
    				//���� � �����������
    				if (requestdata("fullsearch")==1){
						$ps_constr3="tbl_persona where ISMODER=1 and (NAZV like '%".$ps_search2."%' or OPIS like '%".$ps_search2."%' or NAZVROD like '%".$ps_search2."%')";
					}else{
						$ps_constr3="tbl_persona where ISMODER=1 and (NAZV like '%".$ps_search2."%' or NAZVROD like '%".$ps_search2."%')";
					}
    				$pi_pers=recordcount_new($ps_constr3);
    				if ($pi_pers>0){
    					//������� � �����������
    					?>
    					<br>
    					<TABLE cellSpacing=3 class=table_int_table cellPadding=0 border=0 width=500>
    						<TR>
    							<TD class=f8b bgcolor="<?php echo $zcmas[5]?>">
    								<?php echo $zl['498']?>:
    							</TD>
    						</TR>
							<TR>
								<TD class=f8>
									<?php
									if (requestdata("fullsearch")==1){
										$rs_2 = mysql_query("select NAZV,CODE,NAZVROD from tbl_persona where ISMODER=1 and (NAZV like '%".$ps_search2."%' or OPIS like '%".$ps_search2."%' or NAZVROD like '%".$ps_search2."%')",$conn1);
									}else{
										$rs_2 = mysql_query("select NAZV,CODE,NAZVROD from tbl_persona where ISMODER=1 and (NAZV like '%".$ps_search2."%' or NAZVROD like '%".$ps_search2."%')",$conn1);
									}
										while (($rs=mysql_fetch_assoc($rs_2))!==false){
											$ps_pers=$rs['NAZV'];
											$ps_pers=str_replace($ps_search,"<b><u>".$ps_search."</u></b>",$ps_pers);
											$ps_persrod=$rs['NAZVROD'];
											$ps_persrod=str_replace($ps_search,"<b><u>".$ps_search."</u></b>",$ps_persrod);
											//����������� ����������
											?>
											&middot; <a href="persona.php?type=show&code=<?php echo $rs['CODE']?>" title="<?php echo $zl['363']?>"><?php echo $ps_pers?><?php if ($ps_persrod!='') echo '/'.$ps_persrod;?></a><br>
											<?php
										}
									mysql_free_result($rs_2);
									?>
								</TD>
							</TR>
						</TABLE>
    					<?php
    				}
    				

    				//��������� � ���
    				$ps_code1=$ps_usercode;
    				if ($ps_code1==0) $ps_code1=-1;
    				$rs_s2=mysql_query("insert into tbl_search (USERCODE,DATEADD,OPIS) values (".$ps_code1.",'".sqldatetime2(mktime())."','".$ps_search."')",$conn1);
    			}
    			if ($ps_type=="onmoderedit"){
    				if ($zright['DO_MODER']!=1 && $ps_type2!='') $ps_type2='';
    				if ($ps_type2!="all"){
    					us_text($zl['166']);//��������� ������
	    				$ps_constr="tbl_base where ISMODER=0 and ISDOPEDIT=1 and WHOADD=".$ps_usercode;
    				}else{
    					us_text($zl['53']);//������� �� ���������
	    				$ps_constr="tbl_base where ISMODER=0 and ISDOPEDIT=1";
    				}
    			}
    			if ($ps_type=="onmoder"){
    				//�� ���������
    				us_text($zl['54']);
    				$ps_constr="tbl_base where ISMODER=0 and ISDOPEDIT=0 and WHOADD=".$ps_usercode;
    			}
    			if ($ps_type=="mylink"){
    				//��� �������
    				us_text($zl['51']);
    				$ps_constr="tbl_base where ISMODER=1 and WHOADD=".$ps_usercode;
    			}
    			if ($ps_type=="lastnews"){
    				//����� �������
    				us_text($zl['167']);
					$rs_2=mysql_query("select LASTNEWS from tbl_user where CODE=".$ps_usercode,$conn1);
						$rs=mysql_fetch_array($rs_2);
						$pd1=$rs['LASTNEWS'];
					mysql_free_result($rs_2);
    				$ps_constr="tbl_base where ISMODER=1 and DATEMODER>'".$pd1."'";
    				if (recordcount_new($ps_constr)>0){
    					//�������� ��� �������������
	    				?>
	    				<b>:: <a href="subkat.php?type=setlastnews&type2=<?php echo mktime()?>"><?php echo $zl['169']?></b></a><br>
	    				<?php
	    			}else{
	    				//������ ������ ���
	    				echo '<br><b>'.$zl['178'].'</b>';
	    			}
    			}
    			if ($ps_type=="shownews"){
    				//������� �������
    				us_text($zl['44']);
    				$ps_constr="tbl_news";
    				if ($zright['DO_NEWS']==1){
    					//�������� �������
	    				?>
	    				<b>:: <a href="topic.php?type=newnews"><?php echo $zl['182']?></b></a><br>
	    				<?php
	    			}
    			}
    			echo '<br>';
    			$ps_perpage=getconf("PERPAGE","VALUESTR");;//�� ������� �� ��������
				$pi_count=recordcount_new($ps_constr);
				$pi3=ceil($pi_count/$ps_perpage);
				$pi4=($ps_page-1)*$ps_perpage;
    			if ($ps_type=="showsubkat"){
    				//������ ����������
    				$ps_sort2='DATEMODER';
    				if ($ps_sort=='' && $ps_desc=='') $ps_desc=1;
    				if ($ps_sort=="nazv") $ps_sort2="NAZV";
    				if ($ps_sort=="release") $ps_sort2="RELEASE2";
    				if ($ps_sort=="country") $ps_sort2="COUNTRY";
    				if ($ps_sort=="razmer") $ps_sort2="RAZMER";
    				if ($ps_sort=="votes") $ps_sort2="VOTES";
    				if ($ps_sort=="down") $ps_sort2="DOWN";
    				if ($ps_sort=="dopf1") $ps_sort2="DOPF1";
    				if ($ps_sort=="dopf2") $ps_sort2="DOPF2";
    				if ($ps_sort=="dopf3") $ps_sort2="DOPF3";
    				if ($ps_sort=="dopf4") $ps_sort2="DOPF4";
    				if ($ps_sort=="dopf5") $ps_sort2="DOPF5";
    				if ($ps_desc==2) $ps_desc='';
    				if ($ps_desc==1) $ps_sort2=$ps_sort2.' desc';
    				?>
    				<TABLE cellSpacing=1 cellPadding=0 border=0 width=100%>
    					<TR class=f9 valign=top>
    						<TD>
			    				<?php
			    				echo '<b>'.$zl['586'].':</b>';//����������
			    				//���� ����������
			    				//��������
			    				//��� �������
			    				//������
			    				//������
			    				//�������
			    				//���������� ����������
			    				?>
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>" <?php if ($ps_sort=='') echo 'class=linksorted';?>><?php echo $zl['280']?></a>,
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=nazv" <?php if ($ps_sort=='nazv') echo 'class=linksorted';?>><?php echo lcase($zl['284'])?></a>,
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=release" <?php if ($ps_sort=='release') echo 'class=linksorted';?>><?php echo lcase($zl['293'])?></a>,
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=country" <?php if ($ps_sort=='country') echo 'class=linksorted';?>><?php echo lcase($zl['294'])?></a>,
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=razmer" <?php if ($ps_sort=='razmer') echo 'class=linksorted';?>><?php echo $zl['590']?></a>,
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=votes" <?php if ($ps_sort=='votes') echo 'class=linksorted';?>><?php echo $zl['174']?></a>,
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=down" <?php if ($ps_sort=='down') echo 'class=linksorted';?>><?php echo lcase($zl['591'])?></a>
			    				<?php
			    				//���.����
			    				if (getconf("ISSORTDOPF","VALUEINT")==1){
				    				$pb1=0;
				    				if (recordcount_new("tbl_dopf where KATCODE=".$ps_kat)>0){
										$rs2_2=mysql_query("select * from tbl_dopf where KATCODE=".$ps_kat,$conn1);
											$rs2=mysql_fetch_array($rs2_2);
											echo '<br>';
											if ($rs2['DOPF1']!=''){
												?>
												<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=dopf1" <?php if ($ps_sort=='dopf1') echo 'class=linksorted';?>><?php echo lcase($rs2['DOPF1'])?></a><?php
												$pb1=1;
											}
											if ($rs2['DOPF2']!=''){
												if ($pb1==1) echo ', ';
												$pb1=1;
												?>
												<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=dopf2" <?php if ($ps_sort=='dopf2') echo 'class=linksorted';?>><?php echo lcase($rs2['DOPF2'])?></a><?php
											}
											if ($rs2['DOPF3']!=''){
												if ($pb1==1) echo ', ';
												$pb1=1;
												?>
												<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=dopf3" <?php if ($ps_sort=='dopf3') echo 'class=linksorted';?>><?php echo lcase($rs2['DOPF3'])?></a><?php
											}
											if ($rs2['DOPF4']!=''){
												if ($pb1==1) echo ', ';
												$pb1=1;
												?>
												<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=dopf4" <?php if ($ps_sort=='dopf4') echo 'class=linksorted';?>><?php echo lcase($rs2['DOPF4'])?></a><?php
											}
											if ($rs2['DOPF5']!=''){
												if ($pb1==1) echo ', ';
												$pb1=1;
												?>
												<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&desc=<?php echo $ps_desc?>&sort=dopf5" <?php if ($ps_sort=='dopf5') echo 'class=linksorted';?>><?php echo lcase($rs2['DOPF5'])?></a><?php
											}
										mysql_free_result($rs2_2);			    				
									}
								}
			    				?>
			    			</TD>
			    			<TD>
			    				<?php
			    				echo '<b>'.$zl['587'].':</b>';//�����
			    				//�� �����������
			    				//�� ��������
			    				?>
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&sort=<?php echo $ps_sort?>&desc=2" <?php if ($ps_desc=='') echo 'class=linksorted';?>><?php echo $zl['588']?></a>,
			    				<a href="subkat.php?type=showsubkat&type2=<?php echo $ps_type2?>&sort=<?php echo $ps_sort?>&desc=1" <?php if ($ps_desc=='1') echo 'class=linksorted';?>><?php echo $zl['589']?></a>
			    			</TD>
			    		</TR>
			    	</TABLE>
			    	<?php
    				$ps_constr2="select * from tbl_base where ISMODER=1 and (SUBKAT1=".$ps_type2." OR SUBKAT2=".$ps_type2." OR SUBKAT3=".$ps_type2.") order by ".$ps_sort2." limit ".$pi4.",".$ps_perpage;
    			}
    			if ($ps_type=="ismoder"){
    				$ps_constr2="select * from tbl_base where ISMODER=0 and ISDOPEDIT<>1 order by DATEADD limit ".$pi4.",".$ps_perpage;
    			}
    			if ($ps_type=="find"){
    				if (left_1($ps_search,1)=="_" || left_1($ps_search,1)=="*" || requestdata("fullsearch")==1){    				
    					$ps_search2=str_replace("*","",$ps_search);
    					$ps_search2=str_replace("_","",$ps_search2);    					
    					$ps_constr2="select * from tbl_base where ISMODER=1 and (NAZV like '%".$ps_search2."%' or OPIS like '%".$ps_search2."%' or DOPF1 like '%".$ps_search2."%'  or DOPF2 like '%".$ps_search2."%'  or DOPF3 like '%".$ps_search2."%'  or DOPF4 like '%".$ps_search2."%'  or DOPF5 like '%".$ps_search2."%') order by NAZV limit ".$pi4.",".$ps_perpage;
					}else{
    					$ps_constr2="select * from tbl_base where ISMODER=1 and (NAZV like '%".$ps_search."%') order by NAZV limit ".$pi4.",".$ps_perpage;
					}
    			}
    			if ($ps_type=="onmoderedit"){
    				if ($ps_type2!="all"){
    					$ps_constr2="select * from tbl_base where ISMODER=0 and ISDOPEDIT=1 and WHOADD=".$ps_usercode." order by DATEADD limit ".$pi4.",".$ps_perpage;
    				}else{
    					$ps_constr2="select * from tbl_base where ISMODER=0 and ISDOPEDIT=1 order by DATEADD limit ".$pi4.",".$ps_perpage;
    				}
    			}
    			if ($ps_type=="onmoder"){
    				$ps_constr2="select * from tbl_base where ISMODER=0 and ISDOPEDIT=0 and WHOADD=".$ps_usercode." order by DATEADD limit ".$pi4.",".$ps_perpage;
    			}
    			if ($ps_type=="mylink"){
    				$ps_constr2="select * from tbl_base where ISMODER=1 and WHOADD=".$ps_usercode." order by DATEADD desc limit ".$pi4.",".$ps_perpage;
    			}
    			if ($ps_type=="lastnews"){
    				$ps_constr2="select * from tbl_base where ISMODER=1 and DATEMODER>'".$pd1."' order by DATEMODER limit ".$pi4.",".$ps_perpage;
    			}
    			if ($ps_type=="shownews"){
    				$ps_constr2="select * from tbl_news order by DATEADD desc limit ".$pi4.",".$ps_perpage;
    			}
    			if ($pi_count>0){
					if ($pi_count>$ps_perpage){
						?>
						<form method="send" name="frmadd" action="subkat.php">
							<?php
							if ($ps_type2!=""){
								?>
								<input type="hidden" name="type2" value="<?php echo $ps_type2?>">
								<?php
							}
							if ($ps_search!=""){
								?>
								<input type="hidden" name="search" value="<?php echo $ps_search?>">
								<?php
							}
							//��������:
							?>
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="sort" value="<?php echo $ps_sort?>">
							<input type="hidden" name="desc" value="<?php echo $ps_desc?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php 
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					?>
		      		<TABLE cellSpacing=1 cellPadding=5 class=table_int_table width=100% border="0px" bgcolor="<?php echo $zcmas[2]?>">
		      			<?php
						//������� ����������
						$pi1=$pi4;
						$rs_2 = mysql_query($ps_constr2,$conn1);
							if ($ps_type=="shownews"){
								showsubkat_news();
							}else{
								showsubkat();
							}
						mysql_free_result($rs_2);					
		    			?>
		    		</TABLE>
		    		<br>
		    		<?php
					if ($pi_count>$ps_perpage){
						?>
						<form method="send" name="frmadd1" action="subkat.php">
							<?php
							if ($ps_type2!=""){
								?>
								<input type="hidden" name="type2" value="<?php echo $ps_type2?>">
								<?php
							}
							if ($ps_search!=""){
								?>
								<input type="hidden" name="search" value="<?php echo $ps_search?>">
								<?php
							}
							//��������:
							?>
							<input type="hidden" name="sort" value="<?php echo $ps_sort?>">
							<input type="hidden" name="type" value="<?php echo $ps_type?>">
							<input type="hidden" name="desc" value="<?php echo $ps_desc?>">
							<b><?php echo $zl['170']?></b> <select name="page" onChange="autoReload1();">
								<?php
								for ($pi1=1; $pi1<=$pi3;$pi1++)
									{						
									?>
									<option value="<?php echo $pi1?>" <?php if ($ps_page==$pi1) echo "selected";?>><?php echo $pi1?></option>
									<?php
								}
								?>
							</select>
							&nbsp;<?php
							//�������
							inputstyle($zl['171']);
							?>
						</form>
						<?php
					}
					//������� ������
					?>
					<b>:: <a href="#ontop"><?php echo $zl['420']?></b></a><br>
					<br>
					<?php
    			}else{
    				//������ ������ ���
    				echo '<br><b>'.$zl['178'].'</b>';    				
    			}				
			}
			?>
    	</TD>
		<TD width=20>&nbsp;
			
		</TD>	      									
	</TR>
</TABLE>
<?php 
if ($ps_type=="showsubkat") $ps_popular="subkat";
if ($ps_style=="") require_once('inc_down.php');
mysql_close($conn1);
?>	
</body>
</html>
