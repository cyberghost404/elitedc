<?php
session_start();
if(function_exists('imagetypes')){
}else{
	echo 'GD is not loaded';
}
$pi1=imagecreate(70, 20);
$pi2 = imagecolorallocate($pi1, 0, 0, 0);
$pi3 = imagecolorallocate($pi1, 255, 0, 0);
$ps1=$_SESSION['number'];
imagestring ($pi1, 5, 5, 2, $ps1, imagecolorallocate($pi1, 73, 126, 194));
imagegif($pi1);
imagedestroy($pi1);
?>