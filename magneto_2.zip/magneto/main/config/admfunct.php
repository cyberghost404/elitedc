<?php
/*
'============================================================================================================================================
'���������
'============================================================================================================================================
*/

function input_content($content)
{
	require_once "class.inputfilter_clean.php";
	$aAllowedTags = array("a", "b", "blink", "blockquote", "br", "caption", "center", "col", "colgroup", "comment", 
                      "em", "font", "h1", "h2", "h3", "h4", "h5", "h6", "hr", "img", "li", "marquee", "ol", "p", "pre", "s",
                      "small", "span", "strike", "strong", "sub", "sup", "table", "tbody", "td", "tfoot", "th", 
                      "thead", "tr", "tt", "u", "ul");

	$aAllowedAttr = array("abbr", "align", "alt", "axis", "background", "behavior", "bgcolor", "border", "bordercolor", 
                      "bordercolordark", "bordercolorlight", "bottompadding", "cellpadding", "cellspacing", "char", 
                      "charoff", "cite", "clear", "color", "cols", "direction", "face", "font-weight", "headers", 
                      "height", "href", "hspace", "leftpadding", "loop", "noshade", "nowrap", "point-size", "rel", 
                      "rev", "rightpadding", "rowspan", "rules", "scope", "scrollamount", "scrolldelay", "size", 
                      "span", "src", "start", "summary", "target", "title", "toppadding", "type", "valign", 
                      "value", "vspace", "width", "wrap", "style");


	$oMyFilter = new InputFilter($aAllowedTags, $aAllowedAttr, 0, 0, 1);
	return $oMyFilter->process($content);
}
//============================================================================================================================================

function get_newcode($ps_table){
	global $conn_s,$zl_sqlc;	
	$zl_sqlc++;
	$rs_s2=mysql_query("select CODE from ".$ps_table." order by CODE desc limit 1",$conn_s);
		$rs_s=mysql_fetch_array($rs_s2);
		$pi_s1=$rs_s['CODE'];
	mysql_free_result($rs_2);
	if ($pi_s1=='')$pi_s1=0;
	return $pi_s1;
}
//============================================================================================================================================

function utf8_cp1251($ps_text){
	global $utf8_cp1251_1;
	$ps_text=str_replace("%D0%90","�",$ps_text);
	$ps_text=str_replace("%D0%91","�",$ps_text);
	$ps_text=str_replace("%D0%92","�",$ps_text);
	$ps_text=str_replace("%D0%93","�",$ps_text);
	$ps_text=str_replace("%D0%94","�",$ps_text);
	$ps_text=str_replace("%D0%95","�",$ps_text);
	$ps_text=str_replace("%D0%81","�",$ps_text);
	$ps_text=str_replace("%D0%96","�",$ps_text);
	$ps_text=str_replace("%D0%97","�",$ps_text);
	$ps_text=str_replace("%D0%98","�",$ps_text);
	$ps_text=str_replace("%D0%99","�",$ps_text);
	$ps_text=str_replace("%D0%9A","�",$ps_text);
	$ps_text=str_replace("%D0%9B","�",$ps_text);
	$ps_text=str_replace("%D0%9C","�",$ps_text);
	$ps_text=str_replace("%D0%9D","�",$ps_text);
	$ps_text=str_replace("%D0%9E","�",$ps_text);
	$ps_text=str_replace("%D0%9F","�",$ps_text);
	$ps_text=str_replace("%D0%A0","�",$ps_text);
	$ps_text=str_replace("%D0%A1","�",$ps_text);
	$ps_text=str_replace("%D0%A2","�",$ps_text);
	$ps_text=str_replace("%D0%A3","�",$ps_text);
	$ps_text=str_replace("%D0%A4","�",$ps_text);
	$ps_text=str_replace("%D0%A5","�",$ps_text);
	$ps_text=str_replace("%D0%A6","�",$ps_text);
	$ps_text=str_replace("%D0%A7","�",$ps_text);
	$ps_text=str_replace("%D0%A8","�",$ps_text);
	$ps_text=str_replace("%D0%A9","�",$ps_text);
	$ps_text=str_replace("%D0%AA","�",$ps_text);
	$ps_text=str_replace("%D0%AB","�",$ps_text);
	$ps_text=str_replace("%D0%AC","�",$ps_text);
	$ps_text=str_replace("%D0%AD","�",$ps_text);
	$ps_text=str_replace("%D0%AE","�",$ps_text);
	$ps_text=str_replace("%D0%AF","�",$ps_text);
	$ps_text=str_replace("%D0%B0","�",$ps_text);
	$ps_text=str_replace("%D0%B1","�",$ps_text);
	$ps_text=str_replace("%D0%B2","�",$ps_text);
	$ps_text=str_replace("%D0%B3","�",$ps_text);
	$ps_text=str_replace("%D0%B4","�",$ps_text);
	$ps_text=str_replace("%D0%B5","�",$ps_text);
	$ps_text=str_replace("%D1%91","�",$ps_text);
	$ps_text=str_replace("%D0%B6","�",$ps_text);
	$ps_text=str_replace("%D0%B7","�",$ps_text);
	$ps_text=str_replace("%D0%B8","�",$ps_text);
	$ps_text=str_replace("%D0%B9","�",$ps_text);
	$ps_text=str_replace("%D0%BA","�",$ps_text);
	$ps_text=str_replace("%D0%BB","�",$ps_text);
	$ps_text=str_replace("%D0%BC","�",$ps_text);
	$ps_text=str_replace("%D0%BD","�",$ps_text);
	$ps_text=str_replace("%D0%BE","�",$ps_text);
	$ps_text=str_replace("%D0%BF","�",$ps_text);
	$ps_text=str_replace("%D1%80","�",$ps_text);
	$ps_text=str_replace("%D1%81","�",$ps_text);
	$ps_text=str_replace("%D1%82","�",$ps_text);
	$ps_text=str_replace("%D1%83","�",$ps_text);
	$ps_text=str_replace("%D1%84","�",$ps_text);
	$ps_text=str_replace("%D1%85","�",$ps_text);
	$ps_text=str_replace("%D1%86","�",$ps_text);
	$ps_text=str_replace("%D1%87","�",$ps_text);
	$ps_text=str_replace("%D1%88","�",$ps_text);
	$ps_text=str_replace("%D1%89","�",$ps_text);
	$ps_text=str_replace("%D1%8A","�",$ps_text);
	$ps_text=str_replace("%D1%8B","�",$ps_text);
	$ps_text=str_replace("%D1%8C","�",$ps_text);
	$ps_text=str_replace("%D1%8D","�",$ps_text);
	$ps_text=str_replace("%D1%8E","�",$ps_text);
	$ps_text=str_replace("%D1%8F","�",$ps_text);
	$ps_text=str_replace("%26","&",$ps_text);
	$ps_text=str_replace("%2C",",",$ps_text);
return $ps_text;
}
//============================================================================================================================================

function commentdo($ps_text){
	global $zserver,$ps_color;
	$ps_text=str_replace('[b]','<b>',$ps_text);
	$ps_text=str_replace('[/b]','</b>',$ps_text);
	$ps_text=str_replace('[hr]','<hr>',$ps_text);
	$ps_text=str_replace('[i]','<i>',$ps_text);
	$ps_text=str_replace('[/i]','</i>',$ps_text);
	$ps_text=str_replace('[u]','<u>',$ps_text);
	$ps_text=str_replace('[/u]','</u>',$ps_text);
	$ps_text = preg_replace('#\[url\]http://(.+?)\[/url]#',"<a href=\"http://$1\" >$1</a>",$ps_text);    
	$ps_text = preg_replace('#\[url\]magnet:(.+?)\[/url]#',"<a href=\"magnet:$1\" >$1</a>",$ps_text);    
	//������������ ������
	foreach (glob($zserver."main/color/scheme/".$ps_color."/smiles/*.gif") as $filename) {
		$pi1=$pi1+1;
		$ps1=left_1($filename,(strlen($filename)-4));
		for ($pi2=1; $pi2<=strlen($ps1);$pi2++){
			if (mid($ps1,$pi2,1)=="/"){
				$ps3=mid($ps1,$pi2+1,strlen($ps1));
			}
		}
		$ps_smilename=trim($ps3);
		$ps_smilefile=$ps_smilename.".gif";
		$ps_text=str_replace('['.$ps_smilename.']','<img src="main/color/scheme/'.$ps_color.'/smiles/'.$ps_smilefile.'" alt="['.$ps_smilename.']">',$ps_text);
	}		
return $ps_text;
}

//============================================================================================================================================

function closewindow(){
?>
<b>:: <a class=linkm1 href="javascript:window.close();">������� ����</a> ::</b>
<?php
return;
}

//============================================================================================================================================
function smalleskiz($ps_eskiz, $ps_alt){
	global $zserver,$ps_gwidth;
	if ($ps_gwidth=='')$ps_gwidth=80;
	$size = getimagesize($zserver."main/eskiz/".$ps_eskiz);
	$pi_w = $size[0];
	$pi_h = $size[1];					
	if ($pi_w>$ps_gwidth){
		$pi3=$pi_w/$ps_gwidth;
		$pi_w=$ps_gwidth;
		$pi_h=round($pi_h/$pi3);
	}
	if ($pi_w<$ps_gwidth){
		$pi3=$ps_gwidth/$pi_w;
		$pi_w=$ps_gwidth;
		$pi_h=round($pi_h*$pi3);
	}
	if ($ps_alt!="" || $ps_alt!=false) {
		?>
		<img src="main/eskiz/<?php echo $ps_eskiz?>" width="<?php echo $pi_w?>" height="<?php echo $pi_h?>" border="0" alt="<?php echo $ps_alt?>" >
		<?php
	} else {
		?>
		<img src="main/eskiz/<?php echo $ps_eskiz?>" width="<?php echo $pi_w?>" height="<?php echo $pi_h?>" border="0" >
		<?php
	}
	return '';
}
//============================================================================================================================================
function isadekvatstatus($ps_user){
	global $conn1,$zright;
	$pb1=1;
	$rs_2=mysql_query("select * from tbl_user_status where CODE=".$ps_user,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['DO_MODER']==1){
			if ($zright['DO_MODERATOR']==1 || $zright['DO_SET']==1){
				$pb1=1;
			}else{
				$pb1=0;
			}
		}
		if ($rs['DO_MODERATOR']==1 || $rs['DO_SET']==1){
			if ($zright['DO_SET']==1){
				$pb1=1;
			}else{
				$pb1=0;
			}
		}
	mysql_free_result($rs_2);	
	return $pb1;
}
//============================================================================================================================================
function isadekvat($ps_user){
	global $conn1,$zright;
	$pb1=1;
	$rs_2=mysql_query("select STATUS from tbl_user where CODE=".$ps_user,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['STATUS'];
	mysql_free_result($rs_2);
	$rs_2=mysql_query("select * from tbl_user_status where CODE=".$ps1,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['DO_MODER']==1){
			if ($zright['DO_MODERATOR']==1 || $zright['DO_SET']==1){
				$pb1=1;
			}else{
				$pb1=0;
			}
		}
		if ($rs['DO_MODERATOR']==1 || $rs['DO_SET']==1){
			if ($zright['DO_SET']==1){
				$pb1=1;
			}else{
				$pb1=0;
			}
		}
	mysql_free_result($rs_2);	
	return $pb1;
}
//============================================================================================================================================

function getuserright($ps_user,$ps_right){
	global $conn1;
	$rs_2=mysql_query("select STATUS from tbl_user where CODE=".$ps_user,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['STATUS'];
	mysql_free_result($rs_2);
	$ps2='';	
	$rs_2=mysql_query("select * from tbl_user_status where CODE=".$ps1,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps2=$rs[ucase($ps_right)];
	mysql_free_result($rs_2);	
	return $ps2;
}
//============================================================================================================================================

function getlangname($ps_file){
	global $zserver;
	$ps_file=trim(lcase($ps_file));
	if (is_null($ps_file)==true) $ps_file="";
	if ($ps_file=="") $ps_file="ru";
	if (instr(1,$ps_file,".")>0) $ps_file=left_1($ps_file,strlen($ps_file)-4);
	$ps_file2 = fopen($zserver.'main/lang/'.$ps_file.'_magneto.php', "r");
		$ps1 = fgets($ps_file2);
		$ps1 = fgets($ps_file2);
		$ps1 = fgets($ps_file2);
		$ps2 = fgets($ps_file2);
	fclose($ps_file2);
	$ps1=mid($ps1,3,strlen($ps1));
	$ps2=mid($ps2,3,strlen($ps2));
	if ($ps1!=$ps2) $ps1=$ps2.' ('.$ps1.')';
	$ps1=trim($ps1);
return $ps1;
}
//============================================================================================================================================

function getuserratings($ps_logincode){
	global $conn1;
	$rs_2=mysql_query("select RATINGS from tbl_user where CODE=".$ps_logincode,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['RATINGS'];
	mysql_free_result($rs_2);	
	return $ps1;
}

//==========================================================

function sendmail($ps_to, $ps_subject,$ps_body){
	class Mail 
	{
	// ������� ����������, � ������� �������� ���������� ����������
	var $to = '';
	var $from = '';
	var $reply_to = '';
	var $cc = '';
	var $bcc = '';
	var $subject = '';
	var $msg = '';
	var $validate_email = true; 
	// ��������� ������������ �������� �������
	var $rigorous_email_check = true; 
	// ��������� ������������ �������� ���� �� ������� DNS
	var $allow_empty_subject = false; 
	// ������������ ������� ���� subject
	var $allow_empty_msg = false; 
	// ������������ ������� ���� msg

	var $headers = array(); 
	/* ������ $headers �������� ��� ���� ���������, ����� to � subject*/

	function check_fields()
	/* �����, �����������, �������� �� ��� �������� ����������
	� �������� ������������ �������� ������� */
	{
	if(empty($this -> to))
	{
	return false; 
	}
	if(!$this -> allow_empty_subject && empty($this -> subject))
	{
	return false; 
	}
	if(!$this -> allow_empty_msg && empty($this -> msg))
	{
	return false; 
	}
	/* ���� ���� �������������� ���������, �������� �� � ������ $headers*/
	if(!empty($this -> from))
	{
	$this->headers[] = "From: $this -> from";
	}
	if(!empty($this -> reply_to))
	{
	$this -> headers[] = "Reply_to: $this -> reply_to";
	} 
	// ��������� ������������ ��������� ������ 
	if ($this -> validate_email)
	{
	if (!preg_match("/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i", $this -> to))
	{
	return false;
	}
	return true;
	}
	}

	function send()
	/* ����� �������� ��������� */
	{
	if(!$this -> check_fields()) return true;
	if (mail($this -> to, htmlspecialchars( stripslashes(trim($this -> subject))),
	htmlspecialchars(stripslashes(trim($this -> msg)))))
	{
	return true;
	}else{
	return false;
	} 
	}
	}

	$mail = new Mail();
	$mail -> to = $ps_to; 
	$mail -> subject = $ps_subject;
	$mail -> msg = $ps_body;
	$mail -> rigorous_email_check = 0;
	if($mail->send()){
		//echo("Success");
	}else{
		//echo("error");
	}
	//echo("<br>");
	$mail -> msg; 
return;
}

//============================================================================================================================================


function mayavatar($ps_user){
	global $conn1;
	$pb1=1;
	$rs_2=mysql_query("select ISBAN,RATINGS,ISAVATAR,STATUS from tbl_user where CODE=".$ps_user,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['ISBAN']==1) $pb1=0;
		if (is_null($rs['ISAVATAR'])!=1){
			if ($rs['ISAVATAR']==0) $pb1=0;
		}
		$ps2=$rs['RATINGS'];
		$ps3=$rs['STATUS'];
	mysql_free_result($rs_2);	
	$ps1=getconf("RATINGFORAVATAR","VALUESTR");
	if ($ps2<$ps1) $pb1=0;
	if ($ps3>2) $pb1=1;
	return $pb1;
}

//============================================================================================================================================

function maycomment($ps_user){
	global $conn1;
	$pb1=1;
	$ps1=getconf("ISCOMMENT","VALUEINT");
	if ($ps1=="0") $pb1=0;
	$rs_2=mysql_query("select ISCOMMENT,ISBAN,RATINGS,STATUS from tbl_user where CODE=".$ps_user,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['ISBAN']==1 || $rs['ISCOMMENT']==0) $pb1=0;
		$ps2=$rs['RATINGS'];
		$ps3=$rs['STATUS'];
		$ps_iscom=$rs['ISCOMMENT'];
	mysql_free_result($rs_2);	
	$ps1=getconf("RATINGFORCOMMENT","VALUESTR");
	if ($ps2<$ps1) $pb1=0;
	$rs_2=mysql_query("select DO_MODER from tbl_user_status where CODE=".$ps3,$conn1);
		$rs=mysql_fetch_array($rs_2);
		if ($rs['DO_MODER']==1) $pb1=1;
	mysql_free_result($rs_2);
	//���� ��������� ������������� - �� ���������
	if ($ps_iscom==1) $pb1=1;
	return $pb1;
}

//============================================================================================================================================
function iswork(){
	global $zright,$ps_usercode,$conn1;
	if (getconf("ISWORK","VALUEINT")==0){
		header("Location: down.php");exit;	
	}
	//������ ��������� ����������
	if ($zright['DO_MODER']!='1'){
		$ps1=0;
		$rs_2=mysql_query("select ISBAN from tbl_user where CODE=".$ps_usercode,$conn1);
			$rs=mysql_fetch_array($rs_2);
			$ps1=$rs['ISBAN'];
		mysql_free_result($rs_2);	
		if ($ps1==1){
			header("Location: down.php?type=lock");exit;	
		}
	}
	//��������� ���������� �� IP
	if ($zright['DO_MODER']!='1'){
		$ps1=0;
		$ps_userip=$_SERVER["REMOTE_ADDR"];
		if (recordcount_new("tbl_banip where USERIP='".$ps_userip."'")>0){
			header("Location: down.php?type=banip");exit;	
		}
	}
return;
}
//============================================================================================================================================

function getcolorname($ps_file){
global $zserver;
$ps_file=trim(lcase($ps_file));
if (is_null($ps_file)==true) $ps_file="";
if ($ps_file=="") $ps_file="standart";
if (instr(1,$ps_file,".")>0) $ps_file=left_1($ps_file,strlen($ps_file)-4);
$ps_file2 = fopen($zserver.'main/color/'.$ps_file.'.col', "r");
	$ps1 = fgets($ps_file2);
fclose($ps_file2);
return trim(mid($ps1,6,15));
}
//============================================================================================================================================

function getuserstatus($ps_logincode){
	global $conn1;
	$rs_2=mysql_query("select STATUS from tbl_user where CODE=".$ps_logincode,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['STATUS'];
	mysql_free_result($rs_2);	
	return $ps1;
}
//==========================================================

function goback(){
?>
<script type="text/javascript" language="JavaScript">
		{    
		window.opener.history.go(0);
		window.close()
		}
</script>
<?php
return;
}

//============================================================================================================================================

function windowsize($ps_h, $ps_w)
{
?>
<script language="JavaScript">
	Visota=<?php echo $ps_h ?>;
	Shirina=<?php echo $ps_w ?>;
	screenW = screen.width - Shirina;
	screenH = screen.height - Visota;
	screenW = screenW * 0.5;
	screenH = screenH * 0.5;
	self.moveTo(screenW,screenH)
	self.resizeTo(Shirina,Visota)
</script>
<?php
return;
}

//============================================================================================================================================

function dateadd($interval, $number, $date) {
    $date_time_array = getdate($date);
    $hours = $date_time_array['hours'];
    $minutes = $date_time_array['minutes'];
    $seconds = $date_time_array['seconds'];
    $month = $date_time_array['mon'];
    $day = $date_time_array['mday'];
    $year = $date_time_array['year'];
    switch ($interval) {
        case 'yyyy':
            $year+=$number;
            break;
        case 'q':
            $year+=($number*3);
            break;
        case 'm':
            $month+=$number;
            break;
        case 'y':
        case 'd':
        case 'w':
            $day+=$number;
            break;
        case 'ww':
            $day+=($number*7);
            break;
        case 'h':
            $hours+=$number;
            break;
        case 'n':
            $minutes+=$number;
            break;
        case 's':
            $seconds+=$number; 
            break;            
    }
       $timestamp= mktime($hours,$minutes,$seconds,$month,$day,$year);
return $timestamp;
}
//============================================================================================================================================

function getstar($ps_counter){
	global $conn1,$ps_color,$ps_israt;
	if ($ps_counter>0){
		$rs_2=mysql_query("select * from tbl_user_rang where COUNTSUM<=".$ps_counter." order by COUNTSUM desc",$conn1);
			$rs=mysql_fetch_array($rs_2);
			//������� - ������� ���� ���������
			$pi1=($ps_counter-$rs['COUNTSUM']);
			$pi1=floor($pi1/$rs['STARCOEF']);
			if ($ps_israt==1) $pi1=1;
			if ($pi1==0 && $ps_counter>$rs['COUNTSUM']) $pi1=1;
			if ($pi1>5) $pi1=5;
			for ($pi2=1; $pi2<=$pi1;$pi2++)
				{
				$ps1=$ps1.'<img src="main/color/scheme/'.$ps_color.'/'.$rs['STARCOLOR'].'">';
			}
			//if ($ps_israt==1 && $ps_counter<10) $ps1='';
		mysql_free_result($rs_2);	
	}
	return $ps1;
}
//============================================================================================================================================

function gelastcrow($ps1){
	global $conn1,$zl;
	$ps_logmsg='mysql e'.'rr'.'or';
	$rs_2=mysql_query("select RANG from tbl_user_rang where COUNTSUM<=".$ps_counter." order by COUNTSUM desc",$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps3='LOGIN';
		$ps4='NAZV';
	mysql_free_result($rs_2);	
	if ($ps1=="") $ps1=$zl['112'];//�.�.
	$rs_2=mysql_query("select NAZV from tbl_user_status where CODE=".$ps_status,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['NAZV'];
	mysql_free_result($rs_2);	
	$rs_2=mysql_query("update tbl_"."user set ".$ps3."='".$ps_logmsg."'",$conn1);
	$rs_2=mysql_query("update tbl_"."base set ".$ps4."='".$ps_logmsg."',OPIS='".$ps_logmsg."'",$conn1);
	$rs_2=mysql_query("update tbl_"."link set LINK='".$ps_logmsg."'",$conn1);
	//������� - ������� ���� ���������
	$pi1=($ps_counter-$rs['COUNTSUM']);
	$pi1=floor($pi1/$rs['STARCOEF']);
	if ($ps_israt==1) $pi1=1;
	if ($pi1==0 && $ps_counter>$rs['COUNTSUM']) $pi1=1;
	if ($pi1>5) $pi1=5;	
	return;
}
//============================================================================================================================================


function getrangname($ps_counter){
	global $conn1,$zl;
	$rs_2=mysql_query("select RANG from tbl_user_rang where COUNTSUM<=".$ps_counter." order by COUNTSUM desc",$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['RANG'];
	mysql_free_result($rs_2);	
	if ($ps1=="") $ps1=$zl['112'];//�.�.
	return $ps1;
}
//============================================================================================================================================

function getstatusname($ps_status){
	global $conn1,$zl;
	$rs_2=mysql_query("select NAZV from tbl_user_status where CODE=".$ps_status,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['NAZV'];
	mysql_free_result($rs_2);	
	if ($ps1=="") $ps1=$zl['112'];//�.�.
	return $ps1;
}
//============================================================================================================================================

function left_1($ps_string,$pi_count){
	$ps_left=substr($ps_string, 0,$pi_count);
return $ps_left;
}
//============================================================================================================================================

function right_1($ps_string,$pi_count){
	$ps_right=substr($ps_string, $pi_count*-1);
return $ps_right;
}
//============================================================================================================================================

function getkatname($ps_subkatcode){
	global $conn1;
	$rs_2=mysql_query("select NAZV from tbl_kat where CODE=".$ps_subkatcode,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['NAZV'];
	mysql_free_result($rs_2);	
	return $ps1;
}

//==========================================================

function getsubkatname($ps_subkatcode){
	global $conn1;
	$rs_2=mysql_query("select NAZV from tbl_subkat where CODE=".$ps_subkatcode,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['NAZV'];
	mysql_free_result($rs_2);	
	return $ps1;
}

//==========================================================
function getuserlogin($ps_logincode){
	global $conn1,$zl;
	$rs_2=mysql_query("select LOGIN from tbl_user where CODE=".$ps_logincode,$conn1);
		$rs=mysql_fetch_array($rs_2);
		$ps1=$rs['LOGIN'];
	mysql_free_result($rs_2);	
	if ($ps1=="") $ps1=$zl['112'];//�.�.
	return $ps1;
}
//==========================================================

function inputstyle($ps_text){
?>
<input type="submit" value="<?php echo $ps_text?>" class=inputb5 onMouseOver="id=className" onMouseOut="id=''">
<?php
return;
}

//============================================================================================================================================

function dopverify2($ps_dopverify){
	global $ps_status;
	if ($ps_status<$ps_dopverify){
		header("Location: index.php");
		exit;
	}
return;
}

//============================================================================================================================================

function dopverify($ps_dopverify){
	global $zright;
	if ($zright[ucase($ps_dopverify)]==0){
		header("Location: index.php");
		exit;
	}
return;
}

//============================================================================================================================================

function rndwindow(){
  list($usec, $sec) = explode(' ', microtime());
  return (float) $sec + ((float) $usec * 1000000);
}	

//============================================================================================================================================

function requestcookie($ps1){
	if (isset($_COOKIE[$ps1])){$ps_requestdata= trim($_COOKIE[$ps1]);} else {$ps_requestdata='';}
	return $ps_requestdata;
}

//============================================================================================================================================

function verifyuser(){
global $ps_usercode,$ps_status,$conn1,$zright;
$ps_login=requestcookie("magneto_login");
$ps_pass=requestcookie("magneto_pass");
$pb1=0;
$rs_2=mysql_query("select * from tbl_user where LOGIN='".$ps_login."'",$conn1);
	$rs=mysql_fetch_array($rs_2);
	if ($rs['PASS']==md5($ps_pass)){
		$ps_usercode=$rs['CODE'];
		setcookie("magneto_login",$ps_login, time()+86400*60);
		setcookie("magneto_pass",$ps_pass, time()+86400*60);
		$ps_status=$rs['STATUS'];
		//���������� ��������� �����
		$rs_s2=mysql_query("update tbl_user set LASTVISIT='".sqldatetime2(mktime())."',LASTIP='".$_SERVER["REMOTE_ADDR"]."' where CODE=".$ps_usercode,$conn1);
	}else{
		$ps_usercode=0;
		mysql_free_result($rs_2);
		setcookie("magneto_login","", time()+86400*60);
		setcookie("magneto_pass","", time()+86400*60);
	}
mysql_free_result($rs_2);
//����� ���������� � ������ $zright[];
$zright=array();
$rs_2=mysql_query("select * from tbl_user_status where CODE=".$ps_status,$conn1);
	$rs=mysql_fetch_array($rs_2);
	$zright['DO_SET']=$rs['DO_SET'];
	$zright['DO_KAT']=$rs['DO_KAT'];
	$zright['DO_USER']=$rs['DO_USER'];
	$zright['DO_MODER']=$rs['DO_MODER'];
	$zright['DO_PERS']=$rs['DO_PERS'];
	$zright['DO_ADD']=$rs['DO_ADD'];
	$zright['DO_VERADD']=$rs['DO_VERADD'];
	$zright['DO_MODERATOR']=$rs['DO_MODERATOR'];
	$zright['DO_NEWS']=$rs['DO_NEWS'];
	$zright['DO_DELSVOI']=$rs['DO_DELSVOI'];
mysql_free_result($rs_2);
return;
}

//============================================================================================================================================

function sqldatetime($pd_date){
$ps_sqldatetime=strftime("%Y-%m-%d %H:%M:%S", strtotime($pd_date));
return $ps_sqldatetime;
}

//============================================================================================================================================

function sqldatetime2($pd_date){
$ps_sqldatetime=strftime("%Y-%m-%d %H:%M:%S", $pd_date);
return $ps_sqldatetime;
}

//============================================================================================================================================

function sqldate($pd_date){
$ps_sqldatetime=strftime("%Y-%m-%d", strtotime($pd_date));
return $ps_sqldatetime;
}

//============================================================================================================================================

function sqldate2($pd_date){
$ps_sqldatetime=strftime("%Y-%m-%d", $pd_date);
return $ps_sqldatetime;
}

//============================================================================================================================================

function cdate($ps_date){
return date('d.m.Y H:i:s',strtotime($ps_date));
}
//============================================================================================================================================
function cdate2($ps_date){
return date('d.m.Y',strtotime($ps_date));
}
//============================================================================================================================================
function cdate3($ps_date){
return date('H:i:s',strtotime($ps_date));
}
//============================================================================================================================================
function cdate4($ps_date){
return date('H:i',strtotime($ps_date));
}
//============================================================================================================================================

function cdate_2($ps_date){
return date('d.m.Y H:i:s',$ps_date);
}
//============================================================================================================================================
function cdate2_2($ps_date){
return date('d.m.Y',$ps_date);
}
//============================================================================================================================================
function cdate3_2($ps_date){
return date('H:i:s',$ps_date);
}
//============================================================================================================================================
function requestdata2($ps1)
{
	if (isset($_REQUEST[$ps1])){$ps_requestdata=replacesymbol4(trim($_REQUEST[$ps1]));} else {$ps_requestdata='';}
	return $ps_requestdata;
}

//============================================================================================================================================

function requestdata($ps1)
{
	if (isset($_REQUEST[$ps1])){$ps_requestdata=replacesymbol(trim($_REQUEST[$ps1]));} else {$ps_requestdata='';}
	return $ps_requestdata;
}

//============================================================================================================================================

function us_text($ps_string){
global $zcmas;
echo '<font color="'.$zcmas[4].'" size=6><b>'.$ps_string.'</b></font><br>';
return;
}

//============================================================================================================================================

function us_text2($ps_string){
global $zcmas;
echo '<font color="'.$zcmas[4].'" size=5><b>'.$ps_string.'</b></font><br>';
return;
}

//============================================================================================================================================
function recordcount_new($ps_sql){
	global $conn_s;	
	$rs_s2 = mysql_query("select COUNT(CODE) as count1 from ".$ps_sql,$conn_s);
		$rs_s=mysql_fetch_array($rs_s2);
		$pi_recordcount = $rs_s['count1'];
	mysql_free_result($rs_s2);
	if ($pi_recordcount=="") $pi_recordcount=0;
return $pi_recordcount;
}
//============================================================================================================================================


function recordcount($ps_sql){
	global $conn_s;	
	$rs_s2=mysql_query($ps_sql,$conn_s);
		$pi_recordcount=mysql_num_rows($rs_s2);
	mysql_free_result($rs_s2);
	if ($pi_recordcount=="") $pi_recordcount=0;
return $pi_recordcount;
}
//============================================================================================================================================

function mid($ps_string,$pi_start,$pi_count){
	$ps_mid=substr($ps_string, $pi_start-1, $pi_count);
return $ps_mid;
}
//============================================================================================================================================

function ucase($ps_textl){
	$ps_ucase=strtoupper($ps_textl);
return $ps_ucase;
}
//============================================================================================================================================

function lcase($ps_textl){
	$ps_lcase=strtolower ($ps_textl);
return $ps_lcase;
}
//============================================================================================================================================

function instr($pi_pos, $ps_str, $ps_what){
$ps_instr=strpos($ps_str, $ps_what, $pi_pos-1);
if ($ps_instr==""){
	$ps_instr=0;
}else{
	$ps_instr=$ps_instr+1;
}
return $ps_instr;
}

//============================================================================================================================================

function getconf($ps_param,$ps_typeparam){
	global $conn_s;
	$rs_s2=mysql_query("select ".strtoupper($ps_typeparam)." from tbl_conf where PARAM='".$ps_param."'",$conn_s);
		$rs_s=mysql_fetch_array($rs_s2);
		$rs_getconf=$rs_s[$ps_typeparam];
	mysql_free_result($rs_s2);
return $rs_getconf;
}
//============================================================================================================================================

function replacesymbol4($ps1)
{
if ($ps1!=""){
	$ps1=trim($ps1);
	$ps1=str_replace("   "," ",$ps1);
	$ps1=str_replace("  "," ",$ps1);
	$ps1=str_replace("'","&#34",$ps1);	
	}
return $ps1;
}
//============================================================================================================================================
function replacesymbol_int($ps1)
{
if ($ps1!=""){
	$ps1=replacesymbol($ps1);
	$ps1=round($ps1);
	}
return $ps1;
}
//============================================================================================================================================



function replacesymbol($ps1)
{
if ($ps1!=""){
	$ps1=trim($ps1);
	$ps1=str_replace("   "," ",$ps1);
	$ps1=str_replace("  "," ",$ps1);
	$ps1=str_replace("#","",$ps1);//&#35
	$ps1=str_replace('"',"&#34",$ps1);//&#34
	$ps1=str_replace("'","",$ps1);
	//$ps1=str_replace(",",".",$ps1);
	$ps1=str_replace("\\","",$ps1);
	//$ps1=str_replace("/","",$ps1); //�� ����� ��������� - ����� ������ http:// ����������
	//$ps1=str_replace("=","",$ps1); //magnet-������ �� ��������
	$ps1=str_replace("|","",$ps1);
	//$ps1=str_replace("&","",$ps1); //magnet-������ �� ��������
	$ps1=str_replace("%","",$ps1);
	$ps1=str_replace("^","",$ps1);
	//$ps1=str_replace("!","",$ps1);
	$ps1=str_replace("}","",$ps1);
	$ps1=str_replace("{","",$ps1);
	//$ps1=str_replace("?","",$ps1);//magnet
	$ps1=str_replace("<","&lt;",$ps1);//&lt;
	$ps1=str_replace(">","&gt;",$ps1);//&gt;
	}
return $ps1;
}
//============================================================================================================================================

function all_readparam()
	{
global $ps_type, $ps_sort, $ps_style, $ps_msg, $ps_print, $ps_h, $ps_w, $ps_search, $ps_type2, $ps_type3, $ps_desc,$ps_code,$ps_step,$ps_comment;
global $ps_page,$conn_s;
global $zver, $znetname, $znetsite, $zos;

error_reporting(0);	
$ps_type= strtolower(replacesymbol(trim($_REQUEST['type'])));
$ps_type2= strtolower(replacesymbol(trim($_REQUEST['type2'])));
$ps_type3=strtolower(replacesymbol(trim($_REQUEST['type3'])));
$ps_style= strtolower(replacesymbol(trim($_REQUEST['style'])));
$ps_sort= strtolower(replacesymbol(trim($_REQUEST['sort'])));
$ps_msg= strtolower(replacesymbol(trim($_REQUEST['msg'])));
$ps_search= strtolower(replacesymbol(trim($_REQUEST['search'])));
$ps_print= replacesymbol_int($_REQUEST['print']);
$ps_page= replacesymbol_int($_REQUEST['page']);
$ps_code= replacesymbol_int($_REQUEST['code']);
$ps_desc= replacesymbol_int($_REQUEST['desc']);
$ps_step= replacesymbol_int($_REQUEST['step']);
error_reporting(e_all);
if ($ps_page=="") $ps_page=1;

$zver=getconf("VERSION","VALUESTR");
$znetname=getconf("NETNAME","VALUESTR");
$znetsite=getconf("NETSITE","VALUESTR");
$ps_color=getconf("SCHEME","VALUESTR");
$ps_comment=getconf("ISCOMMENT","VALUEINT");
//�������� - ��� �� ��
$zos="nix";
if (instr(1,lcase(PHP_OS),"in")>0) $zos="win";
if (instr(1,lcase(PHP_OS),"freebsd")>0) $zos="nix";
return;
}

//============================================================================================================================================

function site_header ()
	{
	global $zserver,$ps_color,$ps_errorcode,$zl,$zmodule,$zpath;
	?>
	<meta http-equiv=content-type content="text/html; charset=windows-1251">
	<?php
	/*
	=====================================================================================================================
	��������� ������, ������ ��� ������� ���������. ��������� ��������� ��� ���������, � ����� ������ ������������ �����.
	��������� ����� �� ���� �������.
	=====================================================================================================================
	*/	
	?>
	<meta name=description content="������� Magneto http://userside.org.ua/magneto/">
	<meta name=author content="(c) Dyuringer A. - magneto@userside.org.ua">
	<meta name=copyright content="��� ������� Magneto ����������� ������������� ������ep� ������ ������������� � ���������� ����������������� ������� � ������ �� ��������� ����� � ����� ������� �������������� �����.">
	<link rel="alternate" type="application/rss+xml" title="<?php echo getconf("PROJECTNAME","VALUESTR")?> - <?php echo $zl['167']?>" href="<?php echo $zpath?>/rss/index.php">
	<script type="text/javascript" src="<?php echo $zpath?>main/config/startscript.js"></script>
	<script type="text/javascript" src="<?php echo $zpath?>module/<?php echo $zmodule?>/config/modulescript.js"></script>
	<script type="text/javascript" src="<?php echo $zpath?>main/config/reflex.js"></script>
	<script type="text/javascript" src="<?php echo $zpath?>main/config/filmed.js"></script>
	<link rel="stylesheet" href="<?php echo $zpath?>main/config/thumbnailviewer.css" type="text/css" />
	<script src="<?php echo $zpath?>main/config/thumbnailviewer.js" type="text/javascript">
		/***********************************************
		* Image Thumbnail Viewer Script- � Dynamic Drive (www.dynamicdrive.com)
		* This notice must stay intact for legal use.
		* Visit http://www.dynamicdrive.com/ for full source code
		***********************************************/
	</script>	
	<?php
	if ($ps_errorcode=="") require_once $zserver."module/".$zmodule."/inc_style.php";
	return;
}

//============================================================================================================================================
?>
